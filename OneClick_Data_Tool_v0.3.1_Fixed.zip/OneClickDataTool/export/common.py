from __future__ import annotations

import os
from pathlib import Path

from data.connectors.csv_source import _lit


class ExportError(Exception):
    def __init__(self, what: str, why: str = "", suggestion: str = ""):
        super().__init__(what)
        self.what, self.why, self.suggestion = what, why, suggestion


def check_destination(dest: str, source_path: str | None) -> None:
    """Never overwrite the user's original data file."""
    if source_path and Path(dest).resolve() == Path(source_path).resolve():
        raise ExportError("The export would overwrite your original file.",
                          "OneClick Data Tool never modifies the original data.",
                          "Choose a different file name or folder.")
    if not Path(dest).parent.exists():
        raise ExportError("The destination folder does not exist.", str(Path(dest).parent),
                          "Choose an existing folder.")


def tmp_path(dest: str) -> str:
    return dest + ".part"


def finish(tmp: str, dest: str) -> None:
    os.replace(tmp, dest)  # atomic: a failed export never leaves a half-written target


def cleanup(tmp: str) -> None:
    try:
        os.remove(tmp)
    except OSError:
        pass


def copy_to(engine, table: str, dest: str, options: str, select: str = "*") -> None:
    from data.types import quote_ident
    tmp = tmp_path(dest)
    try:
        engine.execute(f"COPY (SELECT {select} FROM {quote_ident(table)} ORDER BY rowid) "
                       f"TO {_lit(tmp)} ({options})")
        finish(tmp, dest)
    except BaseException:
        cleanup(tmp)
        raise
