from data.types import quote_ident, type_kind
from export.common import copy_to

# A text cell that spreadsheet programs would run as a formula (=, @, tab/CR, or +/- followed by
# something that is not a number/phone-like) gets a leading apostrophe ("CSV injection" protection).
_DANGEROUS = r"^[=@\t\r]|^[+-][^0-9\s().,+-]"


def _safe_select(engine, table: str) -> str:
    cols = [c for c, t in engine.schema(table) if type_kind(t) == "text"]
    if not cols:
        return "*"
    repl = ", ".join(
        f"(CASE WHEN regexp_matches({quote_ident(c)}, '{_DANGEROUS}') THEN '''' || {quote_ident(c)} "
        f"ELSE {quote_ident(c)} END) AS {quote_ident(c)}" for c in cols)
    return f"* REPLACE ({repl})"


def export_csv(engine, table: str, dest: str, delimiter: str = ",", neutralize_formulas: bool = True) -> None:
    d = "\\t" if delimiter == "\t" else delimiter
    select = _safe_select(engine, table) if neutralize_formulas else "*"
    copy_to(engine, table, dest, f"FORMAT CSV, HEADER true, DELIMITER '{d}'", select)
