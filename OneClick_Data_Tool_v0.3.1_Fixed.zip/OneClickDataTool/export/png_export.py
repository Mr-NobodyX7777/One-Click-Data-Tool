from export.common import ExportError


def export_png(fig, dest: str, dpi: int = 200) -> None:
    """Save a rendered chart. Refuses figures that were never validated/rendered."""
    if fig is None or not getattr(fig, "axes", None):
        raise ExportError("There is no valid chart to export.", "The chart is empty or was not generated.",
                          "Generate a chart first.")
    fig.savefig(dest, dpi=dpi, format="png", bbox_inches="tight", facecolor=fig.get_facecolor())
