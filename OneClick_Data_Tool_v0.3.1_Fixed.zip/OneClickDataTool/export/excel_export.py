from __future__ import annotations

import datetime as dt
from decimal import Decimal

from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE

from data.types import quote_ident
from export.common import ExportError, cleanup, finish, tmp_path

EXCEL_MAX_DATA_ROWS = 1_048_575  # one row is the header
EXCEL_MAX_CELL_CHARS = 32_767     # longer text makes Excel report the file as corrupt


def _cell(ws, v):
    """Convert a value for openpyxl. Text is always stored as TEXT (a value such as '=1+1' must not
    become a live formula) and characters Excel cannot store are removed instead of aborting the export."""
    if v is None or isinstance(v, (int, float, bool, dt.datetime, dt.date, dt.time)):
        return v
    if isinstance(v, Decimal):
        return float(v)
    if not isinstance(v, str):
        v = str(v)
    v = ILLEGAL_CHARACTERS_RE.sub("", v)[:EXCEL_MAX_CELL_CHARS]
    if v.startswith("="):
        c = WriteOnlyCell(ws, value=v)
        c.data_type = "s"
        return c
    return v


def export_excel(engine, table: str, dest: str, sheet_name: str = "Data") -> None:
    rows = engine.row_count(table)
    if rows > EXCEL_MAX_DATA_ROWS:
        raise ExportError(
            f"Excel cannot hold {rows:,} rows in one worksheet.",
            f"The limit is {EXCEL_MAX_DATA_ROWS:,} data rows per sheet.",
            "Export as Parquet or CSV instead, or filter/sample the data first.")
    cols = [c for c, _ in engine.schema(table)]
    tmp = tmp_path(dest)
    try:
        wb = Workbook(write_only=True)
        ws = wb.create_sheet(sheet_name[:31] or "Data")
        ws.append([_cell(ws, c) for c in cols])
        cur = engine.execute(f"SELECT * FROM {quote_ident(table)} ORDER BY rowid")
        while True:
            chunk = cur.fetchmany(20_000)
            if not chunk:
                break
            for r in chunk:
                ws.append([_cell(ws, v) for v in r])
        wb.save(tmp)
        finish(tmp, dest)
    except BaseException:
        cleanup(tmp)
        raise
