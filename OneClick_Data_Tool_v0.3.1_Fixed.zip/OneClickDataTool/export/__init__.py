"""Dataset export. Output goes only to a file the user chooses; the original is never overwritten."""
from __future__ import annotations

from export.common import ExportError, check_destination
from export.csv_export import export_csv
from export.excel_export import export_excel
from export.json_export import export_json
from export.parquet_export import export_parquet

FORMATS = {
    "CSV (.csv)": (".csv", lambda e, t, d: export_csv(e, t, d)),
    "Parquet (.parquet)": (".parquet", export_parquet),
    "Excel (.xlsx)": (".xlsx", export_excel),
    "JSON (.json)": (".json", lambda e, t, d: export_json(e, t, d, lines=False)),
    "JSON Lines (.jsonl)": (".jsonl", lambda e, t, d: export_json(e, t, d, lines=True)),
}


def export_dataset(engine, table: str, dest: str, fmt_label: str, source_path: str | None) -> None:
    check_destination(dest, source_path)
    FORMATS[fmt_label][1](engine, table, dest)


__all__ = ["FORMATS", "ExportError", "export_dataset"]
