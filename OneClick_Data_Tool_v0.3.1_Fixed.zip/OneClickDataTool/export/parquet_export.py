from export.common import copy_to


def export_parquet(engine, table: str, dest: str) -> None:
    copy_to(engine, table, dest, "FORMAT PARQUET, COMPRESSION ZSTD")
