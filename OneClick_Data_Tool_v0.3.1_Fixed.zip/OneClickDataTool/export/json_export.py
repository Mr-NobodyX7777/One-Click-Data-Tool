from data.types import is_float_type, quote_ident
from export.common import copy_to


def export_json(engine, table: str, dest: str, lines: bool = False) -> None:
    """lines=True writes JSON Lines (one object per line), otherwise a JSON array.

    JSON has no NaN/Infinity, so non-finite floats are written as null (valid JSON for every parser)."""
    floats = [c for c, t in engine.schema(table) if is_float_type(t)]
    select = "*"
    if floats:
        repl = ", ".join(f"(CASE WHEN isfinite({quote_ident(c)}) THEN {quote_ident(c)} END) AS {quote_ident(c)}"
                         for c in floats)
        select = f"* REPLACE ({repl})"
    copy_to(engine, table, dest, f"FORMAT JSON, ARRAY {'false' if lines else 'true'}", select)
