"""Self-contained, printable HTML data-quality report (no network assets)."""
from __future__ import annotations

from html import escape
from pathlib import Path


def _e(value) -> str:
    return escape('—' if value is None else str(value), quote=True)


def export_html_report(audit, dest_path: str) -> None:
    """Export the supplied current AuditResult to a portable HTML document."""
    if audit is None:
        raise ValueError('Run an audit before exporting the report.')
    rows = []
    for col in audit.columns:
        fields = [col.name, col.duck_type, col.category, 'Healthy' if col.healthy else 'Review',
                  f'{col.missing:,}', f'{col.missing_pct:.1f}%', f'{col.unique:,}',
                  col.mean, col.median, col.std, col.skew, col.outliers,
                  '; '.join(col.issues) or 'No issues detected']
        rows.append('<tr>' + ''.join(f'<td>{_e(v)}</td>' for v in fields) + '</tr>')
    penalties = ''.join('<li>' + _e(name) + ': ' + _e(f'{penalty:g}') +
                        ' points (' + _e(detail) + ')</li>'
                        for name, penalty, detail in audit.health.components)
    recommendations = ''.join(
        '<li><b>' + _e(col) + '</b>: ' + _e(getattr(rec, 'reason', None)
                        or getattr(rec, 'explanation', None)
                        or getattr(rec, 'action', 'Review missing values')) + '</li>'
        for col, rec in audit.recommendations.items()) or '<li>No missing-value recommendations.</li>'
    headers = ['Column', 'Data type', 'Category', 'Status', 'Missing', 'Missing %', 'Unique',
               'Mean', 'Median', 'Std dev', 'Skew', 'Outliers', 'Issues']
    content = f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Data Quality Report — {_e(audit.dataset_name)}</title>
<style>body{{background:#101827;color:#e9eef8;font:15px/1.5 system-ui,Arial,sans-serif;margin:0}}
main{{max-width:1240px;margin:36px auto;padding:0 26px}}h1,h2{{color:#fff}}h1{{margin-bottom:2px}}
.muted{{color:#a0aec4}}.stats{{display:flex;gap:14px;flex-wrap:wrap;margin:28px 0}}.stat{{background:#1b273a;
 border:1px solid #344257;padding:16px 24px;border-radius:12px;min-width:140px}}.stat strong{{font-size:28px;display:block;color:#8fd6fa}}
section{{background:#182236;border:1px solid #344257;margin:20px 0;padding:20px;border-radius:12px;overflow:auto}}
table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{text-align:left;padding:11px;border-bottom:1px solid #344257}}
th{{color:#a8d6f9;white-space:nowrap}}tr:hover{{background:#263449}}li{{margin:5px 0}}@media print{{body{{background:white;color:black}}
section,.stat{{background:white;border:1px solid #aaa}}h1,h2,.stat strong{{color:black}}th{{color:black}}}}</style></head>
<body><main><h1>Data Quality Report</h1><div class="muted">Dataset: {_e(audit.dataset_name)}</div>
<div class="stats"><div class="stat"><strong>{audit.health.score}/100</strong>Health score</div>
<div class="stat"><strong>{audit.rows:,}</strong>Rows</div><div class="stat"><strong>{len(audit.columns):,}</strong>Columns</div>
<div class="stat"><strong>{audit.duplicates:,}</strong>Duplicate rows</div>
<div class="stat"><strong>{audit.missing_pct:.1f}%</strong>Missing cells</div></div>
<section><h2>Health-score breakdown</h2><ul>{penalties}</ul><p class="muted">Outliers are potential anomalies,
not necessarily errors. Scores are indicators, not proof of correctness.</p></section>
<section><h2>Column-level results</h2><table><thead><tr>{''.join('<th>'+_e(h)+'</th>' for h in headers)}</tr></thead>
<tbody>{''.join(rows)}</tbody></table></section>
<section><h2>Recommendations</h2><ul>{recommendations}</ul></section>
<p class="muted">Generated locally by OneClick Data Tool. All report content is embedded in this file.</p>
</main></body></html>'''
    dest = Path(dest_path)
    tmp = dest.with_name(dest.name + '.part')
    try:
        tmp.write_text(content, encoding='utf-8')
        tmp.replace(dest)
    finally:
        tmp.unlink(missing_ok=True)
