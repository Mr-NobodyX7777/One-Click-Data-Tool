# OneClick Data Tool — v0.2 Repair Log

This update was made from the uploaded `OneClickDataTool(1).zip`,
`TESTING_REPORT(1).md`, `BUG_FIXES(1).md` and `ROADMAP_TO_v1(1).md`.

## Implemented in the source files

| Issue | File(s) | Outcome |
|---|---|---|
| CSV preview type fallback resets on import | `data/connectors/csv_source.py`, `app/import_dialog.py` | Fallback retained; import uses same previewed source/options. Extra retry when preview parsing fails. |
| CSV invalid encoding setting | `data/connectors/csv_source.py` | Reject unknown encodings with actionable message. |
| Overbroad importer `BaseException` | `data/importer.py` | Changed to `Exception` and still drops partial table. |
| XML missing | `data/connectors/xml_source.py`, registry, import UI | Auto-detect repeating records, optional record XPath, nested flattening, bounded parser, DTD rejection. |
| DuckDB file connector missing | `data/connectors/duckdb_source.py`, registry, import UI | File/table selection and read-only ingestion of tables/views. |
| No project save/open | `app/project.py`, main window | Portable `.ocdt` snapshot of data, immutable originals, surviving undo versions, metadata, history. |
| No shareable HTML data-quality report | `export/html_report.py`, main window | Self-contained, printable HTML with statistics, issues, quality score and recommendations. |
| Closing app during background job | `app/main_window.py` | Prevent exit and close-dataset while a task is still running. |
| No regression coverage for these features | `tests/test_v02_features.py` | CSV fallback, undo trim, XML, DuckDB, archive roundtrip, HTML tests added. |
| Windows distribution workflow | `build_windows.bat` | Builder to create PyInstaller `--onefile` EXE on a Windows build PC. |

## Correction to supplied reports

The alleged undo/redo *stack index overflow* bug is **not demonstrably a bug**
in the submitted implementation. Every `pop(0)` shifts the index of the current
version left by 1, and the current `pos -= 1` performs the corresponding update.
`Dataset.apply()` has already discarded any redo branch and moved the cursor to
the just-appended end of the stack before trimming. This logic was **not replaced**.
A 12-change test now checks that `pos` tracks the correct retained version and
that reset can still return to the original.

Other report statements need care: `itertools.count` uses Python integers and
will not wrap negative simply because the program runs a long time. The alleged
multiple-file SQL-injection and thread-safety guarantees were not verified as
part of this patch.

## Remaining / not claimed as fixed

- Full project **runtime** restore tests still need a machine with dependencies.
  Audits are recomputed after opening rather than serialized; charts are not saved.
- XML supports tabular repeating records, not arbitrary hierarchical XML or huge
  XML documents. DuckDB and XML connectors materialize Arrow data in memory.
- HTML report currently contains quality statistics, breakdowns and recommendations,
  but not rendered distribution-image charts.
- No MySQL server integration / shared multi-user database yet; the existing engine
  remains a per-session local DuckDB instance.
- Windows EXE is a build recipe, not an EXE produced by this ZIP.
- SQL workspace, join/filter builder, advanced visualizations, autosave and crash
  recovery are still future enhancements.
- GUI testing, full dependency-based tests and large-file benchmarks are **not**
  verified in this build environment; package downloads were blocked.

## Validation performed here

1. Python `compileall` succeeded across the application and tests.
2. Standalone HTML rendering and safe markup escaping passed a smoke test.
3. XML record auto-detection, flattening, and DTD rejection passed a focused smoke test.
4. The ZIP archive was validated for entries/CRC integrity.

## Validate on a developer's Windows machine

```powershell
py -3 -m pip install -r requirements.txt pytest
py -3 -m pytest tests/ -v
py -3 main.py
```

Then run `build_windows.bat` and test `dist/OneClickDataTool.exe` on a clean
Windows PC without Python installed. Run import → audit → cleaning → undo →
report export → save → quit → open project → verify data. Do not treat the
program as fully production-verified until these steps pass.

## v0.3 - Loading screens
- `main.py` now shows a loading screen immediately and loads the heavy libraries behind it (new: `app/splash.py`, `app/paths.py`).
- First launch shows extra wording ("preparing components, one time only").
- `Start OneClick Data Tool.bat` opens a "First-time setup" window (`setup_splash.ps1`) while libraries install, then hands over to the app's own loading screen.
- First-run setup window now shows: percentage, the component currently downloading (with friendly name and size), a list of finished downloads, download speed and an estimated time remaining.
- `requirements.txt` now uses `PySide6-Essentials` (the app only uses QtCore/QtGui/QtWidgets) so the first-time download no longer includes the huge WebEngine/Addons packages.
- The in-app loading screen also shows a percentage and the library being loaded.
- Menu items now have extra right padding so shortcut keys (F5, Alt+1...) no longer overlap the label.
- Repository set-up: CI workflow, Dependabot, issue/PR templates, .gitignore, .gitattributes, LICENSE, THIRD_PARTY_NOTICES. GUI smoke test no longer hangs when a job is still running at close.
- Fixed CI failure with newer DuckDB (2.x): result conversion now goes through data/duckdb_compat.py (works on DuckDB 1.x and 2.x).


## v0.3.1 - bug-fix round (found by an independent test pass)

| # | Problem found | Fix |
|---|---|---|
| 1 | One blank cell turned a whole numeric/date/boolean CSV column into text (`''` was removed from DuckDB's null list). | Empty cells are always NULL (`data/connectors/csv_source.py`). |
| 2 | Auditing wide tables was extremely slow (300 columns = 11 s on 3 rows), ran out of memory at 600 columns and crashed the process at 3,000. | Columns are profiled in batches of 25 (`auditor/statistics.py`); 3,000 columns now take ~15 s. |
| 3 | Excel export aborted on control characters; text such as `=1+1` became a live formula; very long text corrupted the sheet. | Illegal characters removed, text always stored as text, cells capped at 32,767 characters. |
| 4 | CSV export could carry spreadsheet formulas (CSV injection). | Text cells starting with `=`, `@`, tab/CR, or `+`/`-` followed by a non-number get a leading `'`. Normal values and phone numbers are untouched. |
| 5 | A column named `rowid` silently scrambled row order in cleaning and export. | Such a column is renamed to `rowid_1` on import (with a warning). |
| 6 | Time-zone-aware timestamps (e.g. Parquet) crashed the audit: `pytz` was missing. | `pytz` added to `requirements.txt` and to the PyInstaller build. |
| 7 | Default missing-value words could silently erase real text such as the country code `NA`. | The import now warns, per column, how many text values were treated as missing. |
| 8 | JSON export wrote `NaN`/`Infinity` (invalid JSON). | Non-finite numbers are written as `null`. |
| 9 | Filling an integer column with `3.7` silently stored 4. | Rejected: whole numbers only. |
| 10 | Integers beyond 64-bit in JSON lost precision silently; Excel formulas without a stored result imported as empty silently; single-record XML was refused; ragged CSV rows were silently padded or collapsed into ONE column. | Warnings for the first two; single-record XML is read; ragged CSV files are read with padding and a warning with the first bad line. |
| 11 | Closing a dataset raised a Python traceback inside a Qt slot. | Dropdown refresh tolerates a just-closed dataset. |
| 12 | Launcher kept a broken/moved `.venv` forever. | `.bat`/`.sh`/`.command` re-install automatically when `duckdb`/`pytz` cannot be imported. |
| 13 | (found during the fix round) DuckDB 2.0.0 raised an internal error that invalidated the whole database when removing duplicates on tables mixing nested/binary/decimal columns. | Duplicate removal now uses `min(rowid) ... GROUP BY` instead of `QUALIFY row_number()`. |
| 14 | A CSV containing only blank lines was accepted as data. | Rejected with a clear message. |

Regression tests for every item: `tests/test_v031_fixes.py` (23 tests). Full suite: 65 passed.
Still NOT verified: the Windows `.bat` launcher and the PyInstaller EXE (no Windows machine was available).
