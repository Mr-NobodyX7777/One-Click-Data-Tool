@echo off
setlocal
cd /d "%~dp0"
REM Run THIS BUILDER on Windows (Python 3.10-3.13 installed) to make the portable one-file EXE.
REM Recipients of dist\OneClickDataTool.exe do NOT need Python or to run this builder.
where py >nul 2>&1
if errorlevel 1 (
  echo Python launcher not found. Install Python on this BUILD PC only.
  pause
  exit /b 1
)
py -3 -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto fail
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name "OneClickDataTool" --collect-all duckdb --collect-all polars --collect-all pyarrow --collect-all matplotlib --collect-all scipy --collect-all PySide6 --hidden-import pytz main.py
if errorlevel 1 goto fail
echo.
echo Built: dist\OneClickDataTool.exe
pause
exit /b 0
:fail
echo Build failed - check console output above.
pause
exit /b 1
