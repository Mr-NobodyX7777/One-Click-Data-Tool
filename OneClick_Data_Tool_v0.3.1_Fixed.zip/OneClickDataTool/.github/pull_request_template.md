## What changed
<!-- Short description -->

## Checklist
- [ ] `python -m pytest tests -q` passes
- [ ] No user data files or `.venv` committed
- [ ] `FIXES_APPLIED.md` / README updated if behaviour changed
