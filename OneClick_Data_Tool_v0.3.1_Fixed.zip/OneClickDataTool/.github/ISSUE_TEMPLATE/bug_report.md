---
name: Bug report
about: Something does not work as expected
labels: bug
---
**What happened?**

**Steps to reproduce**
1.

**Expected behaviour**

**Environment** (Windows version, Python version, file type/size you imported)

**Log** (paste the end of `%LOCALAPPDATA%\OneClickDataTool\logs\oneclick.log`; remove anything private)
