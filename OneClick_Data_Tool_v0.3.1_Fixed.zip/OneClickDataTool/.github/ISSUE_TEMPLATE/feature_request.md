---
name: Feature request
about: Suggest an improvement
labels: enhancement
---
**What do you want to do?**

**Why is it useful?**
