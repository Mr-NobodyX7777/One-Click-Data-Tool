@echo off
setlocal
cd /d "%~dp0"
title OneClick Data Tool

rem Marker files used to coordinate the loading windows
set "OC_DONE=%TEMP%\oneclick_setup_done.flag"
set "OC_FAIL=%TEMP%\oneclick_setup_fail.flag"
set "ONECLICK_HANDOFF=%TEMP%\oneclick_handoff.flag"
set "OC_LOG=%TEMP%\oneclick_setup.log"
del "%OC_DONE%" "%OC_FAIL%" "%ONECLICK_HANDOFF%" "%OC_LOG%" >nul 2>&1

rem Self-repair: a moved/renamed folder or an older install (missing pytz) triggers a clean re-install
if exist ".venv\installed.ok" (
  ".venv\Scripts\python.exe" -c "import duckdb, pytz" >nul 2>&1
  if errorlevel 1 (
    echo Repairing the installation - please wait...
    rmdir /s /q .venv >nul 2>&1
  )
)
if exist ".venv\installed.ok" goto run

echo ==============================================================
echo  OneClick Data Tool - first-time setup (one time only)
echo  This downloads the required Python libraries (~400 MB).
echo  After this, the app runs completely offline.
echo ==============================================================
echo.
set PY=
py -3 --version >nul 2>&1 && set PY=py -3
if "%PY%"=="" python --version >nul 2>&1 && set PY=python
if "%PY%"=="" (
  echo Python 3.10 or newer is required but was not found.
  echo Install it from https://www.python.org/downloads/  ^(tick "Add python.exe to PATH"^)
  echo then double-click this file again.
  pause
  exit /b 1
)

rem Show a friendly "first-time setup" window while the libraries install
if exist "setup_splash.ps1" start "" /b powershell -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File "setup_splash.ps1" -Done "%OC_DONE%" -Fail "%OC_FAIL%" -Handoff "%ONECLICK_HANDOFF%" -Log "%OC_LOG%"

%PY% -m venv .venv || goto fail
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
if exist "setup_splash.ps1" (
  echo Downloading components - progress is shown in the setup window...
  set PYTHONUNBUFFERED=1
  ".venv\Scripts\python.exe" -u -m pip install --progress-bar off -r requirements.txt > "%OC_LOG%" 2>&1 || goto fail
) else (
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt || goto fail
)
echo ok> ".venv\installed.ok"
echo.
echo Setup complete. Starting the app...
echo ok> "%OC_DONE%"

:run
start "" ".venv\Scripts\pythonw.exe" main.py %*
exit /b 0

:fail
echo fail> "%OC_FAIL%"
if exist "%OC_LOG%" type "%OC_LOG%"
echo.
echo Setup failed. Check your internet connection and Python version ^(3.10 - 3.13^), then try again.
rmdir /s /q .venv >nul 2>&1
pause
exit /b 1
