# Third-party software

OneClick Data Tool does **not** include any third-party code in this repository.
The launcher installs the following packages from PyPI onto each user's own computer on first run:

| Package | Licence (check the package page for the current terms) |
|---|---|
| PySide6-Essentials (Qt for Python) | LGPL-3.0 / GPL / commercial |
| DuckDB | MIT |
| Polars | MIT |
| PyArrow | Apache-2.0 |
| Matplotlib | Matplotlib licence (PSF-style) |
| SciPy | BSD-3-Clause |
| NumPy | BSD-3-Clause |
| OpenPyXL | MIT |
| pytz | MIT |

If you ever distribute a bundled build (e.g. the PyInstaller .exe from `build_windows.bat`),
the licence terms of these packages apply to that bundle - in particular the LGPL for Qt/PySide6
(include its licence text and allow users to replace the Qt libraries). Review before distributing.
