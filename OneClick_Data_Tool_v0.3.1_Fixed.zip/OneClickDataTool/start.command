#!/usr/bin/env bash
# One-click launcher for macOS / Linux (on macOS double-click "start.command").
cd "$(dirname "$0")" || exit 1
# Self-repair: a moved folder or an older install (missing pytz) triggers a clean re-install.
if [ -f .venv/installed.ok ] && ! .venv/bin/python -c "import duckdb, pytz" >/dev/null 2>&1; then
  echo "Repairing the installation..."; rm -rf .venv
fi
if [ ! -f .venv/installed.ok ]; then
  echo "First-time setup (one time): downloading libraries..."
  PY=$(command -v python3 || command -v python) || { echo "Python 3.10+ is required."; exit 1; }
  "$PY" -m venv .venv && .venv/bin/python -m pip install --upgrade pip -q \
    && .venv/bin/python -m pip install -r requirements.txt \
    && touch .venv/installed.ok || { echo "Setup failed."; rm -rf .venv; exit 1; }
fi
exec .venv/bin/python main.py "$@"
