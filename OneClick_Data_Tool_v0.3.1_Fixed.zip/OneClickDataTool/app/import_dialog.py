"""Import options dialog with live preview (first 100 rows; never loads the whole file)."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFormLayout, QHBoxLayout,
                               QLabel, QLineEdit, QTableWidget, QTableWidgetItem, QVBoxLayout)

from app.errors import friendly
from data.connectors import REGISTRY, detect_format, make_source
from data.connectors.base import SourceError
from data.connectors.csv_source import DEFAULT_MISSING_TOKENS, detect_encoding
from data.connectors.excel_source import list_sheets
from data.connectors.sqlite_source import list_tables
from data.connectors.duckdb_source import list_tables as list_duckdb_tables
from data.duckdb_manager import Engine

DELIMITERS = [("Auto-detect", None), ("Comma  ,", ","), ("Tab", "\t"), ("Semicolon  ;", ";"), ("Pipe  |", "|")]
ENCODINGS = [("Auto-detect", None), ("UTF-8", "utf-8"), ("UTF-16", "utf-16"),
             ("Latin-1 / Windows-1252", "latin-1")]
HEADERS = [("Auto-detect", None), ("First row is a header", True), ("No header row", False)]


class ImportDialog(QDialog):
    def __init__(self, path: str, engine: Engine, parent=None):
        super().__init__(parent)
        self.path, self.engine = path, engine
        self.setWindowTitle(f"Import - {Path(path).name}")
        self.resize(900, 640)
        self.setAccessibleName("Import options")
        lay = QVBoxLayout(self)
        self.info = QLabel()
        self.info.setObjectName("muted")
        lay.addWidget(self.info)

        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignRight)
        self.fmt = QComboBox()
        self.fmt.setToolTip("Detected from the file extension. Change it if the file is a different format.")
        for name in REGISTRY:
            self.fmt.addItem(name)
        try:
            self.fmt.setCurrentText(detect_format(path))
        except SourceError:
            self.fmt.setCurrentText("CSV")  # unknown extension: treat as delimited text
        form.addRow("Format:", self.fmt)

        # CSV
        self.delim = _combo(DELIMITERS)
        self.enc = _combo(ENCODINGS)
        self.header = _combo(HEADERS)
        self.tokens = QLineEdit(", ".join(DEFAULT_MISSING_TOKENS))
        self.tokens.setToolTip("Text values that should be read as missing (NULL). Empty cells are always missing.")
        self.csv_rows = [("Delimiter:", self.delim), ("Encoding:", self.enc), ("Header row:", self.header),
                         ("Missing-value tokens:", self.tokens)]
        # Excel / SQLite / JSON
        self.sheet = QComboBox()
        self.xl_header = QCheckBox("First row contains column names")
        self.xl_header.setChecked(True)
        self.table = QComboBox()
        self.record_element = QLineEdit()
        self.record_element.setPlaceholderText("Auto-detect repeating XML records (optional XPath)")
        self.flatten = QCheckBox("Flatten nested objects into columns (customer.address.city)")
        self.flatten.setChecked(True)
        self._form_widgets = {}
        for label, w in self.csv_rows:
            form.addRow(label, w)
        form.addRow("Worksheet:", self.sheet)
        form.addRow("", self.xl_header)
        form.addRow("Table / view:", self.table)
        form.addRow("XML record path:", self.record_element)
        form.addRow("", self.flatten)
        self.form = form
        lay.addLayout(form)

        self.status = QLabel()
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        self.preview = QTableWidget()
        self.preview.setEditTriggers(QTableWidget.NoEditTriggers)
        self.preview.setAlternatingRowColors(True)
        self.preview.setAccessibleName("Import preview")
        lay.addWidget(self.preview, 1)

        row = QHBoxLayout()
        row.addStretch()
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.button(QDialogButtonBox.Ok).setText("Import")
        self.buttons.button(QDialogButtonBox.Ok).setObjectName("primary")
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        row.addWidget(self.buttons)
        lay.addLayout(row)

        self.fmt.currentTextChanged.connect(self._format_changed)
        for w in (self.delim, self.enc, self.header, self.sheet, self.table):
            w.currentIndexChanged.connect(self._refresh)
        self.tokens.editingFinished.connect(self._refresh)
        self.xl_header.toggled.connect(self._refresh)
        self.flatten.toggled.connect(self._refresh)
        self.record_element.editingFinished.connect(self._refresh)
        self._loading = True
        self._format_changed(self.fmt.currentText())
        self._loading = False
        self._refresh()

    # ----------------------------------------------------------------------------------------
    def _set_visible(self, widgets, on: bool) -> None:
        for w in widgets:
            w.setVisible(on)
            lab = self.form.labelForField(w)
            if lab:
                lab.setVisible(on)

    def _format_changed(self, fmt: str) -> None:
        csv_w = [w for _, w in self.csv_rows]
        self._set_visible(csv_w, fmt == "CSV")
        self._set_visible([self.sheet, self.xl_header], fmt == "Excel")
        self._set_visible([self.table], fmt in ("SQLite", "DuckDB"))
        self._set_visible([self.record_element], fmt == "XML")
        self._set_visible([self.flatten], fmt == "JSON")
        self.sheet.blockSignals(True)
        self.table.blockSignals(True)
        try:
            if fmt == "Excel" and self.sheet.count() == 0:
                for s in list_sheets(self.path):
                    tag = " (hidden)" if s["hidden"] else ""
                    dims = f"  -  {s['rows'] or '?'} rows x {s['cols'] or '?'} cols"
                    self.sheet.addItem(f"{s['name']}{tag}{dims}", s["name"])
            if fmt in ("SQLite", "DuckDB"):
                self.table.clear()
                for t in (list_tables(self.path) if fmt == "SQLite" else list_duckdb_tables(self.path)):
                    n = "?" if t["rows"] is None else f"{t['rows']:,}"
                    self.table.addItem(f"{t['name']} ({t['kind']}, {n} rows)", t["name"])
        except Exception as e:
            self.status.setText(friendly(e, "Could not list the contents").text())
        finally:
            self.sheet.blockSignals(False)
            self.table.blockSignals(False)
        if not self._loading:
            self._refresh()

    def options(self) -> dict:
        fmt = self.fmt.currentText()
        if fmt == "CSV":
            toks = [t.strip() for t in self.tokens.text().split(",") if t.strip()]
            return dict(delimiter=self.delim.currentData(), encoding=self.enc.currentData(),
                        header=self.header.currentData(), missing_tokens=toks)
        if fmt == "Excel":
            return dict(sheet=self.sheet.currentData(), header=self.xl_header.isChecked())
        if fmt in ("SQLite", "DuckDB"):
            return dict(table=self.table.currentData())
        if fmt == "XML":
            return dict(record_element=self.record_element.text().strip() or None)
        if fmt == "JSON":
            return dict(flatten=self.flatten.isChecked())
        return {}

    def build_source(self):
        key = (self.fmt.currentText(), repr(self.options()))
        if getattr(self, "_preview_key", None) == key:
            return self._preview_source
        return make_source(self.path, self.fmt.currentText(), **self.options())

    def _refresh(self) -> None:
        if getattr(self, "_loading", False):
            return
        size = Path(self.path).stat().st_size if Path(self.path).exists() else 0
        self.info.setText(f"{self.path}   ({size / 1024:,.0f} KB)")
        ok = self.buttons.button(QDialogButtonBox.Ok)
        try:
            self._preview_key = None
            src = self.build_source()
            if self.fmt.currentText() == "CSV" and self.enc.currentData() is None:
                self.enc.setItemText(0, f"Auto-detect ({detect_encoding(self.path)})")
            df = src.preview(self.engine, 100)
            self._preview_source = src
            self._preview_key = (self.fmt.currentText(), repr(self.options()))
        except Exception as e:
            msg = friendly(e, "Preview failed")
            self.status.setText(f"Cannot preview with these settings. {msg.what} {msg.why} {msg.suggestion}")
            self.status.setObjectName("error")
            self.status.setStyleSheet("")
            self.preview.setRowCount(0)
            self.preview.setColumnCount(0)
            ok.setEnabled(False)
            return
        self.status.setObjectName("")
        notes = f"Preview of the first {df.height} rows - {df.width} columns detected."
        if src.warnings:
            notes += "  Notice: " + " ".join(src.warnings)
        self.status.setText(notes)
        self._fill(df)
        ok.setEnabled(True)

    def _fill(self, df) -> None:
        self.preview.clear()
        self.preview.setColumnCount(df.width)
        self.preview.setRowCount(df.height)
        self.preview.setHorizontalHeaderLabels([f"{c}\n{str(t)}" for c, t in zip(df.columns, df.dtypes)])
        for c, name in enumerate(df.columns):
            for r, v in enumerate(df[name].to_list()):
                it = QTableWidgetItem("NULL" if v is None else str(v))
                if v is None:
                    it.setForeground(Qt.gray)
                self.preview.setItem(r, c, it)
        self.preview.resizeColumnsToContents()


def _combo(items) -> QComboBox:
    c = QComboBox()
    for label, data in items:
        c.addItem(label, data)
    return c
