"""User-friendly error messages + the developer diagnostic log (never shows tracebacks to users)."""
from __future__ import annotations

import logging
import os
import sys
import uuid
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from pathlib import Path

import duckdb

from cleaner.operations import OperationError
from data.connectors.base import SourceError
from export.common import ExportError

APP_NAME = "OneClickDataTool"


def data_dir() -> Path:
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    d = base / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def setup_logging() -> Path:
    """Local-only rotating log file: logs/oneclick.log. Contains diagnostics, never dataset contents."""
    log_dir = data_dir() / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    path = log_dir / "oneclick.log"
    root = logging.getLogger("oneclick")
    if not root.handlers:
        h = RotatingFileHandler(path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
        root.addHandler(h)
        root.setLevel(logging.INFO)
    return path


@dataclass
class UserMessage:
    title: str
    what: str
    why: str
    suggestion: str
    ref: str

    def text(self) -> str:
        parts = [self.what]
        if self.why:
            parts.append(f"Why it may have happened: {self.why}")
        if self.suggestion:
            parts.append(f"What you can do: {self.suggestion}")
        parts.append(f"Diagnostic reference: {self.ref}")
        return "\n\n".join(parts)


def friendly(exc: BaseException, context: str = "") -> UserMessage:
    """Translate any exception into What / Why / What-to-do, and log the details."""
    ref = uuid.uuid4().hex[:8]
    logging.getLogger("oneclick.error").error("ref=%s context=%s type=%s", ref, context,
                                              type(exc).__name__, exc_info=exc)
    title = "Something went wrong"
    if isinstance(exc, (SourceError, ExportError, OperationError)):
        what = getattr(exc, "what", str(exc))
        why, sug = getattr(exc, "why", ""), getattr(exc, "suggestion", "")
        return UserMessage(title if context == "" else context, what, why, sug, ref)
    msg = str(exc)
    first = msg.strip().splitlines()[0][:300] if msg.strip() else ""
    if isinstance(exc, FileNotFoundError):
        what, why, sug = ("The file could not be found.", "It may have been moved, renamed or deleted.",
                          "Check the file location and try again.")
    elif isinstance(exc, PermissionError):
        what, why, sug = ("Access to the file was denied.", "The file may be open in another program "
                          "or protected.", "Close other programs using it, or choose a different location.")
    elif isinstance(exc, UnicodeDecodeError):
        what, why, sug = ("The text encoding of this file could not be read.",
                          "The file uses a different character encoding than selected.",
                          "Choose another encoding (UTF-8, UTF-16 or Latin-1) in the import options.")
    elif isinstance(exc, (MemoryError, duckdb.OutOfMemoryException)):
        what, why, sug = ("There is not enough memory for this operation.",
                          "The dataset or the operation is larger than the available RAM.",
                          "Close other programs, work with fewer columns, or export to Parquet.")
    elif isinstance(exc, OSError) and getattr(exc, "errno", None) == 28:
        what, why, sug = ("There is not enough free disk space.", "Temporary or output files need space.",
                          "Free up disk space and try again.")
    elif isinstance(exc, duckdb.IOException):
        what, why, sug = ("The file could not be read.", first or "The file may be corrupt or unreadable.",
                          "Check that the file is valid and not open in another program.")
    elif isinstance(exc, (duckdb.InvalidInputException, duckdb.ConversionException, duckdb.ParserException)):
        what, why, sug = ("The data could not be interpreted.",
                          first or "The file may be malformed (for example inconsistent columns).",
                          "Check the delimiter, header and encoding in the import options.")
    elif isinstance(exc, duckdb.Error):
        what, why, sug = ("The data engine could not complete the operation.", first,
                          "Try again; if it keeps happening, reload the dataset.")
    else:
        what, why, sug = ("An unexpected problem occurred.", "", "Try again. If it persists, "
                          "send the diagnostic reference below with the log file.")
    return UserMessage(context or title, what, why, sug, ref)
