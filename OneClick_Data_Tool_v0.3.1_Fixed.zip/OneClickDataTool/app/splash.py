"""Loading screen shown the moment the program starts (before the heavy libraries load)."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication
from PySide6.QtWidgets import QLabel, QProgressBar, QVBoxLayout, QWidget

BG, PANEL, BORDER, TEXT, MUTED, ACCENT = "#0e1a1f", "#16262d", "#27414a", "#e4f0f2", "#8fb0b7", "#2dd4bf"


class SplashScreen(QWidget):
    def __init__(self, first_run: bool = False):
        super().__init__(None, Qt.SplashScreen | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.setFixedSize(520, 300)
        self.setStyleSheet(
            f"QWidget#root {{ background: {BG}; border: 1px solid {BORDER}; border-radius: 14px; }}"
            f"QLabel {{ color: {TEXT}; background: transparent; font-family: 'Segoe UI','Inter','Noto Sans',sans-serif; }}"
            f"QProgressBar {{ background: {PANEL}; border: 1px solid {BORDER}; border-radius: 5px; height: 16px; color: {TEXT}; font-size: 8pt; font-weight: 700; text-align: center; }}"
            f"QProgressBar::chunk {{ background: {ACCENT}; border-radius: 4px; }}")
        root = QWidget(self)
        root.setObjectName("root")
        root.setGeometry(0, 0, 520, 300)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(36, 34, 36, 28)
        lay.setSpacing(6)

        brand = QLabel("◉ OneClick Data Tool")
        brand.setStyleSheet(f"color: {ACCENT}; font-size: 24pt; font-weight: 800;")
        tag = QLabel("Import  ›  Understand  ›  Clean  ›  Visualize  ›  Export")
        tag.setStyleSheet(f"color: {MUTED}; font-size: 10pt;")
        lay.addWidget(brand)
        lay.addWidget(tag)
        lay.addStretch(1)

        self.status = QLabel("Starting...")
        self.status.setStyleSheet("font-size: 11pt; font-weight: 600;")
        lay.addWidget(self.status)
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setTextVisible(True)
        self.bar.setAlignment(Qt.AlignCenter)
        self.bar.setFormat("%p%")
        lay.addWidget(self.bar)
        note = ("First launch: preparing components. This happens only once and can take a minute or two."
                if first_run else "Your data never leaves this computer.")
        self.note = QLabel(note)
        self.note.setWordWrap(True)
        self.note.setStyleSheet(f"color: {MUTED}; font-size: 9pt; padding-top: 6px;")
        lay.addWidget(self.note)

        screen = QGuiApplication.primaryScreen()
        if screen:
            g = screen.availableGeometry()
            self.move(g.center().x() - self.width() // 2, g.center().y() - self.height() // 2)

    def set_status(self, text: str) -> None:
        self.status.setText(text)
        QGuiApplication.processEvents()

    def set_progress(self, done: int, total: int) -> None:
        self.bar.setRange(0, 100)
        self.bar.setValue(int(100 * done / max(total, 1)))
        QGuiApplication.processEvents()
