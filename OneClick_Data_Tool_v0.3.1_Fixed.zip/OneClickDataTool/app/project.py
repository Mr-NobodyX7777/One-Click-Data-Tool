"""Portable, self-contained project archive (.ocdt).

Projects store all remaining undo versions and the immutable original as Parquet,
plus metadata/history as JSON. They never depend on the source files still existing.
"""
from __future__ import annotations

import json
import os
import shutil
import tempfile
import zipfile
from dataclasses import asdict
from pathlib import Path

from cleaner.history import HistoryEntry
from data.dataset import Dataset, DatasetInfo
from data.importer import protect_reserved_names
from data.types import quote_ident

PROJECT_SCHEMA = 1
MAX_MANIFEST_BYTES = 8 * 1024 * 1024


def _lit(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _snapshot(engine, table: str, path: Path) -> None:
    engine.execute(f"COPY (SELECT * FROM {quote_ident(table)}) TO {_lit(str(path))} (FORMAT PARQUET)")


def save_project(state, path: str) -> None:
    """Atomically save a reusable project that works even if source data is moved."""
    dest = Path(path).resolve()
    dest.parent.mkdir(parents=True, exist_ok=True)
    sources = {Path(ds.info.source_path).resolve() for ds in state.datasets if ds.info.source_path}
    if dest in sources:
        raise ValueError('Choose a new project file, not an original input file.')
    handle, tmp_path = tempfile.mkstemp(prefix='.oneclick_', suffix='.ocdt.tmp', dir=dest.parent)
    os.close(handle)
    try:
        with tempfile.TemporaryDirectory(prefix='oneclick_save_') as td:
            scratch = Path(td)
            manifest = {'schema_version': PROJECT_SCHEMA,
                        'active_index': (state.datasets.index(state.current)
                                         if state.current in state.datasets else -1),
                        'missing_tokens': list(state.missing_tokens), 'datasets': []}
            with zipfile.ZipFile(tmp_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as z:
                for i, ds in enumerate(state.datasets):
                    prefix = f'datasets/{i}'
                    names = []
                    for j, table in enumerate(ds.stack):
                        arcname = f'{prefix}/version_{j}.parquet'
                        file = scratch / f'{i}_{j}.parquet'
                        _snapshot(state.engine, table, file)
                        z.write(file, arcname)
                        names.append(arcname)
                        file.unlink()
                    if ds.original in ds.stack:
                        original = names[ds.stack.index(ds.original)]
                    else:
                        original = f'{prefix}/original.parquet'
                        file = scratch / f'{i}_original.parquet'
                        _snapshot(state.engine, ds.original, file)
                        z.write(file, original)
                        file.unlink()
                    manifest['datasets'].append({
                        'name': ds.name, 'info': asdict(ds.info), 'versions': names,
                        'original': original, 'pos': ds.pos, 'version': ds.version,
                        'history': ds.history.to_dicts(),
                    })
                z.writestr('project.json', json.dumps(manifest, ensure_ascii=False, default=str))
        os.replace(tmp_path, dest)
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)


def load_project(engine, path: str):
    """Return (datasets, active_index, missing_tokens); caller installs state on GUI thread."""
    result: list[Dataset] = []
    made_tables: list[str] = []
    try:
        with zipfile.ZipFile(path) as z, tempfile.TemporaryDirectory(prefix='oneclick_load_') as td:
            info = z.getinfo('project.json')
            if info.file_size > MAX_MANIFEST_BYTES:
                raise ValueError('Project metadata is unexpectedly large.')
            manifest = json.loads(z.read('project.json'))
            if manifest.get('schema_version') != PROJECT_SCHEMA:
                raise ValueError('Unsupported OneClick project format/version.')
            for i, entry in enumerate(manifest['datasets']):
                arcs = entry['versions']
                if not arcs or not (0 <= int(entry['pos']) < len(arcs)):
                    raise ValueError(f'Project dataset {i} has invalid version history.')
                table_by_arc = {}
                # Use a controlled local filename instead of extracting arbitrary archive paths.
                for j, arc in enumerate(dict.fromkeys([*arcs, entry['original']])):
                    if not arc.startswith(f'datasets/{i}/') or not arc.endswith('.parquet'):
                        raise ValueError('Unexpected data file location in the project.')
                    member = z.getinfo(arc)
                    if member.file_size > 15 * 1024**3:
                        raise ValueError('Project data exceeds the supported file size limit.')
                    local = Path(td) / f'{i}_{j}.parquet'
                    with z.open(member) as src, local.open('wb') as dst:
                        shutil.copyfileobj(src, dst, length=1024 * 1024)
                    table = engine.new_table_name('saved')
                    engine.execute(f'CREATE TABLE {quote_ident(table)} AS SELECT * FROM read_parquet({_lit(str(local))})')
                    made_tables.append(table)
                    protect_reserved_names(engine, table)
                    table_by_arc[arc] = table
                    local.unlink()
                ds = Dataset(engine, entry['name'], DatasetInfo(**entry['info']), table_by_arc[entry['original']])
                ds.stack = [table_by_arc[arc] for arc in arcs]
                ds.pos = int(entry['pos'])
                ds.version = int(entry.get('version', 0))
                ds.history.entries = [HistoryEntry(**item) for item in entry.get('history', [])]
                result.append(ds)
            idx = int(manifest.get('active_index', -1))
            if idx >= len(result) or idx < -1:
                idx = len(result) - 1
            return result, idx, manifest.get('missing_tokens')
    except Exception:
        for table in made_tables:
            engine.drop_table(table)
        raise
