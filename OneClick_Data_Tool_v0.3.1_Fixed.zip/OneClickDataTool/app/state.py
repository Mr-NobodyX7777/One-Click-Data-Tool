"""Shared application state (engine, datasets, cached audits)."""
from __future__ import annotations

from PySide6.QtCore import QObject, Signal

from auditor.auditor import DEFAULT_MISSING_TOKENS, AuditResult
from data.dataset import Dataset
from data.duckdb_manager import Engine


class AppState(QObject):
    datasets_changed = Signal()        # a dataset was added/closed/renamed
    current_changed = Signal(object)   # the selected dataset changed (or None)
    data_changed = Signal(object)      # the data of a dataset changed (clean/undo/redo)
    audit_ready = Signal(object)       # an AuditResult is available for the current dataset

    def __init__(self):
        super().__init__()
        self.engine = Engine()
        self.datasets: list[Dataset] = []
        self.current: Dataset | None = None
        self.audits: dict[int, tuple[int, AuditResult]] = {}
        self.missing_tokens = list(DEFAULT_MISSING_TOKENS)

    def add_dataset(self, ds: Dataset) -> None:
        self.datasets.append(ds)
        self.datasets_changed.emit()
        self.set_current(ds)

    def set_current(self, ds: Dataset | None) -> None:
        self.current = ds
        self.current_changed.emit(ds)

    def close_dataset(self, ds: Dataset) -> None:
        self.datasets.remove(ds)
        self.audits.pop(ds.id, None)
        ds.close()
        self.datasets_changed.emit()
        self.set_current(self.datasets[-1] if self.datasets else None)

    def audit_for(self, ds: Dataset | None) -> AuditResult | None:
        if ds is None:
            return None
        hit = self.audits.get(ds.id)
        return hit[1] if hit and hit[0] == ds.version else None

    def store_audit(self, ds: Dataset, version: int, result: AuditResult) -> None:
        self.audits[ds.id] = (version, result)
        if ds is self.current and version == ds.version:
            self.audit_ready.emit(result)

    def shutdown(self) -> None:
        self.engine.close()
