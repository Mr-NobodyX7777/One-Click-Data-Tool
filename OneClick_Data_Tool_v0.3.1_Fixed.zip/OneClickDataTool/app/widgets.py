"""Reusable widgets: cards, the virtualised data grid and a few helpers."""
from __future__ import annotations

import datetime as dt
from collections import OrderedDict
from decimal import Decimal

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt, Signal
from PySide6.QtGui import QColor, QFont, QGuiApplication, QKeySequence
from PySide6.QtWidgets import (QAbstractItemView, QFrame, QHeaderView, QLabel, QSizePolicy,
                               QTableView, QVBoxLayout, QWidget)

from data.duckdb_manager import Engine
from data.types import friendly_type, quote_ident, type_kind

NULL_TEXT = "NULL"


def fmt_int(n) -> str:
    return f"{int(n):,}"


def fmt_bytes(n: int | None) -> str:
    if n is None:
        return "-"
    size = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if size < 1024 or unit == "TB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return "-"


def fmt_value(v) -> str:
    """Compact, locale-neutral text for a statistic value."""
    if v is None:
        return ""
    if isinstance(v, float):
        if v != v:
            return "NaN"
        return f"{v:,.4g}" if abs(v) < 1e6 else f"{v:,.0f}"
    if isinstance(v, int):
        return f"{v:,}"
    return str(v)


class Card(QFrame):
    clicked = Signal()

    def __init__(self, title: str, clickable: bool = False, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.setProperty("clickable", clickable)
        self._clickable = clickable
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 10, 14, 10)
        lay.setSpacing(2)
        self.title = QLabel(title)
        self.title.setObjectName("cardTitle")
        self.value = QLabel("-")
        self.value.setObjectName("cardValue")
        self.note = QLabel("")
        self.note.setObjectName("cardNote")
        self.note.setWordWrap(True)
        for w in (self.title, self.value, self.note):
            lay.addWidget(w)
        if clickable:
            self.setCursor(Qt.PointingHandCursor)
            self.setFocusPolicy(Qt.StrongFocus)
            self.setToolTip("Click to open")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        self.setAccessibleName(title)

    def set(self, value: str, note: str = "") -> None:
        self.value.setText(value)
        self.note.setText(note)
        self.setAccessibleDescription(f"{value}. {note}")

    def mouseReleaseEvent(self, e):
        if self._clickable and e.button() == Qt.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(e)

    def keyPressEvent(self, e):
        if self._clickable and e.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.clicked.emit()
        else:
            super().keyPressEvent(e)


def heading(text: str, level: str = "h1") -> QLabel:
    lb = QLabel(text)
    lb.setObjectName(level)
    return lb


def muted(text: str) -> QLabel:
    lb = QLabel(text)
    lb.setObjectName("muted")
    lb.setWordWrap(True)
    return lb


# ---------------------------------------------------------------------------------------------------
class DatasetTableModel(QAbstractTableModel):
    """Lazy, block-cached view of a DuckDB table. Only the rows on screen are ever fetched,
    so a 10-million-row table costs the same to display as a 100-row one."""

    BLOCK = 200
    MAX_CACHED_BLOCKS = 60
    SORT_LIMIT = 2_000_000  # sorting happens inside DuckDB; refuse on huge tables to keep the GUI responsive

    def __init__(self, engine: Engine | None = None, table: str | None = None, parent=None):
        super().__init__(parent)
        self.engine: Engine | None = None
        self.table = ""
        self.columns: list[tuple[str, str]] = []
        self._rows = 0
        self._cache: OrderedDict[int, list[tuple]] = OrderedDict()
        self._sort: tuple[int, Qt.SortOrder] | None = None
        if engine and table:
            self.set_source(engine, table)

    def set_source(self, engine: Engine | None, table: str | None) -> None:
        self.beginResetModel()
        self.engine, self.table = engine, table or ""
        self._cache.clear()
        self._sort = None
        if engine and table:
            self.columns = engine.schema(table)
            self._rows = engine.row_count(table)
        else:
            self.columns, self._rows = [], 0
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else self._rows

    def columnCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.columns)

    def _block(self, b: int) -> list[tuple]:
        if b in self._cache:
            self._cache.move_to_end(b)
            return self._cache[b]
        order = "rowid"
        if self._sort is not None:
            col = quote_ident(self.columns[self._sort[0]][0])
            direction = "ASC" if self._sort[1] == Qt.AscendingOrder else "DESC"
            order = f"{col} {direction} NULLS LAST, rowid"
        rows = self.engine.fetchall(
            f"SELECT * FROM {quote_ident(self.table)} ORDER BY {order} "
            f"LIMIT {self.BLOCK} OFFSET {b * self.BLOCK}")
        self._cache[b] = rows
        while len(self._cache) > self.MAX_CACHED_BLOCKS:
            self._cache.popitem(last=False)
        return rows

    def raw(self, row: int, col: int):
        rows = self._block(row // self.BLOCK)
        i = row % self.BLOCK
        return rows[i][col] if i < len(rows) else None

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or self.engine is None:
            return None
        v = self.raw(index.row(), index.column())
        dtype = self.columns[index.column()][1]
        if role == Qt.DisplayRole:
            return _display(v)
        if role == Qt.ForegroundRole and _is_missing(v, dtype):
            return QColor("#8a94a0")
        if role == Qt.FontRole and _is_missing(v, dtype):
            f = QFont()
            f.setItalic(True)
            return f
        if role == Qt.TextAlignmentRole and type_kind(dtype) == "numeric" and v is not None:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        if role == Qt.ToolTipRole and v is not None and not isinstance(v, str):
            return str(v)
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole:
            if orientation == Qt.Horizontal:
                n, t = self.columns[section]
                return f"{n}\n{friendly_type(t)}"
            return f"{section + 1:,}"
        if role == Qt.ToolTipRole and orientation == Qt.Horizontal:
            n, t = self.columns[section]
            return f"{n} ({t})"
        return None

    def sort(self, column: int, order=Qt.AscendingOrder):
        if self.engine is None or column < 0:
            return
        if self._rows > self.SORT_LIMIT:
            return
        self.layoutAboutToBeChanged.emit()
        self._sort = (column, order)
        self._cache.clear()
        self.layoutChanged.emit()

    def selection_text(self, indexes) -> str:
        if not indexes:
            return ""
        rows = sorted({i.row() for i in indexes})
        cols = sorted({i.column() for i in indexes})
        picked = {(i.row(), i.column()) for i in indexes}
        lines = []
        for r in rows:
            lines.append("\t".join(_display(self.raw(r, c)) if (r, c) in picked else "" for c in cols))
        return "\n".join(lines)


def _is_missing(v, dtype: str) -> bool:
    if v is None:
        return True
    if isinstance(v, str):
        return v.strip() == ""
    return isinstance(v, float) and v != v


def _display(v) -> str:
    if v is None:
        return NULL_TEXT
    if isinstance(v, str):
        return "(blank)" if v.strip() == "" else v
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        return "NaN" if v != v else f"{v:.10g}"
    if isinstance(v, (dt.datetime, dt.date, dt.time, Decimal, int)):
        return str(v)
    return str(v)


class DataGrid(QTableView):
    """Virtualised grid with row numbers, typed headers, sorting and Ctrl+C copy."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.model_ = DatasetTableModel(parent=self)
        self.setModel(self.model_)
        self.setAlternatingRowColors(True)
        self.setSortingEnabled(True)
        self.setSelectionBehavior(QAbstractItemView.SelectItems)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.horizontalHeader().setDefaultSectionSize(140)
        self.horizontalHeader().setMinimumSectionSize(60)
        self.horizontalHeader().setDefaultAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.verticalHeader().setSectionResizeMode(QHeaderView.Fixed)
        self.verticalHeader().setDefaultSectionSize(26)
        self.setWordWrap(False)
        self.setAccessibleName("Data preview grid")

    def show_table(self, engine: Engine | None, table: str | None) -> None:
        self.horizontalHeader().setSortIndicator(-1, Qt.AscendingOrder)
        self.model_.set_source(engine, table)
        self.horizontalHeader().setFixedHeight(48)
        if self.model_._rows > DatasetTableModel.SORT_LIMIT:
            self.setSortingEnabled(False)
            self.setToolTip("Sorting is disabled for very large tables to keep the app responsive.")
        else:
            self.setSortingEnabled(True)
            self.setToolTip("")

    def keyPressEvent(self, e):
        if e.matches(QKeySequence.Copy):
            QGuiApplication.clipboard().setText(self.model_.selection_text(self.selectedIndexes()))
        else:
            super().keyPressEvent(e)


def simple_table(headers: list[str], rows: list[list], sortable: bool = True):
    """Small read-only QTableWidget populated from python lists."""
    from PySide6.QtWidgets import QTableWidget, QTableWidgetItem
    t = QTableWidget(len(rows), len(headers))
    t.setHorizontalHeaderLabels(headers)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.setAlternatingRowColors(True)
    t.verticalHeader().setVisible(False)
    for r, row in enumerate(rows):
        for c, v in enumerate(row):
            item = QTableWidgetItem(str(v))
            t.setItem(r, c, item)
    t.horizontalHeader().setStretchLastSection(True)
    t.setSortingEnabled(sortable)
    return t
