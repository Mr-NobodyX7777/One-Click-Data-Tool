from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QComboBox, QFormLayout, QGroupBox, QHBoxLayout, QLabel, QListWidget,
                               QListWidgetItem, QPushButton, QSpinBox, QStackedWidget, QVBoxLayout, QWidget)

from app.state import AppState
from app.widgets import heading, muted
from data.types import type_kind
from visualizer.validation import CHARTS, ChartSpec


class VizPage(QWidget):
    generate_requested = Signal(object)   # ChartSpec
    export_png_requested = Signal()

    def __init__(self, state: AppState):
        super().__init__()
        self.setObjectName("page")
        self.state = state
        self.figure = None
        self._recs = []
        lay = QHBoxLayout(self)
        lay.setContentsMargins(24, 20, 24, 16)
        lay.setSpacing(14)

        left = QVBoxLayout()
        left.addWidget(heading("Visualizer"))
        self.reco_box = QGroupBox("Recommended charts")
        rl = QVBoxLayout(self.reco_box)
        self.reco = QListWidget()
        self.reco.setWordWrap(True)
        self.reco.setMinimumHeight(150)
        self.reco.setAccessibleName("Recommended charts")
        self.reco.itemActivated.connect(self._pick_reco)
        self.reco.itemClicked.connect(self._pick_reco)
        rl.addWidget(self.reco)
        left.addWidget(self.reco_box, 2)

        box = QGroupBox("Chart")
        form = QFormLayout(box)
        self.kind = QComboBox()
        for k, cd in CHARTS.items():
            self.kind.addItem(cd.title, k)
        self.x = QComboBox()
        self.y = QComboBox()
        self.lx, self.ly = QLabel(), QLabel()
        self.agg = QComboBox()
        for a in ("count", "mean", "sum", "median", "min", "max"):
            self.agg.addItem(a.title(), a)
        self.agg.setCurrentIndex(1)
        self.top = QSpinBox()
        self.top.setRange(1, 50)
        self.top.setValue(20)
        self.top.setToolTip("Maximum number of categories/groups to draw")
        self.l_agg, self.l_top = QLabel("Aggregation:"), QLabel("Top N:")
        form.addRow("Chart type:", self.kind)
        form.addRow(self.lx, self.x)
        form.addRow(self.ly, self.y)
        form.addRow(self.l_agg, self.agg)
        form.addRow(self.l_top, self.top)
        self.need = muted("")
        form.addRow(self.need)
        left.addWidget(box)
        self.gen = QPushButton("Generate chart")
        self.gen.setObjectName("primary")
        self.gen.clicked.connect(self._generate)
        self.png = QPushButton("Export PNG...")
        self.png.setEnabled(False)
        self.png.clicked.connect(self.export_png_requested)
        left.addWidget(self.gen)
        left.addWidget(self.png)
        left.addStretch(1)
        lw = QWidget()
        lw.setLayout(left)
        lw.setFixedWidth(330)
        lay.addWidget(lw)

        right = QVBoxLayout()
        self.stack = QStackedWidget()
        self.placeholder = QLabel("Pick a recommended chart or choose columns, then press Generate.")
        self.placeholder.setAlignment(Qt.AlignCenter)
        self.placeholder.setObjectName("muted")
        self.stack.addWidget(self.placeholder)
        self.canvas_holder = QVBoxLayout()
        cw = QWidget()
        cw.setLayout(self.canvas_holder)
        self.stack.addWidget(cw)
        self.problem = QLabel()
        self.problem.setWordWrap(True)
        self.problem.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.problem.setObjectName("card")
        self.problem.setMargin(20)
        self.problem.setTextFormat(Qt.PlainText)
        self.stack.addWidget(self.problem)
        right.addWidget(self.stack, 1)
        self.notes = QLabel()
        self.notes.setWordWrap(True)
        self.notes.setObjectName("muted")
        right.addWidget(self.notes)
        lay.addLayout(right, 1)

        self.kind.currentIndexChanged.connect(self._kind_changed)
        state.current_changed.connect(lambda ds: self.refresh())
        state.data_changed.connect(lambda ds: self.refresh())
        self._canvas = None
        self.refresh()

    # ----------------------------------------------------------------------------------------------
    def refresh(self) -> None:
        ds = self.state.current
        self.clear_chart()
        self.x.blockSignals(True)
        self.y.blockSignals(True)
        self._cols = ds.columns() if ds else []
        self.x.blockSignals(False)
        self.y.blockSignals(False)
        self._kind_changed()
        self.gen.setEnabled(ds is not None)
        self.reco.clear()
        self._recs = []

    def set_recommendations(self, recs) -> None:
        self._recs = recs
        self.reco.clear()
        if not recs:
            self.reco.addItem("No chart could be recommended for this data.")
            return
        for r in recs:
            it = QListWidgetItem(f"{r.title}\n{r.reason}")
            it.setData(Qt.UserRole, r.spec)
            self.reco.addItem(it)

    def _kind_changed(self) -> None:
        cd = CHARTS[self.kind.currentData()]
        self.lx.setText(cd.x.label + ":")
        self._fill(self.x, cd.x.kinds, optional=not cd.x.required)
        has_y = cd.y is not None
        for w in (self.ly, self.y):
            w.setVisible(has_y)
        if has_y:
            self.ly.setText(cd.y.label + ":")
            self._fill(self.y, cd.y.kinds, optional=not cd.y.required)
        for w in (self.agg, self.l_agg):
            w.setVisible(cd.uses_agg)
        for w in (self.top, self.l_top):
            w.setVisible(cd.key in ("bar", "box"))
        self.need.setText("Needs: " + cd.needs)

    def _fill(self, combo: QComboBox, kinds, optional: bool) -> None:
        prev = combo.currentData()
        combo.clear()
        if optional:
            combo.addItem("(none)", None)
        for name, t in getattr(self, "_cols", []):
            if type_kind(t) in kinds:
                combo.addItem(f"{name}  [{t}]", name)
        if prev is not None:
            i = combo.findData(prev)
            if i >= 0:
                combo.setCurrentIndex(i)

    def current_spec(self) -> ChartSpec:
        return ChartSpec(self.kind.currentData(), self.x.currentData(),
                         self.y.currentData() if self.y.isVisible() else None,
                         agg=self.agg.currentData(), top_n=self.top.value())

    def _pick_reco(self, item) -> None:
        spec = item.data(Qt.UserRole)
        if spec is None:
            return
        self.kind.setCurrentIndex(self.kind.findData(spec.kind))
        self._kind_changed()
        self.x.setCurrentIndex(max(0, self.x.findData(spec.x)))
        if spec.y:
            self.y.setCurrentIndex(max(0, self.y.findData(spec.y)))
        i = self.agg.findData(spec.agg)
        if i >= 0:
            self.agg.setCurrentIndex(i)
        self._generate()

    def _generate(self) -> None:
        self.generate_requested.emit(self.current_spec())

    # -- results -----------------------------------------------------------------------------------
    def clear_chart(self) -> None:
        self.figure = None
        self.png.setEnabled(False)
        if self._canvas is not None:
            self.canvas_holder.removeWidget(self._canvas)
            self._canvas.deleteLater()
            self._canvas = None
        self.stack.setCurrentIndex(0)
        self.notes.setText("")

    def show_figure(self, fig, plot) -> None:
        from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg, NavigationToolbar2QT
        self.clear_chart()
        self.figure = fig
        canvas = FigureCanvasQTAgg(fig)
        wrap = QWidget()
        wl = QVBoxLayout(wrap)
        wl.setContentsMargins(0, 0, 0, 0)
        nav = NavigationToolbar2QT(canvas, wrap)
        nav.hide()  # matplotlib's own icon bar is hard to see/understand; we drive it with labelled buttons
        bar = QHBoxLayout()
        bar.addWidget(QLabel("Explore chart:"))
        zoom = QPushButton("Zoom")
        zoom.setCheckable(True)
        zoom.setToolTip("Click, then drag a rectangle on the chart to zoom into that area")
        pan = QPushButton("Move")
        pan.setCheckable(True)
        pan.setToolTip("Click, then drag the chart to move around (right-drag to zoom)")
        home = QPushButton("Reset view")
        home.setToolTip("Return to the full chart")

        def toggle(which):
            def f(on):
                other = pan if which == "zoom" else zoom
                if on:
                    other.setChecked(False)
                (nav.zoom if which == "zoom" else nav.pan)()
            return f
        zoom.toggled.connect(toggle("zoom"))
        pan.toggled.connect(toggle("pan"))
        home.clicked.connect(lambda: (zoom.setChecked(False), pan.setChecked(False), nav.home()))
        for b in (zoom, pan, home):
            bar.addWidget(b)
        bar.addStretch()
        wl.addLayout(bar)
        wl.addWidget(canvas, 1)
        self._canvas = wrap
        self.canvas_holder.addWidget(wrap)
        self.stack.setCurrentIndex(1)
        self.png.setEnabled(True)
        self.notes.setText("  ".join(["Note: " + n for n in plot.notes] + ["Warning: " + w for w in plot.warnings]))

    def show_problem(self, plot) -> None:
        self.clear_chart()
        cd = CHARTS.get(plot.spec.kind)
        text = "This chart cannot be drawn with the current selection.\n\n"
        text += "\n".join("- " + e for e in plot.errors)
        if cd:
            text += f"\n\nWhat a {cd.title.lower()} needs: {cd.needs}"
        self.problem.setText(text)
        self.stack.setCurrentIndex(2)
