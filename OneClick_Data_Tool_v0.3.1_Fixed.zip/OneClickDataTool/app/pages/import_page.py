from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (QFrame, QGridLayout, QHBoxLayout, QLabel, QPushButton, QStackedWidget,
                               QVBoxLayout, QWidget)

from app.state import AppState
from app.widgets import Card, DataGrid, fmt_bytes, fmt_int, heading, muted
from data.connectors import REGISTRY


class ImportPage(QWidget):
    open_requested = Signal()
    sample_requested = Signal()
    go_to = Signal(str)  # "audit" | "clean" | "viz"

    def __init__(self, state: AppState):
        super().__init__()
        self.setObjectName("page")
        self.state = state
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 20, 24, 16)
        self.stack = QStackedWidget()
        outer.addWidget(self.stack)
        self.stack.addWidget(self._empty_state())
        self.stack.addWidget(self._overview())
        state.current_changed.connect(self.refresh)
        state.data_changed.connect(lambda ds: self.refresh(ds))
        state.audit_ready.connect(self.show_audit)
        self.refresh(None)

    # -- empty / first-run state -----------------------------------------------------------------------
    def _empty_state(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.addStretch(1)
        box = QFrame()
        box.setObjectName("card")
        box.setMaximumWidth(640)
        bl = QVBoxLayout(box)
        bl.setContentsMargins(32, 28, 32, 28)
        bl.setSpacing(10)
        t = heading("Welcome to OneClick Data Tool")
        bl.addWidget(t)
        bl.addWidget(muted("Import -> Understand -> Clean -> Visualize -> Export.\n"
                           "Everything runs on this computer. Your data never leaves it."))
        drop = QLabel("Drag a file here, or choose one below")
        drop.setAlignment(Qt.AlignCenter)
        drop.setMinimumHeight(90)
        drop.setStyleSheet("border: 2px dashed #8a94a0; border-radius: 8px; padding: 16px;")
        bl.addWidget(drop)
        row = QHBoxLayout()
        b1 = QPushButton("Open File...")
        b1.setObjectName("primary")
        b1.setToolTip("Import a CSV, Excel, JSON, Parquet or SQLite file (Ctrl+O)")
        b1.clicked.connect(self.open_requested)
        b2 = QPushButton("Load Sample Dataset")
        b2.setToolTip("A built-in demo dataset with missing values, duplicates and outliers")
        b2.clicked.connect(self.sample_requested)
        row.addWidget(b1)
        row.addWidget(b2)
        row.addStretch()
        bl.addLayout(row)
        exts = sorted({e for c in REGISTRY.values() for e in c.extensions})
        bl.addWidget(muted("Supported formats: " + ", ".join(exts)))
        hl = QHBoxLayout()
        hl.addStretch()
        hl.addWidget(box)
        hl.addStretch()
        lay.addLayout(hl)
        lay.addStretch(2)
        return w

    # -- overview / dashboard ----------------------------------------------------------------------------
    def _overview(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(12)
        top = QHBoxLayout()
        self.title = heading("Dataset")
        top.addWidget(self.title)
        top.addStretch()
        self.btn_open = QPushButton("Open Another File...")
        self.btn_open.clicked.connect(self.open_requested)
        top.addWidget(self.btn_open)
        lay.addLayout(top)

        self.notice = QLabel()
        self.notice.setObjectName("banner")
        self.notice.setWordWrap(True)
        self.notice.hide()
        lay.addWidget(self.notice)

        grid = QGridLayout()
        grid.setSpacing(10)
        self.cards = {
            "rows": Card("Rows"), "cols": Card("Columns"), "size": Card("File size"),
            "health": Card("Data health", True), "missing": Card("Missing values", True),
            "dups": Card("Duplicate rows", True), "problems": Card("Problem columns", True),
        }
        for i, key in enumerate(("rows", "cols", "size", "health", "missing", "dups", "problems")):
            grid.addWidget(self.cards[key], i // 4, i % 4)
        for k in ("health", "missing", "problems"):
            self.cards[k].clicked.connect(lambda: self.go_to.emit("audit"))
        self.cards["dups"].clicked.connect(lambda: self.go_to.emit("clean"))
        lay.addLayout(grid)

        self.info_line = QLabel()
        self.info_line.setObjectName("muted")
        self.info_line.setWordWrap(True)
        lay.addWidget(self.info_line)

        btns = QHBoxLayout()
        for text, target, primary in (("Audit Dataset", "audit", True), ("Clean Dataset", "clean", False),
                                      ("Visualize Data", "viz", False)):
            b = QPushButton(text)
            if primary:
                b.setObjectName("primary")
            b.clicked.connect(lambda _=False, t=target: self.go_to.emit(t))
            btns.addWidget(b)
        btns.addStretch()
        lay.addLayout(btns)

        lay.addWidget(heading("Data preview", "h2"))
        lay.addWidget(muted("Only the rows you scroll to are loaded, so large datasets stay fast. "
                            "Click a column header to sort. Ctrl+C copies the selection."))
        self.grid = DataGrid()
        lay.addWidget(self.grid, 1)
        return w

    # -- updates -------------------------------------------------------------------------------------
    def refresh(self, ds) -> None:
        if ds is None:
            self.stack.setCurrentIndex(0)
            return
        self.stack.setCurrentIndex(1)
        i = ds.info
        self.title.setText(ds.name)
        cols = ds.columns()
        rows = ds.row_count()
        self.cards["rows"].set(fmt_int(rows), f"{fmt_int(ds.original_rows)} originally" if ds.is_modified else "")
        self.cards["cols"].set(fmt_int(len(cols)))
        self.cards["size"].set(fmt_bytes(i.file_size) if i.file_size is not None else "n/a",
                               "" if i.file_size is not None else "built-in data")
        detail = f"   |   {'Sheet' if i.format == 'Excel' else 'Table'}: {i.detail}" if i.detail else ""
        self.info_line.setText(f"Source: {i.source_name}   |   Format: {i.format}{detail}   |   "
                               f"Storage: {i.storage}")
        if i.warnings:
            self.notice.setText("Notice: " + "  ".join(i.warnings))
            self.notice.show()
        else:
            self.notice.hide()
        self.grid.show_table(self.state.engine, ds.current)
        audit = self.state.audit_for(ds)
        if audit:
            self.show_audit(audit)
        else:
            for k in ("health", "missing", "dups", "problems"):
                self.cards[k].set("...", "auditing")

    def show_audit(self, a) -> None:
        h = a.health.score
        word = "Good" if h >= 85 else "Fair" if h >= 65 else "Needs attention"
        self.cards["health"].set(f"{h} / 100", word)
        self.cards["missing"].set(f"{a.missing_pct:.1f}%", f"{a.missing_cells:,} of {a.total_cells:,} cells")
        self.cards["dups"].set(fmt_int(a.duplicates), "exact duplicate rows" if a.duplicates else "none found")
        n = len(a.problem_columns)
        self.cards["problems"].set(f"{n} of {len(a.columns)}", "see Auditor for details" if n else "all columns healthy")
