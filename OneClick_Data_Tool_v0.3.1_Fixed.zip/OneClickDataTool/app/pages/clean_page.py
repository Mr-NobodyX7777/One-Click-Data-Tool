from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QButtonGroup, QComboBox, QGroupBox, QHBoxLayout, QHeaderView,
                               QLabel, QLineEdit, QPushButton, QRadioButton, QScrollArea, QSplitter, QTableWidget,
                               QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

from app.state import AppState
from app.widgets import fmt_int, fmt_value, heading, muted
from auditor.recommendations import ACTIONS
from cleaner.operations import plan_drop_missing, plan_fill_missing, plan_remove_duplicates


def _scroll(widget: QWidget) -> QScrollArea:
    """Wrap a widget so it scrolls (vertically and horizontally) instead of being squeezed."""
    sa = QScrollArea()
    sa.setWidgetResizable(True)
    sa.setFrameShape(QScrollArea.NoFrame)
    sa.setWidget(widget)
    return sa


class CleanPage(QWidget):
    plan_requested = Signal(object)   # callable(engine, table) -> OperationPlan
    undo_requested = Signal()
    redo_requested = Signal()
    reset_requested = Signal()
    export_history = Signal(str)      # "json" | "csv"
    refresh_requested = Signal()

    def __init__(self, state: AppState):
        super().__init__()
        self.setObjectName("page")
        self.state = state
        self.audit = None
        self._issues: list = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 20, 24, 16)
        lay.setSpacing(10)
        top = QHBoxLayout()
        top.addWidget(heading("Cleaner"))
        top.addStretch()
        self.btn_update = QPushButton("Update (F5)")
        self.btn_update.setToolTip("Re-scan the current data and refresh this page and the Auditor")
        self.btn_update.clicked.connect(self.refresh_requested)
        top.addWidget(self.btn_update)
        self.btn_undo = QPushButton("Undo")
        self.btn_redo = QPushButton("Redo")
        self.btn_reset = QPushButton("Reset to original...")
        self.btn_undo.setToolTip("Undo the last change (Ctrl+Z)")
        self.btn_redo.setToolTip("Redo (Ctrl+Y)")
        self.btn_reset.setToolTip("Discard all changes and return to the imported data. The original file is never modified.")
        self.btn_undo.clicked.connect(self.undo_requested)
        self.btn_redo.clicked.connect(self.redo_requested)
        self.btn_reset.clicked.connect(self.reset_requested)
        for b in (self.btn_undo, self.btn_redo, self.btn_reset):
            top.addWidget(b)
        lay.addLayout(top)
        self.state_label = muted("")
        lay.addWidget(self.state_label)
        self.empty = muted("Import a dataset first.")
        lay.addWidget(self.empty)

        self.body = QSplitter(Qt.Vertical)
        upper = QSplitter(Qt.Horizontal)
        # --- left: issues + duplicates
        left = QWidget()
        ll = QVBoxLayout(left)
        ll.setContentsMargins(0, 0, 0, 0)
        ll.addWidget(heading("Columns with missing values", "h2"))
        self.issues = QTableWidget(0, 5)
        self.issues.setHorizontalHeaderLabels(["Column", "Type", "Missing", "Missing %", "Suggested action"])
        self.issues.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.issues.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.issues.setSelectionMode(QAbstractItemView.SingleSelection)
        self.issues.setAlternatingRowColors(True)
        self.issues.verticalHeader().setVisible(False)
        self.issues.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.issues.setMinimumHeight(220)
        self.issues.setAccessibleName("Columns with missing values")
        self.issues.itemSelectionChanged.connect(self._issue_selected)
        ll.addWidget(self.issues, 1)
        dup = QGroupBox("Duplicate rows")
        dl = QHBoxLayout(dup)
        self.dup_label = QLabel("")
        self.dup_btn = QPushButton("Remove All Duplicates...")
        self.dup_btn.clicked.connect(lambda: self.plan_requested.emit(
            lambda eng, tbl: plan_remove_duplicates(eng, tbl)))
        dl.addWidget(self.dup_label, 1)
        dl.addWidget(self.dup_btn)
        ll.addWidget(dup)
        upper.addWidget(_scroll(left))

        # --- right: detail + action
        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)
        self.col_title = heading("Select a column", "h2")
        rl.addWidget(self.col_title)
        self.evidence = QLabel("")
        self.evidence.setWordWrap(True)
        self.evidence.setTextInteractionFlags(Qt.TextSelectableByMouse)
        rl.addWidget(self.evidence)
        self.reco = QLabel("")
        self.reco.setObjectName("banner")
        self.reco.setWordWrap(True)
        rl.addWidget(self.reco)
        self.levels = QTabWidget()
        self.lv_quick, self.lv_detail, self.lv_method = QLabel(), QLabel(), QLabel()
        for lb, name in ((self.lv_quick, "Quick"), (self.lv_detail, "Detailed"), (self.lv_method, "Methodology")):
            lb.setWordWrap(True)
            lb.setAlignment(Qt.AlignTop | Qt.AlignLeft)
            lb.setMargin(8)
            lb.setTextInteractionFlags(Qt.TextSelectableByMouse)
            self.levels.addTab(_scroll(lb), name)
        self.levels.setMinimumHeight(150)
        rl.addWidget(self.levels)

        act = QGroupBox("Choose an action (you can override the suggestion)")
        al = QVBoxLayout(act)
        self.group = QButtonGroup(self)
        self.radios: dict[str, QRadioButton] = {}
        for key in ("drop", "mean", "median", "custom"):
            rb = QRadioButton(ACTIONS[key])
            self.radios[key] = rb
            self.group.addButton(rb)
            al.addWidget(rb)
            rb.toggled.connect(self._action_changed)
        self.num_hint = QLabel("")
        self.num_hint.setObjectName("muted")
        self.num_hint.setWordWrap(True)
        al.addWidget(self.num_hint)
        scope = QHBoxLayout()
        scope.addSpacing(24)
        scope.addWidget(QLabel("Drop rows missing a value in:"))
        self.scope = QComboBox()
        self.scope.addItem("this column", "column")
        self.scope.addItem("any column", "any")
        scope.addWidget(self.scope)
        scope.addStretch()
        al.addLayout(scope)
        cv = QHBoxLayout()
        cv.addSpacing(24)
        cv.addWidget(QLabel("Custom value:"))
        self.custom = QLineEdit()
        self.custom.setAccessibleName("Custom fill value")
        cv.addWidget(self.custom, 1)
        al.addLayout(cv)
        self.error = QLabel("")
        self.error.setObjectName("error")
        self.error.setWordWrap(True)
        al.addWidget(self.error)
        self.apply_btn = QPushButton("Review impact and apply...")
        self.apply_btn.setObjectName("primary")
        self.apply_btn.setMinimumHeight(36)
        self.apply_btn.clicked.connect(self._apply)
        al.addWidget(self.apply_btn)
        act.setMinimumHeight(290)
        rl.addWidget(act)
        rl.addStretch(1)
        upper.addWidget(_scroll(right))
        upper.setStretchFactor(0, 1)
        upper.setStretchFactor(1, 1)
        self.body.addWidget(upper)

        # --- history
        hist = QWidget()
        hl = QVBoxLayout(hist)
        hl.setContentsMargins(0, 0, 0, 0)
        hh = QHBoxLayout()
        hh.addWidget(heading("Cleaning history", "h2"))
        hh.addStretch()
        for label, fmt in (("Export JSON", "json"), ("Export CSV", "csv")):
            b = QPushButton(label)
            b.clicked.connect(lambda _=False, f=fmt: self.export_history.emit(f))
            hh.addWidget(b)
        hl.addLayout(hh)
        self.history = QTableWidget(0, 7)
        self.history.setHorizontalHeaderLabels(["Time", "Action", "Column", "Affected", "Rows before", "Rows after", "Status"])
        self.history.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.history.setAlternatingRowColors(True)
        self.history.verticalHeader().setVisible(False)
        self.history.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.history.setAccessibleName("Cleaning history")
        hl.addWidget(self.history)
        self.body.addWidget(hist)
        self.body.setStretchFactor(0, 4)
        self.body.setStretchFactor(1, 1)
        self.body.setSizes([560, 150])
        self.body.setChildrenCollapsible(False)
        lay.addWidget(self.body, 1)
        self.body.hide()

        state.current_changed.connect(lambda ds: self.refresh())
        state.audit_ready.connect(lambda a: self.refresh())
        state.data_changed.connect(lambda ds: self.refresh())
        self.refresh()

    # ----------------------------------------------------------------------------------------------
    def refresh(self) -> None:
        ds = self.state.current
        self.empty.setVisible(ds is None)
        self.body.setVisible(ds is not None)
        for b in (self.btn_undo, self.btn_redo, self.btn_reset):
            b.setEnabled(ds is not None)
        if ds is None:
            self.state_label.setText("")
            return
        self.btn_undo.setEnabled(ds.can_undo)
        self.btn_redo.setEnabled(ds.can_redo)
        self.btn_reset.setEnabled(ds.is_modified)
        steps = len(ds.history.applied())
        self.state_label.setText(
            f"{ds.name}: {fmt_int(ds.row_count())} rows now ({fmt_int(ds.original_rows)} originally) - "
            + ("original data, no changes yet." if not ds.is_modified else
               f"{steps} change(s) applied. The original file is untouched."))
        self.audit = self.state.audit_for(ds)
        self._fill_history(ds)
        self._fill_issues()

    def _fill_history(self, ds) -> None:
        entries = ds.history.entries
        self.history.setRowCount(len(entries))
        for r, e in enumerate(reversed(entries)):
            vals = [e.timestamp.replace("T", " "), e.action, e.column or "(all)", f"{e.affected:,}",
                    f"{e.rows_before:,}", f"{e.rows_after:,}", e.status]
            for c, v in enumerate(vals):
                it = QTableWidgetItem(v)
                if e.status != "applied":
                    it.setForeground(QColor("#8a94a0"))
                    f = it.font()
                    f.setStrikeOut(True)
                    it.setFont(f)
                self.history.setItem(r, c, it)

    def _fill_issues(self) -> None:
        a = self.audit
        keep = self.col_title.text().removeprefix("Fill / fix: ")
        self.issues.blockSignals(True)
        self.issues.setRowCount(0)
        self._issues = []
        if a is None:
            self.dup_label.setText("Auditing...")
            self.dup_btn.setEnabled(False)
            self.issues.blockSignals(False)
            return
        self._issues = [c for c in a.columns if c.missing > 0]
        self.issues.setRowCount(len(self._issues))
        for r, p in enumerate(self._issues):
            rec = a.recommendations.get(p.name)
            for c, v in enumerate([p.name, p.duck_type, f"{p.missing:,}", f"{p.missing_pct:.1f}%",
                                   rec.label if rec else ""]):
                self.issues.setItem(r, c, QTableWidgetItem(v))
        self.dup_label.setText(f"{a.duplicates:,} duplicate row(s) found." if a.duplicates
                               else "No duplicate rows found.")
        self.dup_btn.setEnabled(a.duplicates > 0)
        self.issues.blockSignals(False)
        if not self._issues:
            self._clear_detail("No missing values found. Nothing to fill or drop.")
            return
        rows = [i for i, p in enumerate(self._issues) if p.name == keep]
        self.issues.selectRow(rows[0] if rows else 0)
        self._issue_selected()

    def _clear_detail(self, msg: str = "Select a column") -> None:
        self.col_title.setText(msg)
        for w in (self.evidence, self.reco, self.lv_quick, self.lv_detail, self.lv_method):
            w.setText("")
        self.reco.hide()
        self.apply_btn.setEnabled(False)

    def current_profile(self):
        rows = self.issues.selectionModel().selectedRows() if self.issues.selectionModel() else []
        if not rows or rows[0].row() >= len(self._issues):
            return None
        return self._issues[rows[0].row()]

    def _issue_selected(self) -> None:
        p = self.current_profile()
        if p is None or self.audit is None:
            return
        rec = self.audit.recommendations.get(p.name)
        self.col_title.setText(f"Fill / fix: {p.name}")
        ev = [f"Problem: {p.missing:,} missing value(s)   |   Missing: {p.missing_pct:.1f}%   |   Type: {p.duck_type}"]
        if p.is_numeric and p.mean is not None:
            ev.append(f"Mean: {fmt_value(p.mean)}   Median: {fmt_value(p.median)}   Skewness: {fmt_value(p.skew)}   "
                      f"IQR: {fmt_value(p.iqr)}   Outliers: {p.outliers:,} ({p.outlier_pct:.1f}%)")
        self.evidence.setText("\n".join(ev))
        if rec:
            self.reco.setText(f"Recommendation: {rec.label}\n{rec.quick}   (guidance, not a guarantee)")
            self.reco.show()
            self.lv_quick.setText(rec.quick)
            self.lv_detail.setText(rec.detailed or "-")
            self.lv_method.setText(rec.methodology)
            key = rec.action if rec.action in self.radios else None
            if key:
                self.radios[key].setChecked(True)
            else:
                self.group.setExclusive(False)
                for rb in self.radios.values():
                    rb.setChecked(False)
                self.group.setExclusive(True)
            self.custom.setText(rec.suggested_value or "")
        numeric = p.is_numeric
        self.radios["mean"].setEnabled(numeric)
        self.radios["median"].setEnabled(numeric)
        suffix = "" if numeric else "  (numeric columns only)"
        self.radios["mean"].setText(ACTIONS["mean"] + suffix)
        self.radios["median"].setText(ACTIONS["median"] + suffix)
        self.num_hint.setText("" if numeric else
                              f"Mean and Median are unavailable because '{p.name}' is {p.duck_type}, not a number. "
                              "Use Drop rows or a Custom value instead.")
        if not numeric and (self.radios["mean"].isChecked() or self.radios["median"].isChecked()):
            self.radios["custom"].setChecked(True)
        self.error.setText("")
        self._action_changed()

    def _action_changed(self, *_):
        custom = self.radios["custom"].isChecked()
        drop = self.radios["drop"].isChecked()
        self.custom.setEnabled(custom)
        self.scope.setEnabled(drop)
        self.apply_btn.setEnabled(self.current_profile() is not None and self.group.checkedButton() is not None)

    def _apply(self) -> None:
        p = self.current_profile()
        btn = self.group.checkedButton()
        if p is None or btn is None:
            return
        key = next(k for k, rb in self.radios.items() if rb is btn)
        self.error.setText("")
        name = p.name
        if key == "drop":
            cols = None if self.scope.currentData() == "any" else [name]
            self.plan_requested.emit(lambda eng, tbl: plan_drop_missing(eng, tbl, cols))
        else:
            text = self.custom.text()
            self.plan_requested.emit(lambda eng, tbl: plan_fill_missing(eng, tbl, name, key, text))

    def show_error(self, text: str) -> None:
        self.error.setText(text)
