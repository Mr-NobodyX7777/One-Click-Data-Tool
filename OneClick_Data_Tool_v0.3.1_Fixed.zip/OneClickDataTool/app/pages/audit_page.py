from __future__ import annotations

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt, Signal
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QAbstractItemView, QDialog, QDialogButtonBox, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit, QPlainTextEdit, QPushButton, QSplitter, QTableView, QVBoxLayout, QWidget)

from app.state import AppState
from app.widgets import Card, fmt_int, fmt_value, heading, muted
from auditor.auditor import AuditResult, health_methodology
from auditor.statistics import IQR_MULTIPLIER

HEADERS = ["Column", "Type", "Category", "Status", "Non-null", "Missing", "Missing %", "Unique", "Min", "Max",
           "Mean", "Median", "Std dev", "Skew", "Q1", "Q3", "IQR", "Outliers"]
NUMERIC_COLS = {4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 17}


class ColumnsModel(QAbstractTableModel):
    def __init__(self):
        super().__init__()
        self.profiles = []

    def set_profiles(self, profiles):
        self.beginResetModel()
        self.profiles = list(profiles)
        self.endResetModel()

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.profiles)

    def columnCount(self, parent=QModelIndex()):
        return len(HEADERS)

    def _raw(self, p, c):
        return [p.name, p.duck_type, p.category, "Healthy" if p.healthy else "Problem", p.non_null, p.missing,
                p.missing_pct, p.unique, p.min, p.max, p.mean, p.median, p.std, p.skew, p.q1, p.q3, p.iqr,
                p.outliers if p.is_numeric else None][c]

    def data(self, index, role=Qt.DisplayRole):
        p = self.profiles[index.row()]
        c = index.column()
        v = self._raw(p, c)
        if role == Qt.DisplayRole:
            if v is None:
                return ""
            if c == 6:
                return f"{v:.1f}%"
            if c == 3:
                return ("✓ Healthy" if p.healthy else "⚠ Problem")
            return fmt_value(v) if c in NUMERIC_COLS or c in (8, 9) else str(v)
        if role == Qt.UserRole:  # sort key
            if c in (8, 9):
                return str(v) if v is not None else ""
            return v if v is not None else float("-inf") if c in NUMERIC_COLS else ""
        if role == Qt.TextAlignmentRole and c in NUMERIC_COLS:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        if role == Qt.ForegroundRole and c == 3:
            return QColor("#34b878" if p.healthy else "#f2706a")
        if role == Qt.ToolTipRole and c == 3:
            return "; ".join(p.issues) or "No issues found"
        return None

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return HEADERS[section]
        return None


class TextDialog(QDialog):
    def __init__(self, title: str, text: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(640, 460)
        lay = QVBoxLayout(self)
        box = QPlainTextEdit(text)
        box.setReadOnly(True)
        lay.addWidget(box)
        bb = QDialogButtonBox(QDialogButtonBox.Close)
        bb.rejected.connect(self.reject)
        lay.addWidget(bb)


class AuditPage(QWidget):
    go_to = Signal(str)
    remove_duplicates = Signal()
    refresh_requested = Signal()

    def __init__(self, state: AppState):
        super().__init__()
        self.setObjectName("page")
        self.state = state
        self.audit: AuditResult | None = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 20, 24, 16)
        lay.setSpacing(10)
        top = QHBoxLayout()
        top.addWidget(heading("Auditor"))
        top.addStretch()
        self.btn_update = QPushButton("Update audit (F5)")
        self.btn_update.setToolTip("Re-scan the current data (after cleaning) and refresh every number on this page")
        self.btn_update.clicked.connect(self.refresh_requested)
        top.addWidget(self.btn_update)
        b = QPushButton("How is the score calculated?")
        b.clicked.connect(self.show_method)
        top.addWidget(b)
        lay.addLayout(top)
        self.fresh = muted("")
        lay.addWidget(self.fresh)
        self.empty = muted("Import a dataset to see its audit.")
        lay.addWidget(self.empty)

        self.body = QWidget()
        bl = QVBoxLayout(self.body)
        bl.setContentsMargins(0, 0, 0, 0)
        bl.setSpacing(10)
        row = QHBoxLayout()
        self.c_score = Card("Data Health Score")
        self.c_cols = Card("Healthy / problem columns")
        self.c_missing = Card("Missing values")
        self.c_dups = Card("Duplicate rows")
        for c in (self.c_score, self.c_cols, self.c_missing, self.c_dups):
            row.addWidget(c)
        bl.addLayout(row)

        act = QHBoxLayout()
        self.dup_btn = QPushButton("Remove All Duplicates...")
        self.dup_btn.setToolTip("Keeps the first copy of every duplicated row. You will confirm the number of rows first.")
        self.dup_btn.clicked.connect(self.remove_duplicates)
        clean = QPushButton("Open Cleaner")
        clean.clicked.connect(lambda: self.go_to.emit("clean"))
        self.breakdown = QLabel()
        self.breakdown.setObjectName("muted")
        self.breakdown.setWordWrap(True)
        act.addWidget(self.dup_btn)
        act.addWidget(clean)
        act.addStretch()
        bl.addLayout(act)
        bl.addWidget(self.breakdown)

        bar = QHBoxLayout()
        bar.addWidget(heading("Column health", "h2"))
        bar.addStretch()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Filter columns...")
        self.search.setClearButtonEnabled(True)
        self.search.setMaximumWidth(260)
        self.search.setAccessibleName("Filter columns")
        bar.addWidget(self.search)
        bl.addLayout(bar)

        split = QSplitter(Qt.Vertical)
        self.model = ColumnsModel()
        self.proxy = QSortFilterProxyModel()
        self.proxy.setSourceModel(self.model)
        self.proxy.setSortRole(Qt.UserRole)
        self.proxy.setFilterCaseSensitivity(Qt.CaseInsensitive)
        self.proxy.setFilterKeyColumn(0)
        self.search.textChanged.connect(self.proxy.setFilterFixedString)
        self.table = QTableView()
        self.table.setModel(self.proxy)
        self.table.setSortingEnabled(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.table.horizontalHeader().setDefaultSectionSize(95)
        self.table.setColumnWidth(0, 160)
        self.table.verticalHeader().setVisible(False)
        self.table.setAccessibleName("Column health table")
        self.table.selectionModel().selectionChanged.connect(self._selected)
        split.addWidget(self.table)
        self.detail = QPlainTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setPlaceholderText("Select a column to see its profile and what was found.")
        self.detail.setAccessibleName("Column details")
        split.addWidget(self.detail)
        split.setStretchFactor(0, 3)
        split.setStretchFactor(1, 1)
        bl.addWidget(split, 1)
        lay.addWidget(self.body, 1)
        self.body.hide()

        state.current_changed.connect(lambda ds: self.show_audit(state.audit_for(ds)))
        state.audit_ready.connect(self.show_audit)
        state.data_changed.connect(lambda ds: self._stale())

    def _stale(self) -> None:
        self.fresh.setText("Data changed - updating the audit...")

    def show_audit(self, a: AuditResult | None) -> None:
        self.audit = a
        ds = self.state.current
        if a is not None and ds is not None:
            n = len(ds.history.applied())
            self.fresh.setText(f"Audit of the current data ({n} cleaning change(s) applied) - up to date.")
        elif ds is not None:
            self.fresh.setText("Updating the audit...")
        else:
            self.fresh.setText("")
        self.empty.setVisible(a is None)
        self.body.setVisible(a is not None)
        if a is None:
            self.empty.setText("Import a dataset to see its audit." if self.state.current is None
                               else "Auditing...")
            return
        h = a.health
        word = "Good" if h.score >= 85 else "Fair" if h.score >= 65 else "Needs attention"
        self.c_score.set(f"{h.score} / 100", word)
        self.c_cols.set(f"{len(a.healthy_columns)} / {len(a.problem_columns)}",
                        f"of {len(a.columns)} columns")
        self.c_missing.set(f"{a.missing_pct:.1f}%", f"{a.missing_cells:,} of {a.total_cells:,} cells")
        self.c_dups.set(fmt_int(a.duplicates), "exact duplicate rows")
        self.dup_btn.setEnabled(a.duplicates > 0)
        lines = ["Score breakdown:   100"] + [f"  - {n}: -{p:g}  ({d})" for n, p, d in h.components]
        lines.append(f"  = Final score: {h.score}")
        self.breakdown.setText("\n".join(lines))
        self.model.set_profiles(a.columns)
        self.table.sortByColumn(3, Qt.DescendingOrder)  # problems first
        self.detail.setPlainText("")

    def _selected(self, *_):
        idx = self.table.selectionModel().selectedRows()
        if not idx or not self.audit:
            return
        src = self.proxy.mapToSource(idx[0])
        self.detail.setPlainText(describe(self.audit.columns[src.row()], self.audit))

    def show_method(self):
        text = (health_methodology() + "\n\n" +
                "Definitions\n"
                "- Missing: NULL, empty or whitespace-only text, and NaN in float columns.\n"
                "- Non-null: rows minus missing.\n"
                f"- Outliers: numeric values outside Q1 - {IQR_MULTIPLIER:g} x IQR or Q3 + {IQR_MULTIPLIER:g} x IQR "
                "(Tukey's fences). An outlier is a flag for review, not proof that a value is wrong.\n"
                "- Skewness: adjusted Fisher-Pearson sample skewness.\n"
                "- Problem column: >= 1% missing, any placeholder text such as NA, >= 1% outliers, "
                "or a constant column.\n"
                "- Duplicate rows: extra copies of rows identical in every column (NULLs match each other).\n"
                "All statistics are computed on the complete dataset.")
        TextDialog("Audit methodology", text, self).exec()


def describe(p, a: AuditResult) -> str:
    out = [f"{p.name}   [{p.duck_type} - {p.category}]", ""]
    out.append(f"Rows {p.rows:,} | non-null {p.non_null:,} | missing {p.missing:,} ({p.missing_pct:.2f}%) | "
               f"unique {p.unique:,} | cardinality {p.cardinality:.3f}")
    if p.is_numeric and p.mean is not None:
        out.append(f"Mean {fmt_value(p.mean)} | median {fmt_value(p.median)} | std {fmt_value(p.std)} | "
                   f"variance {fmt_value(p.variance)} | skewness {fmt_value(p.skew)}")
        out.append(f"Q1 {fmt_value(p.q1)} | Q3 {fmt_value(p.q3)} | IQR {fmt_value(p.iqr)} | "
                   f"fences [{fmt_value(p.lower_fence)}, {fmt_value(p.upper_fence)}] | "
                   f"outliers {p.outliers:,} ({p.outlier_pct:.2f}%)")
        out.append(f"Zeros {p.zeros:,} | negatives {p.negatives:,} | min {fmt_value(p.min)} | max {fmt_value(p.max)}")
    if p.kind == "text":
        out.append(f"Text length: min {p.min_len} | max {p.max_len} | average {fmt_value(p.avg_len)} | "
                   f"empty {p.empty_strings:,} | whitespace-only {p.whitespace_only:,} | "
                   f"placeholders like NA stored as text {p.token_missing:,}")
    if p.top_values:
        out.append("Most common: " + ", ".join(f"{v} ({c:,})" for v, c in p.top_values))
    if p.kind in ("datetime", "time", "boolean") and p.min is not None:
        out.append(f"Range: {p.min} -> {p.max}")
    out.append("")
    out.append("Findings: " + ("; ".join(p.issues) if p.issues else "no issues found."))
    r = a.recommendations.get(p.name)
    if r:
        out.append(f"Suggested for missing values: {r.label} - {r.quick}  (guidance only; see the Cleaner)")
    return "\n".join(out)
