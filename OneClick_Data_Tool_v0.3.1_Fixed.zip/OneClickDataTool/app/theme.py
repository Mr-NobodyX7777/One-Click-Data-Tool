"""Light / dark Qt style sheets. Colour is never the only carrier of meaning (text labels accompany it)."""
from __future__ import annotations

LIGHT = dict(bg="#f4f6f9", panel="#ffffff", border="#d9dee5", text="#1f2933", muted="#5f6c7b",
             accent="#2f6fb3", accent_text="#ffffff", side="#1d2b3a", side_text="#c9d4e0",
             side_active="#2f6fb3", ok="#1f7a4d", warn="#a35f00", bad="#b3261e", alt="#f8fafc",
             banner="#fff4d6")
DARK = dict(bg="#0e1a1f", panel="#16262d", border="#27414a", text="#e4f0f2", muted="#8fb0b7",
            accent="#2dd4bf", accent_text="#05262a", side="#0a1317", side_text="#9ec2c9",
            side_active="#2dd4bf", ok="#4cc38a", warn="#e0a43a", bad="#ff8a80", alt="#1b2f37",
            banner="#12363a")


def colors(dark: bool) -> dict:
    return DARK if dark else LIGHT


def stylesheet(dark: bool, scale: float = 1.0) -> str:
    c = colors(dark)
    fs = round(10 * scale, 1)
    return f"""
* {{ font-family: "Segoe UI", "Inter", "Noto Sans", "Helvetica Neue", sans-serif; font-size: {fs}pt; }}
QMainWindow, QDialog, QWidget#page {{ background: {c['bg']}; color: {c['text']}; }}
QWidget {{ color: {c['text']}; }}
QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: {c['bg']}; }}
QScrollArea > QWidget > QScrollBar {{ background: transparent; }}
QToolTip {{ background: {c['panel']}; color: {c['text']}; border: 1px solid {c['border']}; padding: 4px; }}
QFrame#sidebar {{ background: {c['side']}; }}
QLabel#brand {{ color: #ffffff; font-size: {fs + 3}pt; font-weight: 700; padding: 18px 16px 2px 16px; }}
QLabel#tagline {{ color: {c['side_text']}; font-size: {fs - 1.5}pt; padding: 0 16px 14px 16px; }}
QPushButton#nav {{ background: transparent; color: {c['side_text']}; border: none; text-align: left;
    padding: 11px 18px; border-left: 3px solid transparent; font-weight: 600; }}
QPushButton#nav:hover {{ background: rgba(255,255,255,0.07); }}
QPushButton#nav:checked {{ color: #ffffff; background: rgba(255,255,255,0.10); border-left: 3px solid {c['side_active']}; }}
QPushButton#nav:focus {{ outline: none; border: 2px solid {c['accent']}; }}
QPushButton#nav:disabled {{ color: #6b7785; }}
QFrame#card {{ background: {c['panel']}; border: 1px solid {c['border']}; border-radius: 8px; }}
QFrame#card[clickable="true"]:hover {{ border: 1px solid {c['accent']}; }}
QLabel#cardTitle {{ color: {c['muted']}; font-size: {fs - 1.5}pt; font-weight: 600; }}
QLabel#cardValue {{ font-size: {fs + 6}pt; font-weight: 700; }}
QLabel#cardNote {{ color: {c['muted']}; font-size: {fs - 1.5}pt; }}
QLabel#h1 {{ font-size: {fs + 5}pt; font-weight: 700; }}
QLabel#h2 {{ font-size: {fs + 1}pt; font-weight: 700; }}
QLabel#muted {{ color: {c['muted']}; }}
QLabel#banner {{ background: {c['banner']}; border: 1px solid {c['border']}; border-radius: 6px; padding: 8px 10px; }}
QLabel#error {{ color: {c['bad']}; font-weight: 600; }}
QPushButton {{ background: {c['panel']}; border: 1px solid {c['border']}; border-radius: 6px; padding: 7px 14px; }}
QPushButton:hover {{ border-color: {c['accent']}; }}
QPushButton:focus {{ border: 2px solid {c['accent']}; }}
QPushButton:disabled {{ color: {c['muted']}; background: {c['alt']}; }}
QPushButton#primary {{ background: {c['accent']}; color: {c['accent_text']}; border: 1px solid {c['accent']}; font-weight: 600; }}
QPushButton#primary:disabled {{ background: {c['border']}; color: {c['muted']}; border-color: {c['border']}; }}
QPushButton#danger {{ color: {c['bad']}; }}
QLineEdit, QComboBox, QSpinBox, QPlainTextEdit, QTextEdit {{ background: {c['panel']}; border: 1px solid {c['border']};
    border-radius: 6px; padding: 5px 8px; selection-background-color: {c['accent']}; selection-color: #ffffff; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QPlainTextEdit:focus {{ border: 2px solid {c['accent']}; }}
QTableView, QTableWidget, QListWidget {{ background: {c['panel']}; alternate-background-color: {c['alt']};
    border: 1px solid {c['border']}; border-radius: 6px; gridline-color: {c['border']};
    selection-background-color: {c['accent']}; selection-color: #ffffff; }}
QHeaderView::section {{ background: {c['alt']}; color: {c['text']}; border: none; border-right: 1px solid {c['border']};
    border-bottom: 1px solid {c['border']}; padding: 6px 8px; font-weight: 600; }}
QTabWidget::pane {{ border: 1px solid {c['border']}; border-radius: 6px; background: {c['panel']}; }}
QTabBar::tab {{ padding: 6px 14px; border: 1px solid transparent; }}
QTabBar::tab:selected {{ border-bottom: 2px solid {c['accent']}; font-weight: 600; }}
QGroupBox {{ background: {c['panel']}; border: 1px solid {c['border']}; border-radius: 8px; margin-top: 14px; padding: 12px 10px 8px 10px; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 6px; font-weight: 700; }}
QRadioButton, QCheckBox {{ spacing: 8px; padding: 3px 0; }}
QRadioButton::indicator {{ width: 14px; height: 14px; border: 2px solid {c['muted']}; border-radius: 9px; background: {c['panel']}; }}
QRadioButton::indicator:hover {{ border-color: {c['accent']}; }}
QRadioButton::indicator:checked {{ border: 2px solid {c['accent']}; background: qradialgradient(cx:0.5, cy:0.5, radius:0.5, fx:0.5, fy:0.5, stop:0 {c['accent']}, stop:0.55 {c['accent']}, stop:0.6 {c['panel']}, stop:1 {c['panel']}); }}
QRadioButton:disabled {{ color: {c['muted']}; }}
QRadioButton::indicator:disabled {{ border: 2px dashed {c['border']}; background: {c['alt']}; }}
QRadioButton:focus, QCheckBox:focus {{ outline: 1px dotted {c['accent']}; }}
QStatusBar {{ background: {c['panel']}; border-top: 1px solid {c['border']}; }}
QProgressBar {{ border: 1px solid {c['border']}; border-radius: 4px; background: {c['alt']}; max-height: 10px; }}
QProgressBar::chunk {{ background: {c['accent']}; border-radius: 3px; }}
QMenuBar {{ background: {c['panel']}; }}
QMenu {{ background: {c['panel']}; border: 1px solid {c['border']}; }}
QMenu::item {{ padding: 6px 36px 6px 24px; }}
QMenu::item:selected {{ background: {c['accent']}; color: #ffffff; }}
QScrollBar:vertical {{ background: {c['alt']}; width: 12px; margin: 0; }}
QScrollBar:horizontal {{ background: {c['alt']}; height: 12px; margin: 0; }}
QScrollBar::handle {{ background: {c['border']}; border-radius: 5px; min-height: 28px; min-width: 28px; }}
QScrollBar::handle:hover {{ background: {c['muted']}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QAbstractScrollArea::corner {{ background: {c['alt']}; }}
QTableCornerButton::section {{ background: {c['alt']}; border: none; }}
QSplitter::handle {{ background: {c['border']}; }}
"""
