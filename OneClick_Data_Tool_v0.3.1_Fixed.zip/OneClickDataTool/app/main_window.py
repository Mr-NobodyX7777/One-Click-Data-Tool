from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSettings, Qt, QTimer
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QFileDialog, QFrame, QHBoxLayout, QLabel,
                               QMainWindow, QMessageBox, QProgressBar, QPushButton, QStackedWidget, QVBoxLayout,
                               QWidget)

from app import theme
from app.project import save_project, load_project
from app.errors import friendly
from app.import_dialog import ImportDialog
from app.pages.audit_page import AuditPage, TextDialog
from app.pages.clean_page import CleanPage
from app.pages.import_page import ImportPage
from app.pages.viz_page import VizPage
from app.state import AppState
from app.widgets import fmt_int
from app.workers import TaskRunner
from auditor.auditor import audit_table, health_methodology
from cleaner.operations import OperationError, plan_remove_duplicates
from data.connectors import file_filter
from data.importer import import_frame, import_source
from data.sample import sample_frame
from export import FORMATS, ExportError, export_dataset
from export.png_export import export_png
from export.html_report import export_html_report
from visualizer.charts import render
from visualizer.recommendations import recommend_charts
from visualizer.validation import validate_plot_data

APP_VERSION = "0.2.0"
PAGES = [("import", "Import"), ("audit", "Auditor"), ("clean", "Cleaner"), ("viz", "Visualizer")]


class MainWindow(QMainWindow):
    def __init__(self, state: AppState | None = None):
        super().__init__()
        self.state = state or AppState()
        self.runner = TaskRunner(self)
        self.settings = QSettings("OneClickDataTool", "OneClickDataTool")
        self.dark = self.settings.value("dark", True, type=bool)
        self.project_path: str | None = None
        self.setWindowTitle("OneClick Data Tool")
        self.resize(1320, 840)
        self.setMinimumSize(900, 600)
        self.setAcceptDrops(True)
        self._build()
        self._menus()
        self.apply_theme()
        self.runner.busy_changed.connect(self._busy)
        self.state.current_changed.connect(self._current_changed)
        self.state.datasets_changed.connect(self._fill_dataset_combo)
        self.state.data_changed.connect(self._data_changed)
        self._busy_timer = QTimer(self, singleShot=True, interval=250)
        self._busy_timer.timeout.connect(lambda: self._set_locked(True))
        self.show_page("import")

    # -- layout -----------------------------------------------------------------------------------------
    def _build(self) -> None:
        root = QWidget()
        h = QHBoxLayout(root)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        side = QFrame()
        side.setObjectName("sidebar")
        side.setFixedWidth(200)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(0, 0, 0, 12)
        sl.setSpacing(2)
        brand = QLabel("OneClick\nData Tool")
        brand.setObjectName("brand")
        tag = QLabel("Import → Understand → Clean\n→ Visualize → Export")
        tag.setObjectName("tagline")
        sl.addWidget(brand)
        sl.addWidget(tag)
        self.nav = QButtonGroup(self)
        self.nav_buttons = {}
        for key, label in PAGES:
            b = QPushButton(label)
            b.setObjectName("nav")
            b.setCheckable(True)
            b.setAccessibleName(f"{label} page")
            b.clicked.connect(lambda _=False, k=key: self.show_page(k))
            self.nav.addButton(b)
            self.nav_buttons[key] = b
            sl.addWidget(b)
        sl.addStretch()
        self.btn_theme = QPushButton()
        self.btn_theme.setObjectName("nav")
        self.btn_theme.setToolTip("Switch between dark and light mode")
        self.btn_theme.clicked.connect(self.toggle_theme)
        sl.addWidget(self.btn_theme)
        off = QLabel("Offline - your data stays\non this computer")
        off.setObjectName("tagline")
        sl.addWidget(off)
        h.addWidget(side)

        main = QVBoxLayout()
        main.setContentsMargins(0, 0, 0, 0)
        bar = QHBoxLayout()
        bar.setContentsMargins(24, 10, 24, 0)
        bar.addWidget(QLabel("Dataset:"))
        self.combo = QComboBox()
        self.combo.setMinimumWidth(260)
        self.combo.setAccessibleName("Active dataset")
        self.combo.currentIndexChanged.connect(self._combo_changed)
        bar.addWidget(self.combo)
        self.btn_close = QPushButton("Close dataset")
        self.btn_close.clicked.connect(self.close_dataset)
        bar.addWidget(self.btn_close)
        self.btn_export = QPushButton("Export cleaned data...")
        self.btn_export.setToolTip("Save the current data as a new file (Ctrl+E). The original is never overwritten.")
        self.btn_export.clicked.connect(self.export_data)
        bar.addStretch()
        bar.addWidget(self.btn_export)
        main.addLayout(bar)
        self.pages = QStackedWidget()
        self.p_import = ImportPage(self.state)
        self.p_audit = AuditPage(self.state)
        self.p_clean = CleanPage(self.state)
        self.p_viz = VizPage(self.state)
        self.page_map = {"import": self.p_import, "audit": self.p_audit, "clean": self.p_clean, "viz": self.p_viz}
        for p in self.page_map.values():
            self.pages.addWidget(p)
        main.addWidget(self.pages, 1)
        h.addLayout(main, 1)
        self.setCentralWidget(root)
        self.progress = QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setFixedWidth(160)
        self.progress.hide()
        self.status_label = QLabel("Ready")
        self.statusBar().addWidget(self.status_label, 1)
        self.statusBar().addPermanentWidget(self.progress)

        self.p_import.open_requested.connect(self.open_file)
        self.p_import.sample_requested.connect(self.load_sample)
        for p in (self.p_import, self.p_audit):
            p.go_to.connect(self.show_page)
        self.p_audit.remove_duplicates.connect(
            lambda: self.plan_and_confirm(lambda e, t: plan_remove_duplicates(e, t)))
        self.p_audit.refresh_requested.connect(self.update_all)
        self.p_clean.refresh_requested.connect(self.update_all)
        self.p_clean.plan_requested.connect(self.plan_and_confirm)
        self.p_clean.undo_requested.connect(self.undo)
        self.p_clean.redo_requested.connect(self.redo)
        self.p_clean.reset_requested.connect(self.reset)
        self.p_clean.export_history.connect(self.export_history)
        self.p_viz.generate_requested.connect(self.generate_chart)
        self.p_viz.export_png_requested.connect(self.export_png)
        self._update_enabled()

    def _menus(self) -> None:
        def act(menu, text, slot, shortcut=None):
            a = QAction(text, self)
            if shortcut:
                a.setShortcut(QKeySequence(shortcut))
            a.triggered.connect(slot)
            menu.addAction(a)
            return a
        m = self.menuBar().addMenu("&File")
        act(m, "&Open file...", self.open_file, "Ctrl+O")
        act(m, "Load &sample dataset", self.load_sample)
        m.addSeparator()
        act(m, "Open &project...", self.open_project, "Ctrl+Shift+O")
        act(m, "&Save project", self.save_project, "Ctrl+S")
        act(m, "Save project &as...", self.save_project_as, "Ctrl+Shift+S")
        m.addSeparator()
        act(m, "&Export cleaned data...", self.export_data, "Ctrl+E")
        act(m, "Export &HTML quality report...", self.export_report)
        m.addSeparator()
        act(m, "E&xit", self.close, "Ctrl+Q")
        m = self.menuBar().addMenu("&Edit")
        self.a_undo = act(m, "&Undo", self.undo, "Ctrl+Z")
        self.a_redo = act(m, "&Redo", self.redo, "Ctrl+Y")
        m = self.menuBar().addMenu("&View")
        act(m, "&Update / re-scan data", self.update_all, "F5")
        act(m, "Toggle &dark theme", self.toggle_theme)
        for i, (k, lab) in enumerate(PAGES, start=1):
            act(m, f"Go to {lab}", lambda _=False, key=k: self.show_page(key), f"Alt+{i}")
        m = self.menuBar().addMenu("&Help")
        act(m, "Health score methodology", lambda: TextDialog("Data Health Score", health_methodology(), self).exec())
        act(m, "Keyboard shortcuts", self.show_shortcuts)
        act(m, "Privacy", self.show_privacy)
        act(m, "About", lambda: QMessageBox.about(self, "About", f"OneClick Data Tool {APP_VERSION}\n"
                                                  "A local, offline data-analysis tool."))

    # -- theme / navigation ---------------------------------------------------------------------------------
    def apply_theme(self) -> None:
        QApplication.instance().setStyleSheet(theme.stylesheet(self.dark))
        self.btn_theme.setText("Light mode" if self.dark else "Dark mode")

    def toggle_theme(self) -> None:
        self.dark = not self.dark
        self.settings.setValue("dark", self.dark)
        self.apply_theme()

    def show_page(self, key: str) -> None:
        self.pages.setCurrentWidget(self.page_map[key])
        self.nav_buttons[key].setChecked(True)

    def _update_enabled(self) -> None:
        has = self.state.current is not None
        for k in ("audit", "clean", "viz"):
            self.nav_buttons[k].setEnabled(has)
        self.btn_export.setEnabled(has)
        self.btn_close.setEnabled(has)
        self.combo.setEnabled(has)
        ds = self.state.current
        if hasattr(self, "a_undo"):
            self.a_undo.setEnabled(bool(ds and ds.can_undo))
            self.a_redo.setEnabled(bool(ds and ds.can_redo))

    def _busy(self, on: bool, label: str) -> None:
        self.progress.setVisible(on)
        self.status_label.setText(label if on else "Ready")
        if on:
            self._busy_timer.start()
        else:
            self._busy_timer.stop()
            self._set_locked(False)

    def _set_locked(self, locked: bool) -> None:
        self.pages.setEnabled(not locked)

    # -- dataset selection ------------------------------------------------------------------------------------
    def _fill_dataset_combo(self) -> None:
        self.combo.blockSignals(True)
        try:
            self.combo.clear()
            for ds in self.state.datasets:
                self.combo.addItem(ds.name, ds.id)
            if self.state.current in self.state.datasets:  # not the case for an instant while closing one
                self.combo.setCurrentIndex(self.state.datasets.index(self.state.current))
        finally:
            self.combo.blockSignals(False)

    def _combo_changed(self, i: int) -> None:
        if 0 <= i < len(self.state.datasets) and self.state.datasets[i] is not self.state.current:
            self.state.set_current(self.state.datasets[i])

    def _current_changed(self, ds) -> None:
        self._fill_dataset_combo()
        self._update_enabled()
        if ds is None:
            self.show_page("import")
            return
        if self.state.audit_for(ds) is None:
            self.run_audit(ds)
        else:
            self.state.audit_ready.emit(self.state.audit_for(ds))
        self.run_recommendations(ds)

    def _data_changed(self, ds) -> None:
        self._update_enabled()
        self.run_audit(ds)
        self.run_recommendations(ds)

    def update_all(self) -> None:
        """Re-scan the current data and refresh every page."""
        ds = self.state.current
        if ds is None:
            return
        ds.version += 1  # invalidate any cached audit
        self.state.data_changed.emit(ds)

    def close_dataset(self) -> None:
        if self.runner.busy:
            QMessageBox.information(self, 'Busy', 'Finish the current operation before closing a dataset.')
            return
        ds = self.state.current
        if ds and QMessageBox.question(self, "Close dataset", f"Close '{ds.name}'? Unexported changes are lost.\n"
                                       "The original file is not affected.") == QMessageBox.Yes:
            self.state.close_dataset(ds)

    # -- error reporting ----------------------------------------------------------------------------------------
    def report_error(self, exc: BaseException, context: str = "") -> None:
        msg = friendly(exc, context)
        box = QMessageBox(QMessageBox.Warning, msg.title or "Problem", msg.what, QMessageBox.Ok, self)
        details = "\n\n".join(x for x in (msg.why and f"Why it may have happened: {msg.why}",
                                          msg.suggestion and f"What you can do: {msg.suggestion}") if x)
        box.setInformativeText(details + (f"\n\nDiagnostic reference: {msg.ref}"))
        box.exec()

    # -- import -----------------------------------------------------------------------------------------------------
    def open_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Open data file", self.settings.value("last_dir", ""), file_filter())
        if path:
            self.import_path(path)

    def import_path(self, path: str) -> None:
        self.settings.setValue("last_dir", str(Path(path).parent))
        try:
            dlg = ImportDialog(path, self.state.engine, self)
        except Exception as e:
            self.report_error(e, "Could not open the file")
            return
        if dlg.exec() != dlg.DialogCode.Accepted:
            return
        try:
            source = dlg.build_source()
        except Exception as e:
            self.report_error(e, "Import failed")
            return
        self.state.missing_tokens = dlg.options().get("missing_tokens", self.state.missing_tokens) \
            if dlg.fmt.currentText() == "CSV" else self.state.missing_tokens
        eng = self.state.engine
        self.runner.run(lambda: import_source(eng, source),
                        on_success=self._imported, on_error=lambda e: self.report_error(e, "Import failed"),
                        label=f"Importing {source.name}...")

    def _imported(self, ds) -> None:
        self.state.add_dataset(ds)
        self.show_page("import")

    def load_sample(self) -> None:
        eng = self.state.engine
        self.runner.run(lambda: import_frame(eng, sample_frame(), "Sample dataset", "Built-in sample"),
                        on_success=self._imported, on_error=lambda e: self.report_error(e, "Sample failed"),
                        label="Loading sample...")

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        urls = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        if urls:
            self.import_path(urls[0])

    # -- audit -----------------------------------------------------------------------------------------------------
    def run_audit(self, ds) -> None:
        eng, table, version, name = self.state.engine, ds.current, ds.version, ds.name
        tokens = list(self.state.missing_tokens)
        self.runner.run(lambda: audit_table(eng, table, name, tokens),
                        on_success=lambda r: self.state.store_audit(ds, version, r),
                        on_error=lambda e: self.report_error(e, "Audit failed"), label="Auditing dataset...")

    def run_recommendations(self, ds) -> None:
        eng, table, version = self.state.engine, ds.current, ds.version

        def job():
            a = audit_table(eng, table, ds.name, list(self.state.missing_tokens))
            return a, recommend_charts(eng, table, a)

        def done(res):
            if ds is self.state.current and ds.version == version:
                self.p_viz.set_recommendations(res[1])
        self.runner.run(job, on_success=done, on_error=lambda e: None, label="Preparing chart suggestions...")

    # -- cleaning -----------------------------------------------------------------------------------------------------
    def plan_and_confirm(self, builder) -> None:
        ds = self.state.current
        if ds is None:
            return
        eng, table = self.state.engine, ds.current

        def err(e):
            if isinstance(e, OperationError):
                self.p_clean.show_error(str(e))
                self.show_page("clean")
            else:
                self.report_error(e, "Could not prepare the change")
        self.runner.run(lambda: builder(eng, table), on_success=lambda p: self._confirm(ds, p),
                        on_error=err, label="Calculating impact...")

    def _confirm(self, ds, plan) -> None:
        if plan.affected == 0:
            QMessageBox.information(self, "Nothing to change", f"{plan.description}\n\nNo rows or cells would be affected.")
            return
        unit = "row(s) removed" if plan.rows_removed else "cell(s) filled"
        text = (f"{plan.description}\n\n"
                f"Rows affected: {plan.affected:,} ({unit})\n"
                f"Current rows: {plan.current_rows:,}\n"
                f"Rows after: {plan.rows_after:,}")
        if plan.notes:
            text += "\n\n" + "\n".join(plan.notes)
        text += "\n\nThe original file is not modified, and you can undo this."
        box = QMessageBox(QMessageBox.Question, "Confirm change", text, QMessageBox.Cancel, self)
        ok = box.addButton("Apply", QMessageBox.AcceptRole)
        box.setDefaultButton(QMessageBox.Cancel)
        box.exec()
        if box.clickedButton() is not ok or ds is not self.state.current:
            return
        self.runner.run(lambda: ds.apply(plan), on_success=lambda _e: self.state.data_changed.emit(ds),
                        on_error=lambda e: self.report_error(e, "The change could not be applied"),
                        label="Applying change...")

    def undo(self) -> None:
        ds = self.state.current
        if ds and ds.undo():
            self.state.data_changed.emit(ds)

    def redo(self) -> None:
        ds = self.state.current
        if ds and ds.redo():
            self.state.data_changed.emit(ds)

    def reset(self) -> None:
        ds = self.state.current
        if ds and QMessageBox.question(self, "Reset to original", "Discard all changes and return to the imported data?"
                                       ) == QMessageBox.Yes:
            ds.reset_to_original()
            self.state.data_changed.emit(ds)

    def export_history(self, fmt: str) -> None:
        ds = self.state.current
        if not ds:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export cleaning history", f"cleaning_history.{fmt}",
                                              f"{fmt.upper()} (*.{fmt})")
        if path:
            try:
                (ds.history.export_json if fmt == "json" else ds.history.export_csv)(path)
                self.status_label.setText(f"History saved to {path}")
            except Exception as e:
                self.report_error(e, "History export failed")

    # -- charts -----------------------------------------------------------------------------------------------------------
    def generate_chart(self, spec) -> None:
        ds = self.state.current
        if ds is None:
            return
        eng, table = self.state.engine, ds.current

        def done(plot):
            if not plot.ok:
                self.p_viz.show_problem(plot)
                return
            self.p_viz.show_figure(render(plot), plot)
        self.runner.run(lambda: validate_plot_data(eng, table, spec), on_success=done,
                        on_error=lambda e: self.report_error(e, "Chart failed"), label="Preparing chart...")

    def export_png(self) -> None:
        fig = self.p_viz.figure
        path, _ = QFileDialog.getSaveFileName(self, "Export chart", "chart.png", "PNG image (*.png)")
        if path:
            try:
                export_png(fig, path)
                self.status_label.setText(f"Chart saved to {path}")
            except Exception as e:
                self.report_error(e, "PNG export failed")

    # -- export data --------------------------------------------------------------------------------------------------------
    def export_data(self) -> None:
        ds = self.state.current
        if ds is None:
            return
        rows = ds.row_count()
        if rows > 1_000_000:
            QMessageBox.information(self, "Large dataset", f"This dataset has {rows:,} rows. Parquet is the "
                                    "recommended format for data this size (smaller and faster). CSV is still available.")
        filters = ";;".join(FORMATS)
        stem = Path(ds.info.source_name).stem + ("_cleaned" if ds.is_modified else "_export")
        path, flt = QFileDialog.getSaveFileName(self, "Export data", stem, filters)
        if not path:
            return
        ext = FORMATS[flt][0] if flt in FORMATS else ".csv"
        if not path.lower().endswith(ext):
            path += ext
        label = flt if flt in FORMATS else "CSV (.csv)"
        eng, table, src = self.state.engine, ds.current, ds.info.source_path

        def err(e):
            self.report_error(e, "Export failed")
        self.runner.run(lambda: export_dataset(eng, table, path, label, src),
                        on_success=lambda _r: self.status_label.setText(f"Exported {fmt_int(rows)} rows to {path}"),
                        on_error=err, label="Exporting...")

    # -- projects and quality reports -----------------------------------------------------------------------
    def save_project(self) -> None:
        if not self.project_path:
            self.save_project_as()
            return
        if self.runner.busy:
            QMessageBox.information(self, 'Busy', 'Finish the current operation before saving a project.')
            return
        path = self.project_path
        self.runner.run(lambda: save_project(self.state, path),
                        on_success=lambda _: self.status_label.setText(f'Project saved: {path}'),
                        on_error=lambda e: self.report_error(e, 'Project save failed'),
                        label='Saving project...')

    def save_project_as(self) -> None:
        if self.runner.busy:
            QMessageBox.information(self, 'Busy', 'Finish the current operation before saving a project.')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Save project', self.project_path or 'OneClick Project.ocdt',
                                             'OneClick Projects (*.ocdt)')
        if not path:
            return
        if not path.lower().endswith('.ocdt'):
            path += '.ocdt'
        self.project_path = path
        self.save_project()

    def open_project(self) -> None:
        if self.runner.busy:
            QMessageBox.information(self, 'Busy', 'Finish the current operation before opening a project.')
            return
        path, _ = QFileDialog.getOpenFileName(self, 'Open project', self.project_path or '',
                                             'OneClick Projects (*.ocdt)')
        if not path:
            return
        if self.state.datasets and QMessageBox.question(
                self, 'Replace workspace',
                'Opening this project will replace the current workspace and discard unsaved changes. Continue?'
        ) != QMessageBox.Yes:
            return
        engine = self.state.engine
        self.runner.run(lambda: load_project(engine, path),
                        on_success=lambda result: self._project_loaded(path, result),
                        on_error=lambda e: self.report_error(e, 'Could not open project'),
                        label='Opening project...')

    def _project_loaded(self, path, result) -> None:
        datasets, active_index, missing_tokens = result
        for ds in self.state.datasets:
            ds.close()
        self.state.datasets = datasets
        self.state.audits.clear()
        if missing_tokens is not None:
            self.state.missing_tokens = missing_tokens
        self.project_path = path
        self.state.datasets_changed.emit()
        self.state.set_current(datasets[active_index] if active_index >= 0 else None)
        self.status_label.setText(f'Project opened: {path}')

    def export_report(self) -> None:
        ds = self.state.current
        if not ds:
            QMessageBox.information(self, 'No dataset', 'Import a dataset and run an audit first.')
            return
        report = self.state.audit_for(ds)
        if report is None:
            QMessageBox.information(self, 'Audit pending', 'Finish the audit before exporting a report.')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Export HTML quality report',
                                             f'{ds.name}_quality_report.html', 'HTML files (*.html)')
        if not path:
            return
        if not path.lower().endswith('.html'):
            path += '.html'
        try:
            export_html_report(report, path)
            self.status_label.setText(f'HTML report saved: {path}')
        except Exception as e:
            self.report_error(e, 'HTML report export failed')

    # -- help --------------------------------------------------------------------------------------------------------------------
    def show_shortcuts(self) -> None:
        TextDialog("Keyboard shortcuts", "Ctrl+O  Open file\nCtrl+E  Export data\nCtrl+Z  Undo\nCtrl+Y  Redo\n"
                   "Ctrl+S  Save project\nCtrl+Shift+O  Open project\nCtrl+C  Copy selected cells (data grid)\nAlt+1..4  Go to Import / Auditor / Cleaner / Visualizer\n"
                   "Ctrl+Q  Quit", self).exec()

    def show_privacy(self) -> None:
        TextDialog("Privacy", "OneClick Data Tool works entirely on this computer.\n\n"
                   "- Your data is never uploaded anywhere.\n- No telemetry, no accounts, no internet access is needed.\n"
                   "- Your original files are opened read-only and never modified.\n"
                   "- Working copies live in a temporary folder, unless you explicitly save a portable .ocdt project.\n"
                   "- The diagnostic log (oneclick.log) never contains your data.", self).exec()

    def closeEvent(self, e):
        if self.runner.busy:
            e.ignore()
            QMessageBox.information(self, 'Operation running',
                                    'Finish the current operation before closing the application.')
            return
        self.state.shutdown()
        super().closeEvent(e)
