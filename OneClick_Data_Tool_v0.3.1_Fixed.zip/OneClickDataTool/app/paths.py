"""Tiny, dependency-free helpers so the loading screen can run before the heavy imports."""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "OneClickDataTool"


def data_dir() -> Path:
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    d = base / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def first_run_marker() -> Path:
    return data_dir() / "first_launch_done"


def is_first_run() -> bool:
    return not first_run_marker().exists()


def mark_first_run_done() -> None:
    try:
        first_run_marker().write_text("ok", encoding="utf-8")
    except OSError:
        pass
