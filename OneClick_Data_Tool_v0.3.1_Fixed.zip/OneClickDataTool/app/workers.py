"""Run expensive work off the GUI thread and deliver results back on it."""
from __future__ import annotations

import itertools
import traceback
from typing import Callable

from PySide6.QtCore import QObject, QRunnable, QThreadPool, QTimer, Signal, Slot


class _Signals(QObject):
    finished = Signal(int, object)
    failed = Signal(int, object)


class _Worker(QRunnable):
    def __init__(self, task_id: int, fn: Callable, signals: _Signals):
        super().__init__()
        self.task_id, self.fn, self.signals = task_id, fn, signals
        self.setAutoDelete(True)

    def run(self):
        try:
            result = self.fn()
        except BaseException as e:  # noqa: BLE001 - reported to the GUI thread
            e.__traceback_text__ = traceback.format_exc()  # type: ignore[attr-defined]
            try:
                self.signals.failed.emit(self.task_id, e)
            except RuntimeError:
                pass  # window already closed
        else:
            try:
                self.signals.finished.emit(self.task_id, result)
            except RuntimeError:
                pass  # window already closed


class TaskRunner(QObject):
    """Callbacks always run on the GUI thread (signals are delivered via queued connection
    to this QObject's slots)."""

    busy_changed = Signal(bool, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.pool = QThreadPool.globalInstance()
        self._ids = itertools.count(1)
        self._tasks: dict[int, tuple[Callable | None, Callable | None, str]] = {}
        self._signals = _Signals()
        self._signals.finished.connect(self._on_finished)
        self._signals.failed.connect(self._on_failed)

    @property
    def busy(self) -> bool:
        return bool(self._tasks)

    def run(self, fn: Callable, on_success: Callable | None = None,
            on_error: Callable | None = None, label: str = "Working...") -> int:
        tid = next(self._ids)
        was_idle = not self._tasks
        self._tasks[tid] = (on_success, on_error, label)
        if was_idle:
            self.busy_changed.emit(True, label)
        self.pool.start(_Worker(tid, fn, self._signals))
        return tid

    def _done(self, tid: int):
        cb = self._tasks.pop(tid)
        if not self._tasks:
            self.busy_changed.emit(False, "")
        return cb

    @Slot(int, object)
    def _on_finished(self, tid: int, result):
        ok, _, _ = self._done(tid)
        if ok:
            ok(result)

    @Slot(int, object)
    def _on_failed(self, tid: int, exc):
        _, err, _ = self._done(tid)
        if err:
            err(exc)
