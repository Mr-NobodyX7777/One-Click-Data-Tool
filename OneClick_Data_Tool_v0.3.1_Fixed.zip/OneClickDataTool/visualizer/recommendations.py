"""Chart recommendations. A chart is only suggested if it passes validation."""
from __future__ import annotations

from dataclasses import dataclass

from auditor.auditor import AuditResult
from data.duckdb_manager import Engine
from data.types import num_expr, quote_ident
from visualizer.validation import ChartSpec, validate_plot_data

MAX_RECOMMENDATIONS = 10


@dataclass
class Recommendation:
    spec: ChartSpec
    title: str
    reason: str


def _is_identifier(p) -> bool:
    return p.kind == "numeric" and p.non_null > 20 and p.cardinality >= 0.95 and p.duck_type.upper() in (
        "TINYINT", "SMALLINT", "INTEGER", "BIGINT", "HUGEINT", "UBIGINT", "UINTEGER")


def recommend_charts(engine: Engine, table: str, audit: AuditResult) -> list[Recommendation]:
    cols = audit.columns
    nums = [c for c in cols if c.is_numeric and c.non_null >= 3 and not c.constant and not _is_identifier(c)]
    cats = [c for c in cols if c.category == "Categorical" and 2 <= c.unique <= 20 and c.non_null >= 3]
    times = [c for c in cols if c.category == "Date/time" and c.unique >= 2]
    cand: list[Recommendation] = []

    for c in nums[:3]:
        cand.append(Recommendation(ChartSpec("histogram", c.name), "Histogram + KDE",
                                   f"'{c.name}' is numeric - a histogram shows its distribution "
                                   f"(skewness {c.skew:.2f})." if c.skew is not None else
                                   f"'{c.name}' is numeric - a histogram shows its distribution."))
    if len(nums) >= 2:
        pairs = _best_pairs(engine, table, nums[:8])
        for (a, b, r) in pairs[:2]:
            strength = "strong" if abs(r) >= 0.7 else "moderate" if abs(r) >= 0.4 else "weak"
            cand.append(Recommendation(ChartSpec("scatter", a, b), "Scatter + regression",
                                       f"'{a}' and '{b}' are both numeric ({strength} correlation, r = {r:.2f})."))
    for cat in cats[:2]:
        if nums:
            cand.append(Recommendation(ChartSpec("box", cat.name, nums[0].name), "Box plot",
                                       f"Compare '{nums[0].name}' across the {cat.unique} groups of '{cat.name}'."))
        cand.append(Recommendation(ChartSpec("bar", cat.name, agg="count"), "Bar chart",
                                   f"'{cat.name}' has {cat.unique} categories - counts show how rows are split."))
    if times and nums:
        cand.append(Recommendation(ChartSpec("line", times[0].name, nums[0].name, agg="mean"), "Line chart",
                                   f"'{times[0].name}' is a date/time column - see how '{nums[0].name}' changes over time."))

    out: list[Recommendation] = []
    for r in cand:
        if validate_plot_data(engine, table, r.spec).ok:  # never recommend what cannot be drawn
            out.append(r)
        if len(out) >= MAX_RECOMMENDATIONS:
            break
    return out


def _best_pairs(engine: Engine, table: str, nums) -> list[tuple[str, str, float]]:
    exprs, keys = [], []
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            exprs.append(f"corr({num_expr(nums[i].name)}, {num_expr(nums[j].name)})")
            keys.append((nums[i].name, nums[j].name))
    row = engine.fetchone(f"SELECT {', '.join(exprs)} FROM {quote_ident(table)}")
    pairs = [(a, b, r) for (a, b), r in zip(keys, row) if r is not None]
    pairs.sort(key=lambda p: -abs(p[2]))
    return pairs
