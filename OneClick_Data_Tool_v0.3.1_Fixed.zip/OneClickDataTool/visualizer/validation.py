"""Centralised chart validation + data preparation.

`validate_plot_data()` is the ONLY way a chart gets its data. It checks columns,
types, valid values/pairs, observation counts, variance and category counts, and
returns either a ready-to-draw payload or clear, human-readable errors. A chart
is never drawn from an invalid PlotData, so a silent blank graph cannot happen.

All statistics come from the FULL data (DuckDB); only the points that are
physically drawn are sampled when a dataset is large.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from data.duckdb_manager import Engine
from data.types import missing_expr, num_expr, quote_ident, type_kind

MAX_POINTS = 50_000
KDE_POINTS = 5_000
MAX_TOP_N = 50
AGGREGATIONS = ("count", "mean", "sum", "median", "min", "max")


@dataclass
class Slot:
    label: str
    kinds: tuple[str, ...]
    required: bool = True


@dataclass
class ChartDef:
    key: str
    title: str
    x: Slot
    y: Slot | None
    min_obs: int
    needs: str  # one-line statement of the data requirement
    uses_agg: bool = False


CHARTS: dict[str, ChartDef] = {
    "histogram": ChartDef("histogram", "Histogram + KDE", Slot("Column (numeric)", ("numeric",)), None, 2,
                          "One numeric column with at least 2 valid values."),
    "box": ChartDef("box", "Box plot", Slot("Group by (optional, categorical)", ("text", "boolean"), False),
                    Slot("Values (numeric)", ("numeric",)), 3,
                    "A numeric column; optionally grouped by a column with a readable number of categories."),
    "scatter": ChartDef("scatter", "Scatter + regression", Slot("X (numeric)", ("numeric",)),
                        Slot("Y (numeric)", ("numeric",)), 3,
                        "Two different numeric columns with at least 3 rows where both are valid."),
    "bar": ChartDef("bar", "Bar chart", Slot("Category", ("text", "boolean")),
                    Slot("Value (optional, numeric)", ("numeric",), False), 1,
                    "A categorical column; optionally a numeric column to aggregate.", uses_agg=True),
    "line": ChartDef("line", "Line chart", Slot("X (date/time or numeric)", ("datetime", "numeric")),
                     Slot("Y (numeric)", ("numeric",)), 2,
                     "A date/time (or numeric, ordered) X and a numeric Y with at least 2 distinct X values.",
                     uses_agg=True),
}


@dataclass
class ChartSpec:
    kind: str
    x: str | None = None
    y: str | None = None
    agg: str = "mean"
    top_n: int = 20
    max_points: int = MAX_POINTS
    sort: str = "value_desc"  # value_desc | value_asc | label

    def to_dict(self) -> dict:
        return dict(self.__dict__)


@dataclass
class PlotData:
    spec: ChartSpec
    ok: bool = False
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)  # e.g. sampling disclosure
    payload: dict = field(default_factory=dict)

    def fail(self, msg: str) -> "PlotData":
        self.ok = False
        self.errors.append(msg)
        return self


def _plural(n: int, word: str) -> str:
    return f"{n:,} {word}{'' if n == 1 else 's'}"


def validate_plot_data(engine: Engine, table: str, spec: ChartSpec) -> PlotData:
    pd = PlotData(spec)
    cd = CHARTS.get(spec.kind)
    if cd is None:
        return pd.fail(f"Unknown chart type '{spec.kind}'.")
    try:
        schema = dict(engine.schema(table))
        total_rows = engine.row_count(table)
    except Exception:
        return pd.fail("The dataset could not be read. Reload it and try again.")
    if total_rows == 0:
        return pd.fail("The dataset has no rows, so there is nothing to plot.")

    # 1+2. column existence and types
    for slot, col in ((cd.x, spec.x), (cd.y, spec.y)):
        if slot is None:
            continue
        if not col:
            if slot.required:
                pd.fail(f"Select a column for '{slot.label}'.")
            continue
        if col not in schema:
            pd.fail(f"Column '{col}' does not exist in this dataset.")
            continue
        kind = type_kind(schema[col])
        if kind not in slot.kinds:
            pd.fail(f"'{col}' is a {schema[col]} column ({kind}); '{slot.label}' needs "
                    f"{' or '.join(slot.kinds)} data. {_hint(spec.kind, kind)}".strip())
    if pd.errors:
        return pd
    if spec.kind == "scatter" and spec.x == spec.y:
        return pd.fail("X and Y are the same column; pick two different numeric columns.")
    if spec.agg not in AGGREGATIONS:
        return pd.fail(f"Unknown aggregation '{spec.agg}'.")
    top_n = max(1, min(int(spec.top_n), MAX_TOP_N))

    try:
        {"histogram": _histogram, "box": _box, "scatter": _scatter,
         "bar": _bar, "line": _line}[spec.kind](engine, table, schema, spec, pd, top_n)
    except _Invalid as e:
        pd.ok = False
        pd.errors.append(str(e))
    except Exception as e:  # defensive: surface a readable message instead of a blank chart
        pd.ok = False
        pd.errors.append(f"The chart data could not be prepared ({type(e).__name__}). "
                         "Check the selected columns and try again.")
        import logging
        logging.getLogger("oneclick.viz").exception("validate_plot_data failed")
    if not pd.errors:
        pd.ok = True
    return pd


class _Invalid(Exception):
    pass


def _hint(chart: str, kind: str) -> str:
    if chart == "line" and kind == "text":
        return "Line charts need an ordered X (date/time or number); use a bar chart for categories."
    if chart in ("box", "bar") and kind == "numeric":
        return "Use a text/categorical column here."
    return ""


# ---------------------------------------------------------------------------------------------------
def _histogram(engine, table, schema, spec, pd, top_n):
    n_expr = num_expr(spec.x)
    t = quote_ident(table)
    n, lo, hi, mean, med, std, q1, q3 = engine.fetchone(
        f"SELECT count({n_expr}), min({n_expr}), max({n_expr}), avg({n_expr}), median({n_expr}), "
        f"stddev_samp({n_expr}), quantile_cont({n_expr},0.25), quantile_cont({n_expr},0.75) FROM {t}")
    n = int(n)
    if n == 0:
        raise _Invalid(f"'{spec.x}' has no valid numeric values (all values are missing or not numbers).")
    if n < CHARTS["histogram"].min_obs:
        raise _Invalid(f"'{spec.x}' has only {_plural(n, 'valid value')}; a histogram needs at least 2.")
    total = engine.row_count(table)
    if n < total:
        pd.warnings.append(f"{total - n:,} missing/invalid value(s) in '{spec.x}' were left out.")
    constant = lo == hi
    if constant:
        pd.warnings.append(f"All {n:,} values equal {lo:g}; showing a single bar and no density curve.")
        edges, counts = np.array([lo - 0.5, lo + 0.5]), np.array([n])
        kde_vals = np.array([])
    else:
        iqr = (q3 - q1) if q1 is not None else 0
        width = 2 * iqr * n ** (-1 / 3) if iqr and iqr > 0 else (hi - lo) / (1 + math.log2(n))
        bins = int(np.clip(math.ceil((hi - lo) / width), 5, 100)) if width > 0 else 10
        w = (hi - lo) / bins
        rows = engine.fetchall(
            f"SELECT least(CAST(floor(({n_expr} - {lo!r}) / {w!r}) AS INTEGER), {bins - 1}) b, count(*) "
            f"FROM {t} WHERE {n_expr} IS NOT NULL GROUP BY b")
        counts = np.zeros(bins, dtype=np.int64)
        for b, c in rows:
            counts[int(b)] = c
        edges = lo + w * np.arange(bins + 1)
        sample_sql = f"SELECT {n_expr} v FROM {t} WHERE {n_expr} IS NOT NULL"
        if n > KDE_POINTS:
            sample_sql = (f"SELECT v FROM (SELECT {n_expr} v FROM {t} WHERE {n_expr} IS NOT NULL) "
                          f"USING SAMPLE reservoir({KDE_POINTS} ROWS) REPEATABLE (42)")
            pd.notes.append(f"Density curve estimated from a random sample of {KDE_POINTS:,} of {n:,} values; "
                            "bars, mean and median use all values.")
        kde_vals = np.array([r[0] for r in engine.fetchall(sample_sql)], dtype=float)
    pd.payload = dict(edges=edges, counts=counts, kde_values=kde_vals, mean=mean, median=med,
                      std=std, n=n, constant=constant, column=spec.x)


def _box(engine, table, schema, spec, pd, top_n):
    t = quote_ident(table)
    y = num_expr(spec.y)
    nvalid = int(engine.scalar(f"SELECT count({y}) FROM {t}"))
    if nvalid == 0:
        raise _Invalid(f"'{spec.y}' has no valid numeric values (all missing or not numbers).")
    if spec.x:
        gx = f"CAST({quote_ident(spec.x)} AS VARCHAR)"
        where = f"{y} IS NOT NULL AND NOT {missing_expr(spec.x, schema[spec.x])}"
    else:
        gx = "'All data'"
        where = f"{y} IS NOT NULL"
    base = f"SELECT {gx} g, {y} v, rowid rid FROM {t} WHERE {where}"
    ngroups, nrows = engine.fetchone(f"SELECT count(DISTINCT g), count(*) FROM ({base})")
    if nrows == 0:
        raise _Invalid(f"No rows have both a group value in '{spec.x}' and a valid number in '{spec.y}'.")
    if spec.x and ngroups > 50 and ngroups / nrows > 0.9:
        raise _Invalid(f"'{spec.x}' has {ngroups:,} different values for {nrows:,} rows - nearly every row is "
                       "its own group, so box plots would be meaningless. Choose a column with fewer categories.")
    if nrows < 3:
        raise _Invalid(f"Only {_plural(nrows, 'valid row')} found; a box plot needs at least 3 values.")
    top = engine.fetchall(f"SELECT g FROM ({base}) GROUP BY g HAVING count(*) >= 3 "
                          f"ORDER BY count(*) DESC, g LIMIT {top_n}")
    groups = [r[0] for r in top]
    if not groups:
        raise _Invalid("Every group has fewer than 3 values, so quartiles cannot be estimated.")
    if ngroups > len(groups):
        pd.warnings.append(f"Showing the {len(groups)} largest of {ngroups:,} groups with at least 3 values; "
                           "other groups were left out.")
    in_list = ", ".join("'" + g.replace("'", "''") + "'" for g in groups)
    stats = engine.fetchall(
        f"WITH b AS ({base}), s AS (SELECT g, count(*) n, avg(v) mean, quantile_cont(v,.25) q1, "
        f"quantile_cont(v,.5) med, quantile_cont(v,.75) q3 FROM b WHERE g IN ({in_list}) GROUP BY g) "
        f"SELECT s.g, any_value(s.n), any_value(s.mean), any_value(s.q1), any_value(s.med), any_value(s.q3), "
        f"min(b.v) FILTER (WHERE b.v >= s.q1 - 1.5*(s.q3-s.q1)), "
        f"max(b.v) FILTER (WHERE b.v <= s.q3 + 1.5*(s.q3-s.q1)), "
        f"count(*) FILTER (WHERE b.v < s.q1 - 1.5*(s.q3-s.q1) OR b.v > s.q3 + 1.5*(s.q3-s.q1)) "
        f"FROM b JOIN s USING (g) GROUP BY s.g")
    order = {g: i for i, g in enumerate(groups)}
    stats.sort(key=lambda r: order[r[0]])
    fl = engine.fetchall(
        f"WITH b AS ({base}), s AS (SELECT g, quantile_cont(v,.25) q1, quantile_cont(v,.75) q3 "
        f"FROM b WHERE g IN ({in_list}) GROUP BY g) "
        f"SELECT g, v FROM (SELECT b.g, b.v, row_number() OVER (PARTITION BY b.g ORDER BY hash(b.rid)) rk "
        f"FROM b JOIN s USING (g) WHERE b.v < s.q1 - 1.5*(s.q3-s.q1) OR b.v > s.q3 + 1.5*(s.q3-s.q1)) "
        f"WHERE rk <= 200")
    fliers: dict[str, list[float]] = {}
    for g, v in fl:
        fliers.setdefault(g, []).append(v)
    boxes = []
    for g, n, mean, q1, med, q3, wl, wh, nout in stats:
        boxes.append(dict(label=g, n=int(n), mean=mean, q1=q1, med=med, q3=q3,
                          whislo=wl if wl is not None else q1, whishi=wh if wh is not None else q3,
                          n_outliers=int(nout), fliers=fliers.get(g, [])))
    pd.payload = dict(boxes=boxes, y=spec.y, x=spec.x)


def _scatter(engine, table, schema, spec, pd, top_n):
    t = quote_ident(table)
    xe, ye = num_expr(spec.x), num_expr(spec.y)
    pairs = f"SELECT {xe} x, {ye} y FROM {t}"
    valid = f"SELECT x, y FROM ({pairs}) WHERE x IS NOT NULL AND y IS NOT NULL"
    n, vx, vy, r, slope, icpt, r2, xlo, xhi = engine.fetchone(
        f"SELECT count(*), var_pop(x), var_pop(y), corr(x,y), regr_slope(y,x), regr_intercept(y,x), "
        f"regr_r2(y,x), min(x), max(x) FROM ({valid})")
    n = int(n)
    total = engine.row_count(table)
    if n == 0:
        raise _Invalid(f"No row has a valid number in both '{spec.x}' and '{spec.y}' "
                       "(every row is missing one of them).")
    if n < CHARTS["scatter"].min_obs:
        raise _Invalid(f"Only {_plural(n, 'row')} have valid values for both columns; "
                       "a scatter plot with regression needs at least 3.")
    if n < total:
        pd.warnings.append(f"{total - n:,} row(s) with a missing/invalid value in either column were left out.")
    regression = True
    if not vx or vx == 0:
        regression = False
        pd.warnings.append(f"'{spec.x}' is constant, so no regression line or correlation can be computed.")
    elif not vy or vy == 0:
        regression = False
        pd.warnings.append(f"'{spec.y}' is constant, so no regression line or correlation can be computed.")
    sql = valid
    if n > spec.max_points:
        sql = f"SELECT x, y FROM ({valid}) USING SAMPLE reservoir({int(spec.max_points)} ROWS) REPEATABLE (42)"
        pd.notes.append(f"Showing a random sample of {spec.max_points:,} of {n:,} points. "
                        "Correlation and the regression line use all rows.")
    rows = np.array(engine.fetchall(sql), dtype=float)
    pd.payload = dict(x=rows[:, 0], y=rows[:, 1], n=n, r=r if regression else None,
                      slope=slope if regression else None, intercept=icpt if regression else None,
                      r2=r2 if regression else None, xlo=xlo, xhi=xhi, xname=spec.x, yname=spec.y)


def _bar(engine, table, schema, spec, pd, top_n):
    t = quote_ident(table)
    x = quote_ident(spec.x)
    present = f"NOT {missing_expr(spec.x, schema[spec.x])}"
    agg = spec.agg if spec.y else "count"
    if spec.y:
        if agg == "count":
            agg = "mean"  # a value column was chosen, so aggregate it (default mean)
        ye = num_expr(spec.y)
        if agg in ("min", "max", "mean", "sum", "median"):
            val = f"{agg}({ye})"
        base_where = f"{present} AND {ye} IS NOT NULL"
    else:
        val = "count(*)"
        base_where = present
    nrows, ncat = engine.fetchone(f"SELECT count(*), count(DISTINCT {x}) FROM {t} WHERE {base_where}")
    if nrows == 0:
        what = f"'{spec.x}' and a valid number in '{spec.y}'" if spec.y else f"'{spec.x}'"
        raise _Invalid(f"No rows have a value in {what}.")
    if ncat > 50 and ncat / nrows > 0.9:
        raise _Invalid(f"'{spec.x}' has {ncat:,} different values for {nrows:,} rows - almost every value is "
                       "unique, so a bar chart would be unreadable. Choose a column with repeated categories.")
    rows = engine.fetchall(
        f"WITH g AS (SELECT CAST({x} AS VARCHAR) c, {val} v FROM {t} WHERE {base_where} GROUP BY {x}) "
        f"SELECT c, v FROM g ORDER BY v DESC, c LIMIT {top_n}")
    if ncat > top_n:
        pd.warnings.append(f"Showing the top {top_n} of {ncat:,} categories (by value).")
    if spec.sort != "value_desc":
        rows.sort(key=(lambda r: r[0]) if spec.sort == "label" else (lambda r: r[1]), reverse=False)
    if ncat == 1:
        pd.warnings.append("Only one category was found.")
    skipped = engine.row_count(table) - nrows
    if skipped > 0:
        pd.warnings.append(f"{skipped:,} row(s) with a missing category or value were left out.")
    label = {"count": "Count", "mean": "Mean", "sum": "Sum", "median": "Median",
             "min": "Minimum", "max": "Maximum"}[agg]
    pd.payload = dict(labels=[r[0] for r in rows], values=[float(r[1]) for r in rows], x=spec.x, y=spec.y,
                      agg=agg, measure=f"{label} of {spec.y}" if spec.y else "Count of rows", n=nrows,
                      categories=ncat)


def _line(engine, table, schema, spec, pd, top_n):
    t = quote_ident(table)
    xkind = type_kind(schema[spec.x])
    ye = num_expr(spec.y)
    xcol = quote_ident(spec.x)
    xe = num_expr(spec.x) if xkind == "numeric" else xcol
    valid = f"SELECT {xe} x, {ye} y FROM {t} WHERE {xe} IS NOT NULL AND {ye} IS NOT NULL"
    n, nd, xmin, xmax = engine.fetchone(
        f"SELECT count(*), count(DISTINCT x), min(x), max(x) FROM ({valid})")
    n = int(n)
    if n == 0:
        raise _Invalid(f"No row has valid values in both '{spec.x}' and '{spec.y}'.")
    if nd < 2:
        raise _Invalid(f"'{spec.x}' has only {_plural(int(nd), 'distinct value')} among the valid rows; "
                       "a line needs at least 2 different X values.")
    agg = spec.agg if spec.agg in ("mean", "sum", "median", "min", "max") else "mean"
    fn = f"{agg}(y)"
    group = "x"
    x_note = None
    if nd > spec.max_points:
        if xkind == "numeric":
            w = (xmax - xmin) / spec.max_points
            group = f"{xmin!r} + floor((x - {xmin!r}) / {w!r}) * {w!r}"
            x_note = f"X was grouped into {spec.max_points:,} equal-width bins"
        else:
            span_days = max(1, (xmax - xmin).days if hasattr(xmax - xmin, "days") else 1)
            for unit, days in (("day", 1), ("week", 7), ("month", 30), ("quarter", 91), ("year", 365)):
                if span_days / days <= spec.max_points:
                    break
            group = f"date_trunc('{unit}', x)"
            x_note = f"X was grouped by {unit}"
    rows = engine.fetchall(f"SELECT {group} gx, {fn} FROM ({valid}) GROUP BY gx ORDER BY gx")
    if x_note:
        pd.notes.append(f"{x_note} because there are {int(nd):,} distinct values; each point is the {agg} of its group.")
    if n > nd:
        pd.warnings.append(f"Several rows share the same X value; each point shows the {agg} of '{spec.y}'.")
    if n < engine.row_count(table):
        pd.warnings.append(f"{engine.row_count(table) - n:,} row(s) with a missing/invalid X or Y were left out.")
    pd.payload = dict(x=[r[0] for r in rows], y=[float(r[1]) for r in rows], xname=spec.x, yname=spec.y,
                      agg=agg, is_time=(xkind == "datetime"))
