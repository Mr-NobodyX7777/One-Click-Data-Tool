"""Matplotlib rendering. Only ever called with a validated PlotData."""
from __future__ import annotations

import numpy as np
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter

from visualizer.validation import CHARTS, PlotData

ACCENT = "#2f6fb3"
ACCENT_2 = "#d9822b"
INK = "#1f2933"
GRID = "#d8dee6"


def _fmt_num(v: float) -> str:
    a = abs(v)
    if a >= 1e9:
        return f"{v / 1e9:.3g}B"
    if a >= 1e6:
        return f"{v / 1e6:.3g}M"
    if a >= 1e4:
        return f"{v / 1e3:.3g}K"
    return f"{v:.4g}"


def _style(ax, grid: bool = True) -> None:
    ax.set_facecolor("white")
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    ax.spines["left"].set_color("#9aa5b1")
    ax.spines["bottom"].set_color("#9aa5b1")
    ax.tick_params(colors=INK, labelsize=9)
    if grid:
        ax.grid(True, color=GRID, linewidth=0.7, alpha=0.8)
        ax.set_axisbelow(True)


def render(plot: PlotData, width: float = 9.0, height: float = 5.6, title: str | None = None) -> Figure:
    if not plot.ok:
        raise ValueError("Refusing to draw a chart that failed validation.")
    fig = Figure(figsize=(width, height), facecolor="white", layout="constrained")
    ax = fig.add_subplot(111)
    _style(ax)
    drawer = {"histogram": _histogram, "box": _box, "scatter": _scatter,
              "bar": _bar, "line": _line}[plot.spec.kind]
    default_title = drawer(ax, plot.payload)
    ax.set_title(title or default_title, fontsize=13, fontweight="bold", color=INK, loc="left")
    return fig


def _histogram(ax, d) -> str:
    edges, counts = d["edges"], d["counts"]
    widths = np.diff(edges)
    ax.bar(edges[:-1], counts, width=widths, align="edge", color=ACCENT, alpha=0.55,
           edgecolor="white", linewidth=0.6, label=f"Count (n = {d['n']:,})")
    vals = d["kde_values"]
    if not d["constant"] and len(vals) >= 5 and np.std(vals) > 0:
        try:
            from scipy.stats import gaussian_kde
            xs = np.linspace(edges[0], edges[-1], 300)
            dens = gaussian_kde(vals)(xs) * d["n"] * widths[0]
            ax.plot(xs, dens, color=INK, linewidth=1.8, label="Density (KDE)")
        except Exception:
            pass
    ax.axvline(d["mean"], color=ACCENT_2, linestyle="--", linewidth=1.8, label=f"Mean = {_fmt_num(d['mean'])}")
    ax.axvline(d["median"], color="#2a9d6f", linestyle="-", linewidth=1.8, label=f"Median = {_fmt_num(d['median'])}")
    ax.set_xlabel(d["column"])
    ax.set_ylabel("Count")
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: _fmt_num(v)))
    ax.legend(frameon=False, fontsize=9)
    return f"Distribution of {d['column']}"


def _box(ax, d) -> str:
    boxes = d["boxes"]
    stats = []
    for b in boxes:
        stats.append(dict(label=f"{_short(b['label'])}\n(n={b['n']:,})", q1=b["q1"], med=b["med"], q3=b["q3"],
                          whislo=b["whislo"], whishi=b["whishi"], fliers=b["fliers"], mean=b["mean"]))
    ax.bxp(stats, showmeans=True, showfliers=True, patch_artist=True, widths=0.55,
           boxprops=dict(facecolor="#bcd3ea", edgecolor=ACCENT),
           medianprops=dict(color=INK, linewidth=2), whiskerprops=dict(color=ACCENT), capprops=dict(color=ACCENT),
           flierprops=dict(marker="o", markersize=3.5, markerfacecolor=ACCENT_2, markeredgecolor="none", alpha=0.6),
           meanprops=dict(marker="D", markerfacecolor="white", markeredgecolor=INK, markersize=5))
    ax.set_ylabel(d["y"])
    if d["x"]:
        ax.set_xlabel(d["x"])
    if len(boxes) > 6:
        for lab in ax.get_xticklabels():
            lab.set_rotation(40)
            lab.set_ha("right")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: _fmt_num(v)))
    out = sum(b["n_outliers"] for b in boxes)
    ax.text(0.99, 0.99, f"Box = Q1-Q3 (IQR)   line = median   diamond = mean\nwhiskers = 1.5 x IQR   dots = outliers ({out:,})",
            transform=ax.transAxes, ha="right", va="top", fontsize=8, color="#52606d")
    return f"{d['y']} by {d['x']}" if d["x"] else f"Distribution of {d['y']}"


def _scatter(ax, d) -> str:
    ax.scatter(d["x"], d["y"], s=14, color=ACCENT, alpha=0.45, edgecolors="none")
    if d["slope"] is not None:
        xs = np.array([d["xlo"], d["xhi"]])
        ax.plot(xs, d["slope"] * xs + d["intercept"], color=ACCENT_2, linewidth=2)
        sign = "+" if d["intercept"] >= 0 else "-"
        ax.text(0.01, 0.99,
                f"r = {d['r']:.3f}   R² = {d['r2']:.3f}\ny = {d['slope']:.4g}x {sign} {abs(d['intercept']):.4g}\n"
                f"n = {d['n']:,} pairs",
                transform=ax.transAxes, va="top", fontsize=9, color=INK,
                bbox=dict(boxstyle="round,pad=0.4", facecolor="white", edgecolor=GRID))
    else:
        ax.text(0.01, 0.99, f"n = {d['n']:,} pairs", transform=ax.transAxes, va="top", fontsize=9, color=INK)
    ax.set_xlabel(d["xname"])
    ax.set_ylabel(d["yname"])
    for axis in (ax.xaxis, ax.yaxis):
        axis.set_major_formatter(FuncFormatter(lambda v, _: _fmt_num(v)))
    return f"{d['yname']} vs {d['xname']}"


def _bar(ax, d) -> str:
    labels, values = d["labels"], d["values"]
    horizontal = len(labels) > 8 or max(len(str(l)) for l in labels) > 12
    pos = np.arange(len(labels))
    if horizontal:
        bars = ax.barh(pos, values, color=ACCENT, alpha=0.85)
        ax.set_yticks(pos, [_short(l, 28) for l in labels])
        ax.invert_yaxis()
        ax.set_xlabel(d["measure"])
        ax.set_ylabel(d["x"])
        ax.xaxis.set_major_formatter(FuncFormatter(lambda v, _: _fmt_num(v)))
        ax.grid(axis="y", visible=False)
    else:
        bars = ax.bar(pos, values, color=ACCENT, alpha=0.85)
        ax.set_xticks(pos, [_short(l, 14) for l in labels])
        ax.set_ylabel(d["measure"])
        ax.set_xlabel(d["x"])
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: _fmt_num(v)))
        ax.grid(axis="x", visible=False)
    if len(labels) <= 30:
        ax.bar_label(bars, labels=[_fmt_num(v) for v in values], fontsize=8, color=INK, padding=3)
    ax.margins(x=0.08 if horizontal else 0.02)
    return f"{d['measure']} by {d['x']}"


def _line(ax, d) -> str:
    marker = "o" if len(d["x"]) <= 60 else None
    ax.plot(d["x"], d["y"], color=ACCENT, linewidth=1.8, marker=marker, markersize=4)
    ax.set_xlabel(d["xname"])
    ax.set_ylabel(f"{d['agg'].title()} of {d['yname']}")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _: _fmt_num(v)))
    if d["is_time"]:
        ax.figure.autofmt_xdate()
    return f"{d['yname']} over {d['xname']}"


def _short(s, n: int = 20) -> str:
    s = str(s)
    return s if len(s) <= n else s[: n - 1] + "…"


def chart_title(kind: str) -> str:
    return CHARTS[kind].title
