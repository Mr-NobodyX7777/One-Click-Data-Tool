# First-time setup window: shows what is being downloaded, a percentage and an estimated time remaining.
# It reads pip's log file (written by the launcher) and closes itself when setup finishes or fails.
param([string]$Done, [string]$Fail, [string]$Handoff, [string]$Log)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

function C($hex) { return [System.Drawing.ColorTranslator]::FromHtml($hex) }

$form = New-Object System.Windows.Forms.Form
$form.Text = "OneClick Data Tool"
$form.FormBorderStyle = "None"
$form.StartPosition = "CenterScreen"
$form.Size = New-Object System.Drawing.Size(560, 430)
$form.BackColor = C "#0e1a1f"
$form.TopMost = $true

function Add-Label($text, $size, $color, $x, $y, $w, $h, $bold) {
    $l = New-Object System.Windows.Forms.Label
    $l.Text = $text
    $style = [System.Drawing.FontStyle]::Regular
    if ($bold) { $style = [System.Drawing.FontStyle]::Bold }
    $l.Font = New-Object System.Drawing.Font("Segoe UI", $size, $style)
    $l.ForeColor = C $color
    $l.BackColor = [System.Drawing.Color]::Transparent
    $l.Location = New-Object System.Drawing.Point($x, $y)
    $l.Size = New-Object System.Drawing.Size($w, $h)
    $form.Controls.Add($l)
    return $l
}

$null = Add-Label "OneClick Data Tool" 22 "#2dd4bf" 32 22 400 46 $true
$null = Add-Label "First-time setup  -  happens only once" 11 "#e4f0f2" 34 72 480 26 $true
$null = Add-Label "Downloading the components the app needs. After this the app runs fully offline. Please keep this window open - the app starts by itself." 9 "#8fb0b7" 34 100 490 40 $false

$lblPct = Add-Label "0%" 26 "#2dd4bf" 410 138 120 48 $true
$lblPct.TextAlign = "MiddleRight"
$lblNow = Add-Label "Preparing..." 11 "#e4f0f2" 34 146 380 28 $true
$lblSub = Add-Label "" 9 "#8fb0b7" 34 174 380 22 $false

$bar = New-Object System.Windows.Forms.ProgressBar
$bar.Style = "Continuous"
$bar.Minimum = 0
$bar.Maximum = 1000
$bar.Location = New-Object System.Drawing.Point(34, 202)
$bar.Size = New-Object System.Drawing.Size(492, 14)
$form.Controls.Add($bar)

$lblEta = Add-Label "Estimating time remaining..." 10 "#e4f0f2" 34 224 492 24 $false

$list = New-Object System.Windows.Forms.ListBox
$list.Location = New-Object System.Drawing.Point(34, 254)
$list.Size = New-Object System.Drawing.Size(492, 130)
$list.BackColor = C "#16262d"
$list.ForeColor = C "#8fb0b7"
$list.BorderStyle = "None"
$list.Font = New-Object System.Drawing.Font("Consolas", 9)
$list.IntegralHeight = $false
$form.Controls.Add($list)

$null = Add-Label "Typical total: 3 - 10 minutes, depending on your internet speed." 8 "#8fb0b7" 34 394 490 22 $false

# Friendly names for the packages
$friendly = @{
    "pyside6_essentials" = "Window and interface toolkit"
    "pyside6" = "Window and interface toolkit"
    "shiboken6" = "Interface toolkit helper"
    "duckdb" = "Data engine"
    "polars" = "Fast data tables"
    "polars_runtime_32" = "Fast data tables (core)"
    "pyarrow" = "Data file support"
    "matplotlib" = "Charts and graphs"
    "scipy" = "Statistics tools"
    "numpy" = "Number crunching"
    "openpyxl" = "Excel file support"
    "pillow" = "Image support"
    "fonttools" = "Chart fonts"
    "kiwisolver" = "Chart layout"
    "contourpy" = "Chart contours"
}

$script:startTime = Get-Date
$script:expectedMB = 150.0      # rough total download size; adjusted upward if reality is bigger
$script:dlStart = $null
$script:lastKey = ""
$script:lastKeyTime = Get-Date
$script:installStart = $null
$script:shown = 0.0
$script:doneAt = $null

function Read-Log {
    if (-not $Log -or -not (Test-Path $Log)) { return @() }
    try {
        $fs = [System.IO.File]::Open($Log, 'Open', 'Read', 'ReadWrite')
        $sr = New-Object System.IO.StreamReader($fs)
        $text = $sr.ReadToEnd()
        $sr.Close(); $fs.Close()
        return ($text -split "`r?`n")
    } catch { return @() }
}

function To-MB($num, $unit) {
    $n = [double]::Parse($num, [System.Globalization.CultureInfo]::InvariantCulture)
    switch ($unit.ToLower()) {
        "kb" { return $n / 1024.0 }
        "gb" { return $n * 1024.0 }
        default { return $n }
    }
}

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 400
$timer.Add_Tick({
    if ($Fail -and (Test-Path $Fail)) { $timer.Stop(); $form.Close(); return }

    $now = Get-Date
    $lines = Read-Log
    $files = @()        # download entries: name, version, mb
    $installing = $false
    $finished = $false
    $found = @()
    $lastRaw = ""
    foreach ($ln in $lines) {
        if ($ln.Trim().Length -gt 0) { $lastRaw = $ln.Trim() }
        if ($ln -match '^Collecting\s+([A-Za-z0-9_.\-]+)') { $found += $Matches[1] }
        if ($ln -match '^\s*(?:Downloading|Using cached)\s+(\S+\.whl|\S+\.tar\.gz)\s+\(([\d.]+)\s*(kB|MB|GB)\)') {
            $fname = $Matches[1]; $mb = To-MB $Matches[2] $Matches[3]
            $parts = $fname -split '-'
            $pkg = ($parts[0]).ToLower().Replace('-', '_')
            $ver = ""
            if ($parts.Length -gt 1) { $ver = $parts[1] }
            $files += ,@($pkg, $ver, $mb)
        }
        if ($ln -match '^\s*Installing collected packages') { $installing = $true }
        if ($ln -match '^\s*Successfully installed') { $finished = $true }
    }

    $doneMB = 0.0
    $curMB = 0.0
    $curName = ""
    $n = $files.Count
    for ($i = 0; $i -lt $n; $i++) {
        $isLast = ($i -eq $n - 1)
        if ($isLast -and -not $installing -and -not $finished) {
            $curMB = $files[$i][2]; $curName = $files[$i][0]
        } else { $doneMB += $files[$i][2] }
    }

    # list of completed downloads
    $wantRows = @()
    for ($i = 0; $i -lt $n; $i++) {
        $p = $files[$i][0]
        if ($i -eq $n - 1 -and -not $installing -and -not $finished) { continue }
        $label = $p; if ($friendly.ContainsKey($p)) { $label = $friendly[$p] }
        $wantRows += ("[done]  {0}  ({1:N1} MB)" -f $label, $files[$i][2])
    }
    if ($n -eq 0) {
        $wantRows = @()
        foreach ($f in ($found | Select-Object -Unique)) { $wantRows += ("[found]  {0}" -f $f) }
    }
    if ($list.Items.Count -ne $wantRows.Count) {
        $list.BeginUpdate(); $list.Items.Clear()
        foreach ($r in $wantRows) { [void]$list.Items.Add($r) }
        $list.EndUpdate()
        $list.TopIndex = [Math]::Max(0, $list.Items.Count - 1)
    }

    # position within the file currently downloading (estimated from the average speed so far)
    if ($n -gt 0 -and -not $script:dlStart) { $script:dlStart = $now }
    $key = "$n"
    if ($key -ne $script:lastKey) { $script:lastKey = $key; $script:lastKeyTime = $now }
    $speed = 0.0
    if ($script:dlStart) {
        $dt = ($now - $script:dlStart).TotalSeconds
        if ($dt -gt 3 -and $doneMB -gt 1) { $speed = $doneMB / $dt }
    }
    $interp = 0.0
    if ($curMB -gt 0) {
        $since = ($now - $script:lastKeyTime).TotalSeconds
        if ($speed -gt 0) { $interp = [Math]::Min($curMB * 0.95, $speed * $since) }
        else { $interp = [Math]::Min($curMB * 0.5, 0.4 * $since) }
    }
    $seen = $doneMB + $curMB
    if ($seen -gt $script:expectedMB * 0.9) { $script:expectedMB = $seen + 20 }

    $pct = 0.0
    $nowText = "Preparing the Python environment..."
    $subText = ""
    $etaText = "Estimating time remaining..."

    if ($n -eq 0 -and $lines.Count -gt 1) {
        $nowText = "Checking which components are needed..."
        $pct = 1
        if ($found.Count -gt 0) { $subText = "Found: " + $found[$found.Count - 1] }
    }
    if ($n -gt 0) {
        $frac = ($doneMB + $interp) / $script:expectedMB
        $pct = 3 + 82 * [Math]::Min($frac, 1.0)
        $label = $curName; if ($friendly.ContainsKey($curName)) { $label = $friendly[$curName] }
        $nowText = "Downloading: $label"
        $subText = ("{0}   ({1:N1} MB)" -f $curName, $curMB)
        if ($speed -gt 0 -and $doneMB -ge 8) {
            $remain = [Math]::Max($script:expectedMB - $doneMB - $interp, 0) / $speed + 45
            $etaText = "About " + (Format-Eta $remain) + " remaining   -   " + ("{0:N1} MB/s" -f $speed)
        }
    }
    if ($installing -and -not $finished) {
        if (-not $script:installStart) { $script:installStart = $now }
        $s = ($now - $script:installStart).TotalSeconds
        $pct = 88 + [Math]::Min(10, $s / 4.0)
        $nowText = "Installing the downloaded components..."
        $subText = "This part has no download - almost there"
        $etaText = "Finishing up - about a minute remaining"
    }
    if ($finished -or ($Done -and (Test-Path $Done))) {
        $pct = 100
        $nowText = "All set - starting the app..."
        $subText = ""
        $etaText = "Done"
        if (-not $script:doneAt) { $script:doneAt = $now }
    }

    if ($pct -lt $script:shown) { $pct = $script:shown }   # never move backwards
    $script:shown = $pct
    $lblPct.Text = ("{0}%" -f [int][Math]::Floor($pct))
    $bar.Value = [int][Math]::Min(1000, [Math]::Round($pct * 10))
    $lblNow.Text = $nowText
    if ($subText -eq "" -and $lastRaw -ne "" -and -not $script:doneAt) {
        $subText = $lastRaw; if ($subText.Length -gt 60) { $subText = $subText.Substring(0, 60) + "..." }
    }
    $lblSub.Text = $subText
    $lblEta.Text = $etaText

    if ($script:doneAt) {
        $handedOver = $Handoff -and (Test-Path $Handoff)
        if ($handedOver -or ($now - $script:doneAt).TotalSeconds -gt 30) { $timer.Stop(); $form.Close() }
    }
})

function Format-Eta($seconds) {
    if ($seconds -lt 60) { return "less than a minute" }
    $m = [Math]::Ceiling($seconds / 60.0)
    if ($m -eq 1) { return "1 minute" }
    return "$m minutes"
}

$timer.Start()
[void]$form.ShowDialog()
