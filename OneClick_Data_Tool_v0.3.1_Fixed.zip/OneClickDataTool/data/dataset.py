"""A dataset = original (immutable) + working versions (for undo/redo) in DuckDB.

Logical separation required by the spec:
  original source  -> the file on disk, never touched (sources are opened read-only)
  original table   -> immutable copy imported into DuckDB
  working dataset  -> the current version; every cleaning step creates a new version
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from datetime import datetime

from cleaner.history import HistoryEntry, HistoryLog
from data.duckdb_manager import Engine
from data.types import quote_ident

_ids = itertools.count(1)


@dataclass
class DatasetInfo:
    source_name: str
    format: str
    detail: str = ""
    file_size: int | None = None
    source_path: str | None = None
    import_config: dict = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    imported_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    storage: str = "DuckDB (temporary local database)"


class Dataset:
    MAX_UNDO = 8  # versions kept for undo; each version is a full table on disk

    def __init__(self, engine: Engine, name: str, info: DatasetInfo, original_table: str):
        self.engine = engine
        self.id = next(_ids)
        self.name = name
        self.info = info
        self.original = original_table
        self.stack: list[str] = [original_table]
        self.pos = 0
        self.history = HistoryLog()
        self.version = 0  # bumped on every change; used for cache invalidation
        self.original_rows = engine.row_count(original_table)

    # -- state ------------------------------------------------------------------
    @property
    def current(self) -> str:
        return self.stack[self.pos]

    def columns(self) -> list[tuple[str, str]]:
        return self.engine.schema(self.current)

    def column_names(self) -> list[str]:
        return [c for c, _ in self.columns()]

    def row_count(self) -> int:
        return self.engine.row_count(self.current)

    @property
    def can_undo(self) -> bool:
        return self.pos > 0

    @property
    def can_redo(self) -> bool:
        return self.pos < len(self.stack) - 1

    @property
    def is_modified(self) -> bool:
        return self.current != self.original

    # -- changes ------------------------------------------------------------------
    def apply(self, plan) -> HistoryEntry:
        """Apply an OperationPlan: create a new version, never edit in place."""
        new = self.engine.new_table_name(f"ds{self.id}")
        self.engine.execute(f"CREATE TABLE {quote_ident(new)} AS {plan.sql}", plan.params)
        for t in self.stack[self.pos + 1:]:  # discard redo branch
            self.engine.drop_table(t)
        del self.stack[self.pos + 1:]
        self.stack.append(new)
        self.pos += 1
        while len(self.stack) > self.MAX_UNDO + 1:
            old = self.stack.pop(0)
            self.pos -= 1
            if old != self.original:
                self.engine.drop_table(old)
        rows_after = self.engine.row_count(new)
        entry = HistoryEntry(plan.action, plan.column, plan.affected, plan.current_rows,
                             rows_after, plan.parameters)
        self.history.add(entry)
        self.version += 1
        return entry

    def undo(self) -> bool:
        if not self.can_undo:
            return False
        self.pos -= 1
        self.history.mark_last("applied", "undone")
        self.version += 1
        return True

    def redo(self) -> bool:
        if not self.can_redo:
            return False
        self.pos += 1
        self.history.mark_last("undone", "applied", newest_first=False)
        self.version += 1
        return True

    def reset_to_original(self) -> None:
        for t in self.stack:
            if t != self.original:
                self.engine.drop_table(t)
        self.stack = [self.original]
        self.pos = 0
        self.history.revert_all()
        self.version += 1

    def close(self) -> None:
        for t in set(self.stack + [self.original]):
            self.engine.drop_table(t)
