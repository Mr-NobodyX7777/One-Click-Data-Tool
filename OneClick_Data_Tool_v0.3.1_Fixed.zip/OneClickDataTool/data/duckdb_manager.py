"""The common data engine: one embedded DuckDB database per application session.

The database file lives in a private temporary folder, so large datasets are
disk-backed (DuckDB spills to disk) instead of having to fit in RAM. Everything
is deleted when the engine is closed. Nothing here touches the network.
"""
from __future__ import annotations

import itertools
import shutil
import tempfile
import threading
from pathlib import Path

import duckdb
import polars as pl

from data.types import quote_ident


class Engine:
    def __init__(self, temp_dir: str | None = None):
        self._dir = Path(tempfile.mkdtemp(prefix="oneclick_", dir=temp_dir))
        self._db_path = self._dir / "work.duckdb"
        self._con = duckdb.connect(str(self._db_path))
        self._con.execute(f"SET temp_directory = '{(self._dir / 'spill').as_posix()}'")
        self._counter = itertools.count(1)
        self._lock = threading.Lock()
        self.closed = False

    # -- naming ---------------------------------------------------------
    def new_table_name(self, prefix: str = "t") -> str:
        return f"{prefix}_{next(self._counter)}"

    # -- execution ------------------------------------------------------
    def cursor(self) -> duckdb.DuckDBPyConnection:
        """A thread-safe cursor on the shared database (one per call/thread)."""
        with self._lock:
            return self._con.cursor()

    def execute(self, sql: str, params=None):
        cur = self.cursor()
        cur.execute(sql, params or [])
        return cur

    def fetchall(self, sql: str, params=None) -> list[tuple]:
        return self.execute(sql, params).fetchall()

    def fetchone(self, sql: str, params=None):
        return self.execute(sql, params).fetchone()

    def scalar(self, sql: str, params=None):
        row = self.fetchone(sql, params)
        return None if row is None else row[0]

    def polars(self, sql: str, params=None) -> pl.DataFrame:
        from data.duckdb_compat import to_polars
        return to_polars(self.execute(sql, params))

    # -- schema helpers ------------------------------------------------------
    def schema(self, table: str) -> list[tuple[str, str]]:
        rows = self.fetchall(f"DESCRIBE {quote_ident(table)}")
        return [(r[0], r[1]) for r in rows]

    def row_count(self, table: str) -> int:
        return int(self.scalar(f"SELECT count(*) FROM {quote_ident(table)}"))

    def drop_table(self, table: str) -> None:
        self.execute(f"DROP TABLE IF EXISTS {quote_ident(table)}")

    def register_arrow(self, table: str, arrow_table) -> None:
        cur = self.cursor()
        cur.register("_incoming", arrow_table)
        cur.execute(f"CREATE TABLE {quote_ident(table)} AS SELECT * FROM _incoming")
        cur.unregister("_incoming")

    # -- lifecycle ----------------------------------------------------------
    def close(self) -> None:
        if self.closed:
            return
        self.closed = True
        try:
            self._con.close()
        finally:
            shutil.rmtree(self._dir, ignore_errors=True)
