"""Turn row-oriented Python data (Excel, SQLite) into a typed Arrow table.

Column types are inferred over *all* values. A column that mixes incompatible
types (e.g. numbers and the word "unknown") is kept as text so that no value is
silently discarded, and a warning is returned so the user can decide how to
convert it later.
"""
from __future__ import annotations

import datetime as dt
from decimal import Decimal

import pyarrow as pa


def _infer(values: list):
    kinds = set()
    for v in values:
        if v is None:
            continue
        if isinstance(v, bool):
            kinds.add("bool")
        elif isinstance(v, int):
            kinds.add("int")
        elif isinstance(v, (float, Decimal)):
            kinds.add("float")
        elif isinstance(v, dt.datetime):
            kinds.add("datetime")
        elif isinstance(v, dt.date):
            kinds.add("date")
        elif isinstance(v, dt.time):
            kinds.add("time")
        elif isinstance(v, (bytes, bytearray)):
            kinds.add("bytes")
        else:
            kinds.add("str")
    return kinds


def build_arrow_table(names: list[str], columns: list[list]) -> tuple[pa.Table, list[str]]:
    warnings: list[str] = []
    arrays = []
    for name, values in zip(names, columns):
        kinds = _infer(values)
        try:
            if not kinds:
                arr = pa.array([None] * len(values), type=pa.string())
            elif kinds == {"bool"}:
                arr = pa.array(values, type=pa.bool_())
            elif kinds == {"int"}:
                try:
                    arr = pa.array(values, type=pa.int64())
                except (pa.ArrowInvalid, OverflowError):
                    arr = pa.array([None if v is None else str(v) for v in values], type=pa.string())
            elif kinds <= {"int", "float"}:
                arr = pa.array([None if v is None else float(v) for v in values], type=pa.float64())
            elif kinds == {"datetime"}:
                arr = pa.array(values, type=pa.timestamp("us"))
            elif kinds == {"date"}:
                arr = pa.array(values, type=pa.date32())
            elif kinds == {"date", "datetime"}:
                arr = pa.array(
                    [None if v is None else (v if isinstance(v, dt.datetime)
                                             else dt.datetime(v.year, v.month, v.day)) for v in values],
                    type=pa.timestamp("us"))
            elif kinds == {"time"}:
                arr = pa.array(values, type=pa.time64("us"))
            elif kinds == {"bytes"}:
                arr = pa.array(values, type=pa.binary())
            else:
                if len(kinds) > 1:
                    warnings.append(
                        f"Column '{name}' mixes different value types ({', '.join(sorted(kinds))}); "
                        "it was loaded as text so that no value is lost.")
                arr = pa.array([None if v is None else str(v) for v in values], type=pa.string())
        except Exception:  # last-resort safety net: keep the data as text
            warnings.append(f"Column '{name}' could not be typed and was loaded as text.")
            arr = pa.array([None if v is None else str(v) for v in values], type=pa.string())
        arrays.append(arr)
    return pa.Table.from_arrays(arrays, names=names), warnings


def unique_names(raw: list) -> list[str]:
    """Make header names non-empty and unique (blank -> column_N, dup -> name_2)."""
    seen: set[str] = set()
    out = []
    for i, h in enumerate(raw, start=1):
        base = "" if h is None else str(h).strip()
        if not base:
            base = f"column_{i}"
        name, k = base, 1
        while name in seen:
            k += 1
            name = f"{base}_{k}"
        seen.add(name)
        out.append(name)
    return out
