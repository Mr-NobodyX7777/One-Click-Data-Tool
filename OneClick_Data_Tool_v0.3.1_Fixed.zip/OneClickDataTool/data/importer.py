"""Import a DataSource (or an in-memory frame) into the engine as a Dataset."""
from __future__ import annotations

from pathlib import Path

import polars as pl

from data.connectors import make_source
from data.connectors.base import DataSource, SourceError
from data.dataset import Dataset, DatasetInfo
from data.duckdb_manager import Engine
from data.types import quote_ident


def protect_reserved_names(engine: Engine, table: str) -> list[str]:
    """DuckDB keeps a hidden `rowid` column that the cleaner/exporter use to preserve row order. A user
    column called "rowid" (any capitalisation) would shadow it and silently scramble the order, so such a
    column is renamed (rowid -> rowid_1). Returns user-facing warnings."""
    names = [c for c, _ in engine.schema(table)]
    taken = {n.casefold() for n in names} | {"rowid"}
    warns = []
    for n in names:
        if n.casefold() == "rowid":
            k, new = 1, None
            while new is None or new.casefold() in taken:
                new = f"{n}_{k}"
                k += 1
            taken.add(new.casefold())
            engine.execute(f"ALTER TABLE {quote_ident(table)} RENAME COLUMN {quote_ident(n)} TO {quote_ident(new)}")
            warns.append(f"Column '{n}' was renamed to '{new}' because 'rowid' is reserved for keeping the row order.")
    return warns


def import_source(engine: Engine, source: DataSource, name: str | None = None) -> Dataset:
    """Load a source into DuckDB. On any failure the partial table is removed, so a
    half-imported dataset can never be mistaken for a complete one."""
    table = engine.new_table_name("orig")
    try:
        source.load_into(engine, table)
        rows = engine.row_count(table)
        if rows == 0:
            raise SourceError("The file has no data rows.",
                              "Only a header (or nothing) was found.",
                              "Check the import options (header row, delimiter) or choose another file.")
        if not engine.schema(table):
            raise SourceError("No columns were found.", "", "")
        source.warnings.extend(protect_reserved_names(engine, table))
    except Exception:
        engine.drop_table(table)
        raise
    detail = source.detail()
    info = DatasetInfo(
        source_name=source.name, format=source.format_name, detail=detail,
        file_size=source.file_size, source_path=source.path,
        import_config=source.config(), warnings=list(source.warnings))
    label = name or (f"{Path(source.path).stem} [{detail}]" if detail else Path(source.path).stem)
    return Dataset(engine, label, info, table)


def import_path(engine: Engine, path: str, fmt: str | None = None, **options) -> Dataset:
    return import_source(engine, make_source(path, fmt, **options))


def import_frame(engine: Engine, df: pl.DataFrame, name: str, fmt: str = "Built-in") -> Dataset:
    table = engine.new_table_name("orig")
    engine.register_arrow(table, df.to_arrow())
    warns = protect_reserved_names(engine, table)
    info = DatasetInfo(source_name=name, format=fmt, storage="DuckDB (temporary local database)", warnings=warns)
    return Dataset(engine, name, info, table)
