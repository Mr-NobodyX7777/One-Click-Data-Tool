"""Type helpers shared by the auditor, cleaner and visualizer.

DuckDB type names are mapped onto a small set of "kinds" so the rest of the
application never needs to care about the exact storage type.
"""
from __future__ import annotations

import re

NUMERIC_PREFIXES = (
    "TINYINT", "SMALLINT", "INTEGER", "BIGINT", "HUGEINT",
    "UTINYINT", "USMALLINT", "UINTEGER", "UBIGINT", "UHUGEINT",
    "FLOAT", "DOUBLE", "DECIMAL", "REAL",
)
INTEGER_TYPES = {
    "TINYINT", "SMALLINT", "INTEGER", "BIGINT", "HUGEINT",
    "UTINYINT", "USMALLINT", "UINTEGER", "UBIGINT", "UHUGEINT",
}
FLOAT_TYPES = {"FLOAT", "DOUBLE", "REAL"}


def quote_ident(name: str) -> str:
    """Quote an SQL identifier (column / table name) safely."""
    return '"' + name.replace('"', '""') + '"'


def type_kind(duck_type: str) -> str:
    """Return one of: numeric, boolean, datetime, time, text, other."""
    t = duck_type.upper()
    if t.startswith(NUMERIC_PREFIXES) and not t.endswith("]"):
        return "numeric"
    if t == "BOOLEAN":
        return "boolean"
    if t == "DATE" or t.startswith("TIMESTAMP"):
        return "datetime"
    if t.startswith("TIME"):
        return "time"
    if t in ("VARCHAR", "TEXT", "STRING") or t.startswith("VARCHAR"):
        return "text"
    return "other"


def is_integer_type(duck_type: str) -> bool:
    return duck_type.upper() in INTEGER_TYPES


def is_float_type(duck_type: str) -> bool:
    return duck_type.upper() in FLOAT_TYPES


def friendly_type(duck_type: str) -> str:
    """Human friendly type label for table headers."""
    t = duck_type.upper()
    if t in INTEGER_TYPES:
        return "Integer"
    if t in FLOAT_TYPES:
        return "Float"
    if t.startswith("DECIMAL"):
        return "Decimal"
    if t == "BOOLEAN":
        return "Boolean"
    if t == "DATE":
        return "Date"
    if t.startswith("TIMESTAMP"):
        return "DateTime"
    if t.startswith("TIME"):
        return "Time"
    if t == "VARCHAR":
        return "String"
    if t == "BLOB":
        return "Binary"
    if re.match(r"^(STRUCT|MAP|UNION)", t) or t.endswith("]"):
        return "Nested"
    return duck_type


def num_expr(col: str) -> str:
    """SQL expression: column as a finite DOUBLE, otherwise NULL (NaN/inf dropped)."""
    c = f"TRY_CAST({quote_ident(col)} AS DOUBLE)"
    return f"CASE WHEN isfinite({c}) THEN {c} END"


def missing_expr(col: str, duck_type: str) -> str:
    """SQL predicate that is TRUE when a cell counts as missing.

    NULL always counts. Text columns also treat empty / whitespace-only strings
    as missing; float columns also treat NaN as missing.
    """
    q = quote_ident(col)
    kind = type_kind(duck_type)
    if kind == "text":
        return f"({q} IS NULL OR trim({q}) = '')"
    if is_float_type(duck_type):
        return f"({q} IS NULL OR isnan({q}))"
    return f"({q} IS NULL)"
