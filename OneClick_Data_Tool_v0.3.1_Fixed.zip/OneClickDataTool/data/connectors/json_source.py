from __future__ import annotations

import mmap
import re

import pyarrow as pa

from data.connectors.base import DataSource
from data.connectors.csv_source import _lit
from data.duckdb_manager import Engine
from data.types import quote_ident


def flatten_exprs(schema: pa.Schema) -> list[str]:
    """SELECT expressions that expand STRUCT columns into dotted leaf columns.

    customer: {name, address: {city}}  ->  customer.name, customer.address.city
    Lists/arrays are *not* destroyed: they stay as list columns.
    """
    out: list[str] = []

    def walk(sql_path: str, label: str, typ: pa.DataType):
        if pa.types.is_struct(typ) and typ.num_fields > 0:
            for i in range(typ.num_fields):
                f = typ.field(i)
                walk(f"{sql_path}.{quote_ident(f.name)}", f"{label}.{f.name}", f.type)
        else:
            out.append(f"{sql_path} AS {quote_ident(label)}")

    for f in schema:
        walk(quote_ident(f.name), f.name, f.type)
    return out


class JSONDataSource(DataSource):
    """JSON array of records, or JSON Lines / NDJSON. Nested objects can be flattened."""

    format_name = "JSON"
    extensions = (".json", ".jsonl", ".ndjson")

    def __init__(self, path, flatten: bool = True, **kw):
        super().__init__(path, flatten=flatten, **kw)
        self._flat_cache: str | None = None

    def _raw(self) -> str:
        return f"SELECT * FROM read_json_auto({_lit(self.path)}, format='auto', sample_size=-1)"

    def scan_sql(self, columns=None) -> str:
        if not self.options["flatten"]:
            cols = "*" if not columns else ", ".join(quote_ident(c) for c in columns)
            return f"SELECT {cols} FROM ({self._raw()})"
        if self._flat_cache is None:
            # need the nested schema once; use a throwaway in-memory connection
            import duckdb
            con = duckdb.connect()
            try:
                from data.duckdb_compat import to_arrow
                schema = to_arrow(con.execute(f"SELECT * FROM ({self._raw()}) LIMIT 0")).schema
            finally:
                con.close()
            self._flat_cache = ", ".join(flatten_exprs(schema))
        inner = f"SELECT {self._flat_cache} FROM ({self._raw()})"
        if columns:
            return f"SELECT {', '.join(quote_ident(c) for c in columns)} FROM ({inner})"
        return inner

    def load_into(self, engine, table):
        super().load_into(engine, table)
        try:
            self._warn_big_ints(engine, table)
        except Exception:  # noqa: BLE001 - diagnostics must never fail an import
            pass

    def _warn_big_ints(self, engine, table) -> None:
        """DuckDB stores JSON integers that do not fit in 64 bits as DOUBLE, which silently rounds them."""
        if (self.file_size or 0) > 300 * 1024 * 1024 or not any(t.upper() == "DOUBLE" for _, t in engine.schema(table)):
            return
        pat = re.compile(rb'(?<![\w."])-?\d{19,}(?![\w."])')
        with open(self.path, "rb") as f, mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            for m in pat.finditer(mm):
                if not -(2**63) <= int(m.group()) <= 2**63 - 1:
                    self.warnings.append(
                        "The file contains integers too large for 64 bits (for example an ID). They were stored "
                        "as approximate decimal numbers and may have lost their last digits. If they are "
                        "identifiers, export them from the source as text (in quotes).")
                    return
