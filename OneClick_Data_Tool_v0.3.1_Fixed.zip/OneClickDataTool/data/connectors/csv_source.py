from __future__ import annotations

import codecs
from pathlib import Path

import duckdb

from data.connectors.base import DataSource, SourceError
from data.duckdb_manager import Engine
from data.types import quote_ident

DEFAULT_MISSING_TOKENS = ["NA", "N/A", "n/a", "NULL", "null", "NaN", "nan", "#N/A"]
ENCODINGS = {"utf-8": "utf-8", "utf-16": "utf-16", "latin-1": "latin-1", "windows-1252": "latin-1"}


def detect_encoding(path: str) -> str:
    """Return a DuckDB-compatible encoding name: utf-8, utf-16 or latin-1."""
    with open(path, "rb") as f:
        head = f.read(256 * 1024)
    if head.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)):
        return "utf-16"
    try:
        codecs.getincrementaldecoder("utf-8")().decode(head, final=False)
        return "utf-8"
    except UnicodeDecodeError:
        return "latin-1"  # also covers Windows-1252 text in practice


class CSVDataSource(DataSource):
    """CSV / TSV / delimited text.

    options: delimiter (None = auto), encoding (None = auto), header (None = auto),
    missing_tokens (list of strings treated as NULL; empty cells are always NULL).
    """

    format_name = "CSV"
    extensions = (".csv", ".tsv", ".txt", ".tab")

    def __init__(self, path, delimiter=None, encoding=None, header=None,
                 missing_tokens=None, **kw):
        super().__init__(path, delimiter=delimiter, encoding=encoding, header=header,
                         missing_tokens=list(DEFAULT_MISSING_TOKENS if missing_tokens is None
                                             else missing_tokens), **kw)
        if self.options["delimiter"] is None and Path(path).suffix.lower() in (".tsv", ".tab"):
            self.options["delimiter"] = "\t"
        if self.options["encoding"] is None:
            self.options["encoding"] = detect_encoding(path)
        if self.options["encoding"] not in ENCODINGS:
            raise SourceError("Unsupported CSV encoding.",
                              f"Encoding: {self.options['encoding']}",
                              "Choose UTF-8, UTF-16, Latin-1, or Windows-1252.")
        self._all_varchar = False
        self._null_padding = False
        self._sniff_rows = -1  # -1 = look at the whole file when detecting types

    def _args(self, raw: bool = False) -> str:
        """read_csv() arguments. raw=True reads every cell as untouched text (used for diagnostics)."""
        o = self.options
        parts = [f"sample_size={self._sniff_rows}", f"encoding={_lit(ENCODINGS.get(o['encoding'], o['encoding']))}"]
        if o["delimiter"]:
            parts.append(f"delim={_lit(o['delimiter'])}")
        if o["header"] is not None:
            parts.append(f"header={'true' if o['header'] else 'false'}")
        if not raw:
            # Empty cells are ALWAYS missing. DuckDB only treats them as NULL when '' is part of the
            # nullstr list; leaving it out made any numeric/date/boolean column that contained a blank
            # cell load as text.
            tokens = [t for t in dict.fromkeys(o["missing_tokens"]) if t != ""] + [""]
            parts.append("nullstr=[" + ", ".join(_lit(t) for t in tokens) + "]")
        if self._all_varchar or raw:
            parts.append("all_varchar=true")
        if self._null_padding:
            parts.append("null_padding=true")
        return ", ".join(parts)

    def scan_sql(self, columns=None) -> str:
        cols = "*" if not columns else ", ".join(quote_ident(c) for c in columns)
        return f"SELECT {cols} FROM read_csv({_lit(self.path)}, {self._args()})"

    def _check(self, engine: Engine) -> None:
        """Validate that DuckDB can parse the file; fall back to text typing if needed."""
        if Path(self.path).stat().st_size == 0:
            raise SourceError("The file is empty.", "It contains no data.",
                              "Choose a file that contains a header row and data.")
        try:
            engine.fetchall(f"SELECT * FROM ({self.scan_sql()}) LIMIT 1")
        except duckdb.Error as e:
            if self._all_varchar:
                raise
            self._all_varchar = True
            try:
                engine.fetchall(f"SELECT * FROM ({self.scan_sql()}) LIMIT 1")
            except duckdb.Error:
                self._all_varchar = False
                raise e
            self.warnings.append("Column types could not be detected reliably; "
                                 "all columns were loaded as text. You can convert them later.")
        self._maybe_enable_padding(engine)

    def _maybe_enable_padding(self, engine: Engine) -> None:
        """Rows with different field counts make DuckDB's auto-detection give up and return ONE column
        containing whole lines ("1,2,3"). Detect that and re-read with padding so columns are kept."""
        if self._null_padding or self.options["delimiter"]:
            return
        cols = [d[0] for d in engine.fetchall(f"DESCRIBE {self.scan_sql()}")]
        if len(cols) == 1 and any(d in cols[0] for d in (",", ";", "\t", "|")):
            self._null_padding = True
            try:
                if len(engine.fetchall(f"DESCRIBE {self.scan_sql()}")) > 1:
                    return
            except duckdb.Error:
                pass
            self._null_padding = False

    def get_schema(self, engine):
        self._check(engine)
        return super().get_schema(engine)

    def preview(self, engine, limit=100):
        # fast preview: sniff types from the first rows only so huge files open instantly
        old = self._sniff_rows
        self._sniff_rows = 20480
        try:
            self._check(engine)
            try:
                return super().preview(engine, limit)
            except duckdb.Error:
                if self._all_varchar:
                    raise
                # A row after LIMIT 1 can expose a mixed-type detection failure.
                self._all_varchar = True
                try:
                    result = super().preview(engine, limit)
                except duckdb.Error:
                    self._all_varchar = False
                    raise
                self.warnings.append('Preview required text-only typing; the import will preserve those types.')
                return result
        finally:
            self._sniff_rows = old
            # Keep the successful all-text fallback for the later import.

    def load_into(self, engine, table):
        self._check(engine)
        super().load_into(engine, table)
        cols = [c for c, _ in engine.schema(table)]
        if len(cols) <= 25:   # (cheap check; a file with nothing but blank lines has a single column)
            anything = " OR ".join(f"{quote_ident(c)} IS NOT NULL" for c in cols)
            if not engine.scalar(f"SELECT count(*) FROM {quote_ident(table)} WHERE {anything}"):
                raise SourceError("The file contains no data values.", "Every cell is empty.",
                                  "Choose a file that contains data, or check the header/delimiter options.")
        # Diagnostics must never make a successful import fail.
        for check in (self._warn_replaced_tokens, self._warn_ragged_rows):
            try:
                check(engine, table)
            except Exception:  # noqa: BLE001
                pass
        if self._null_padding and not any("different number of fields" in w for w in self.warnings):
            self.warnings.append("Rows in this file have different numbers of fields, so short rows were padded "
                                 "with empty values. Check the result before cleaning.")

    # -- import diagnostics ----------------------------------------------------------------------------
    DIAG_MAX_BYTES = 100 * 1024 * 1024   # skip the extra diagnostic scans on very large files

    def _warn_replaced_tokens(self, engine, table) -> None:
        """Tell the user when text such as 'NA' (e.g. the country code for Namibia) became missing."""
        tokens = [t for t in self.options["missing_tokens"] if t != ""]
        text_cols = [c for c, t in engine.schema(table) if t.upper() == "VARCHAR"]
        if not tokens or not text_cols or (self.file_size or 0) > self.DIAG_MAX_BYTES:
            return
        in_list = ", ".join(_lit(t) for t in tokens)
        found: list[tuple[str, int]] = []
        for i in range(0, len(text_cols), 25):
            part = text_cols[i:i + 25]
            exprs = ", ".join(f"count(*) FILTER (WHERE {quote_ident(c)} IN ({in_list}))" for c in part)
            row = engine.fetchone(f"SELECT {exprs} FROM read_csv({_lit(self.path)}, {self._args(raw=True)})")
            found += [(c, int(n)) for c, n in zip(part, row) if n]
        for c, n in found[:5]:
            self.warnings.append(
                f"Column '{c}': {n:,} value(s) such as 'NA' or 'null' were treated as missing. If they are real "
                "values (for example the country code NA), remove them from the missing-value list in the import options.")
        if len(found) > 5:
            self.warnings.append(f"...and {len(found) - 5} more text column(s) had values treated as missing.")

    def _warn_ragged_rows(self, engine, table) -> None:
        """Warn when some rows have more/fewer fields than the table has columns."""
        import csv
        if (self.file_size or 0) > 100 * 1024 * 1024:
            return
        ncols = len(engine.schema(table))
        delim = self.options["delimiter"]
        if not delim:
            pad = ", null_padding=true" if self._null_padding else ""
            delim = engine.scalar(f"SELECT Delimiter FROM sniff_csv({_lit(self.path)}, "
                                  f"encoding={_lit(ENCODINGS.get(self.options['encoding'], self.options['encoding']))}{pad})")
        if not delim or len(delim) != 1:
            return
        csv.field_size_limit(2**31 - 1)
        bad = first = 0
        width = None
        enc = {"utf-16": "utf-16", "latin-1": "latin-1"}.get(ENCODINGS[self.options["encoding"]], "utf-8-sig")
        with open(self.path, newline="", encoding=enc, errors="replace") as f:
            for n, row in enumerate(csv.reader(f, delimiter=delim), start=1):
                if n > 1_000_000:
                    break
                if not (row and any(x.strip() for x in row)):
                    continue
                if width is None:  # the header (or first) row defines the expected width
                    width = len(row) if self.options["header"] is not False else ncols
                    if self.options["header"] is not False:
                        continue
                if len(row) != width:
                    bad += 1
                    first = first or n
        if bad:
            self.warnings.append(
                f"{bad:,} row(s) have a different number of fields than the header (first one: line "
                f"{first}). Short rows were padded with empty values. Check the delimiter and quoting.")


def _lit(s: str) -> str:
    return "'" + str(s).replace("'", "''") + "'"
