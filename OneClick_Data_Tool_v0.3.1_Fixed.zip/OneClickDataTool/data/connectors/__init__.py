"""Connector registry. To add a new source type, subclass DataSource and add it here."""
from __future__ import annotations

from pathlib import Path

from data.connectors.base import DataSource, SourceError
from data.connectors.csv_source import CSVDataSource
from data.connectors.excel_source import ExcelDataSource
from data.connectors.json_source import JSONDataSource
from data.connectors.parquet_source import ParquetDataSource
from data.connectors.sqlite_source import SQLiteDataSource
from data.connectors.xml_source import XMLDataSource
from data.connectors.duckdb_source import DuckDBDataSource

REGISTRY: dict[str, type[DataSource]] = {
    cls.format_name: cls
    for cls in (CSVDataSource, ExcelDataSource, JSONDataSource, ParquetDataSource, SQLiteDataSource, XMLDataSource, DuckDBDataSource)
}


def detect_format(path: str) -> str:
    ext = Path(path).suffix.lower()
    for name, cls in REGISTRY.items():
        if ext in cls.extensions:
            return name
    raise SourceError(
        f"The file type '{ext or 'unknown'}' is not supported.",
        "OneClick Data Tool can read CSV/TSV/TXT, Excel (.xlsx), JSON/JSON Lines, Parquet, SQLite, DuckDB and XML.",
        "Convert the file to one of these formats, or pick the format manually.")


def make_source(path: str, fmt: str | None = None, **options) -> DataSource:
    fmt = fmt or detect_format(path)
    if not Path(path).exists():
        raise SourceError("The file could not be found.", f"{path} does not exist.",
                          "Check that it has not been moved or deleted.")
    return REGISTRY[fmt](path, **options)


def file_filter() -> str:
    exts = " ".join(f"*{e}" for c in REGISTRY.values() for e in c.extensions)
    return f"Data files ({exts});;All files (*)"
