from __future__ import annotations

import sqlite3

import pyarrow as pa

from data.columnar import build_arrow_table, unique_names
from data.connectors.base import DataSource, SourceError


def _connect(path: str) -> sqlite3.Connection:
    """Open a SQLite file strictly read-only: the original is never modified."""
    from pathlib import Path
    uri = Path(path).resolve().as_uri() + "?mode=ro"
    try:
        con = sqlite3.connect(uri, uri=True)
        con.execute("SELECT 1 FROM sqlite_master LIMIT 1")
        return con
    except sqlite3.DatabaseError as e:
        raise SourceError("This SQLite database could not be opened.",
                          "The file may be corrupt, encrypted, or not a SQLite database.",
                          "Check that the file is a valid SQLite database.") from e


def list_tables(path: str) -> list[dict]:
    con = _connect(path)
    try:
        out = []
        for name, kind in con.execute(
                "SELECT name, type FROM sqlite_master WHERE type IN ('table','view') "
                "AND name NOT LIKE 'sqlite_%' ORDER BY type, name"):
            q = '"' + name.replace('"', '""') + '"'
            try:
                n = con.execute(f"SELECT count(*) FROM {q}").fetchone()[0]
            except sqlite3.Error:
                n = None
            out.append({"name": name, "kind": kind, "rows": n})
        return out
    finally:
        con.close()


class SQLiteDataSource(DataSource):
    format_name = "SQLite"
    extensions = (".sqlite", ".sqlite3", ".db", ".db3")

    def __init__(self, path, table: str | None = None, **kw):
        super().__init__(path, table=table, **kw)

    def detail(self) -> str:
        return self.options.get("table") or ""

    def arrow_table(self, limit: int | None = None) -> pa.Table:
        con = _connect(self.path)
        try:
            table = self.options["table"]
            if not table:
                tables = list_tables(self.path)
                if not tables:
                    raise SourceError("The database contains no tables.", "", "")
                table = tables[0]["name"]
            q = '"' + table.replace('"', '""') + '"'
            sql = f"SELECT * FROM {q}" + (f" LIMIT {int(limit)}" if limit is not None else "")
            try:
                cur = con.execute(sql)
            except sqlite3.Error as e:
                raise SourceError(f"Table '{table}' could not be read.", str(e), "") from e
            names = unique_names([d[0] for d in cur.description])
            cols: list[list] = [[] for _ in names]
            while True:
                chunk = cur.fetchmany(50_000)
                if not chunk:
                    break
                for row in chunk:
                    for i, v in enumerate(row):
                        cols[i].append(v)
        finally:
            con.close()
        table_, warns = build_arrow_table(names, cols)
        self.warnings.extend(warns)
        return table_
