"""Common data-source interface.

Every connector (CSV, Excel, JSON, Parquet, SQLite, and future ones such as
PostgreSQL or REST) implements this small interface. The rest of the
application only ever sees the DuckDB table a source is loaded into, so the
Auditor, Cleaner and Visualizer never depend on the original file format.

There are two kinds of source:
* DuckDB-native sources (CSV, JSON, Parquet) describe themselves as an SQL
  relation (`scan_sql`) and DuckDB reads them directly - nothing is staged in
  Python memory.
* Python-read sources (Excel, SQLite) return an Arrow table (`arrow_table`).
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

import polars as pl
import pyarrow as pa

from data.duckdb_manager import Engine
from data.types import quote_ident


class SourceError(Exception):
    """A problem with a data source that we can explain to the user."""

    def __init__(self, what: str, why: str = "", suggestion: str = ""):
        super().__init__(what)
        self.what, self.why, self.suggestion = what, why, suggestion


class DataSource(ABC):
    format_name = "Unknown"
    extensions: tuple[str, ...] = ()
    read_only = True  # sources are never written back to

    def __init__(self, path: str, **options):
        self.path = str(path)
        self.options = options
        self.warnings: list[str] = []

    # -- description ----------------------------------------------------------
    @property
    def name(self) -> str:
        return Path(self.path).name

    @property
    def file_size(self) -> int | None:
        try:
            return Path(self.path).stat().st_size
        except OSError:
            return None

    def detail(self) -> str:
        """Sheet / table name where applicable."""
        return ""

    def config(self) -> dict:
        """JSON-serialisable import configuration (stored with the project later)."""
        return {"format": self.format_name, "path": self.path, **self.options}

    # -- native (SQL) access --------------------------------------------------
    def scan_sql(self, columns: list[str] | None = None) -> str | None:
        """SQL SELECT reading the source, or None for Python-read sources."""
        return None

    # -- Python-read access ------------------------------------------------------
    def arrow_table(self, limit: int | None = None) -> pa.Table:
        raise NotImplementedError

    # -- common interface ----------------------------------------------------------
    def get_schema(self, engine: Engine) -> list[tuple[str, str]]:
        sql = self.scan_sql()
        if sql is not None:
            rows = engine.fetchall(f"DESCRIBE {sql}")
            return [(r[0], r[1]) for r in rows]
        table = self.arrow_table(limit=1)
        return [(f.name, str(f.type)) for f in table.schema]

    def preview(self, engine: Engine, limit: int = 100) -> pl.DataFrame:
        sql = self.scan_sql()
        if sql is not None:
            return engine.polars(f"SELECT * FROM ({sql}) LIMIT {int(limit)}")
        return pl.from_arrow(self.arrow_table(limit=limit))

    def sample(self, engine: Engine, limit: int) -> pl.DataFrame:
        sql = self.scan_sql()
        if sql is not None:
            return engine.polars(f"SELECT * FROM ({sql}) USING SAMPLE {int(limit)} ROWS")
        return self.preview(engine, limit)

    def get_row_count(self, engine: Engine) -> int:
        sql = self.scan_sql()
        if sql is not None:
            return int(engine.scalar(f"SELECT count(*) FROM ({sql})"))
        return self.arrow_table().num_rows

    def load_into(self, engine: Engine, table: str) -> None:
        """Materialise the source into a DuckDB table (the 'original' copy)."""
        sql = self.scan_sql()
        if sql is not None:
            engine.execute(f"CREATE TABLE {quote_ident(table)} AS {sql}")
        else:
            engine.register_arrow(table, self.arrow_table())
