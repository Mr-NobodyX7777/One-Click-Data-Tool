from __future__ import annotations

import zipfile

import pyarrow as pa
from openpyxl import load_workbook
from openpyxl.utils.exceptions import InvalidFileException

from data.columnar import build_arrow_table, unique_names
from data.connectors.base import DataSource, SourceError


def list_sheets(path: str) -> list[dict]:
    """Worksheets with visibility and approximate size (cheap: read-only mode)."""
    wb = _open(path)
    try:
        return [{"name": ws.title, "hidden": ws.sheet_state != "visible",
                 "rows": ws.max_row, "cols": ws.max_column} for ws in wb.worksheets]
    finally:
        wb.close()


def _open(path: str):
    if path.lower().endswith(".xls"):
        raise SourceError("Old .xls workbooks are not supported yet.",
                          "Only the modern .xlsx format can be read.",
                          "Open the file in Excel and save it as .xlsx, then import it again.")
    try:
        return load_workbook(path, read_only=True, data_only=True)
    except (InvalidFileException, zipfile.BadZipFile, KeyError) as e:
        raise SourceError("This Excel file could not be opened.",
                          "The file may be corrupt, password-protected, or not a real .xlsx file.",
                          "Try opening it in Excel and saving a fresh copy.") from e


def _uncached_formulas(path: str, sheet: str, max_rows: int = 5000) -> int:
    """Formula cells (in the first rows) that have no stored result - they would import as empty."""
    wf = load_workbook(path, read_only=True, data_only=False)
    wv = load_workbook(path, read_only=True, data_only=True)
    try:
        n = 0
        for i, (rf, rv) in enumerate(zip(wf[sheet].iter_rows(values_only=True), wv[sheet].iter_rows(values_only=True))):
            if i >= max_rows:
                break
            n += sum(1 for f, v in zip(rf, rv) if isinstance(f, str) and f.startswith("=") and v is None)
        return n
    finally:
        wf.close()
        wv.close()


class ExcelDataSource(DataSource):
    """One worksheet of an .xlsx workbook. Each sheet becomes its own dataset."""

    format_name = "Excel"
    extensions = (".xlsx", ".xlsm", ".xls")

    def __init__(self, path, sheet: str | None = None, header: bool = True, **kw):
        super().__init__(path, sheet=sheet, header=header, **kw)

    def detail(self) -> str:
        return self.options.get("sheet") or ""

    def arrow_table(self, limit: int | None = None) -> pa.Table:
        wb = _open(self.path)
        try:
            sheet = self.options["sheet"] or wb.sheetnames[0]
            if sheet not in wb.sheetnames:
                raise SourceError(f"Worksheet '{sheet}' was not found.", "", "Pick another sheet.")
            ws = wb[sheet]
            rows, dropped_rows = [], 0
            want = None if limit is None else limit + (1 if self.options["header"] else 0)
            for r in ws.iter_rows(values_only=True):
                if all(v is None or (isinstance(v, str) and v.strip() == "") for v in r):
                    dropped_rows += 1
                    continue
                rows.append(list(r))
                if want is not None and len(rows) >= want:
                    break
        finally:
            wb.close()
        if not rows:
            raise SourceError("The worksheet is empty.", "It contains no cells with data.",
                              "Choose a different sheet.")
        width = max(len(r) for r in rows)
        for r in rows:
            r.extend([None] * (width - len(r)))
        header = rows[0] if self.options["header"] else [None] * width
        body = rows[1:] if self.options["header"] else rows
        cols = [[r[i] for r in body] for i in range(width)]
        keep = [i for i in range(width)
                if header[i] not in (None, "") or any(v is not None for v in cols[i])]
        if len(keep) < width:
            self.warnings.append(f"{width - len(keep)} completely empty column(s) were skipped.")
        if dropped_rows and limit is None:
            self.warnings.append(f"{dropped_rows} completely empty row(s) were skipped.")
        if limit is None:
            try:
                missing = _uncached_formulas(self.path, sheet)
            except Exception:  # noqa: BLE001 - diagnostics only
                missing = 0
            if missing:
                self.warnings.append(
                    f"{missing:,} formula cell(s) have no stored result (the workbook was probably not saved by "
                    "Excel), so they were imported as empty. Open it in Excel, save it, and import it again.")
        names = unique_names([header[i] for i in keep])
        table, warns = build_arrow_table(names, [cols[i] for i in keep])
        self.warnings.extend(warns)
        return table
