"""Read existing DuckDB files in read-only mode and select a table/view."""
from __future__ import annotations

from pathlib import Path

import duckdb
import pyarrow as pa

from data.connectors.base import DataSource, SourceError
from data.duckdb_compat import to_arrow


def _connect(path: str):
    try:
        return duckdb.connect(str(Path(path).resolve()), read_only=True)
    except duckdb.Error as e:
        raise SourceError('Could not open DuckDB database in read-only mode.', str(e),
                          'Ensure this is a DuckDB file and it is not exclusively locked.') from e


def list_tables(path: str) -> list[dict]:
    con = _connect(path)
    try:
        rows = con.execute("SELECT table_schema, table_name, table_type FROM information_schema.tables "
                           "WHERE table_schema NOT IN ('information_schema','pg_catalog') "
                           "ORDER BY table_schema, table_name").fetchall()
        return [{'name': f'{schema}.{name}', 'schema': schema, 'table_name': name, 'kind': kind, 'rows': None}
                for schema, name, kind in rows]
    finally:
        con.close()


class DuckDBDataSource(DataSource):
    format_name = 'DuckDB'
    extensions = ('.duckdb', '.ddb', '.duckdb3')

    def __init__(self, path, table=None, **kw):
        super().__init__(path, table=table, **kw)

    def detail(self) -> str:
        return self.options.get('table') or ''

    def arrow_table(self, limit=None) -> pa.Table:
        con = _connect(self.path)
        try:
            allowed = {t['name']: t for t in list_tables(self.path)}
            table = self.options['table'] or next(iter(allowed), None)
            if not table or table not in allowed:
                raise SourceError('The selected DuckDB table or view does not exist.',
                                  f'Selected: {table!r}', 'Choose an available table from the import dialog.')
            target = allowed[table]
            identifiers = '.'.join('"' + part.replace('"', '""') + '"'
                                   for part in (target['schema'], target['table_name']))
            query = f'SELECT * FROM {identifiers}' + (f' LIMIT {int(limit)}' if limit is not None else '')
            return to_arrow(con.execute(query))
        except duckdb.Error as e:
            raise SourceError('Failed to read DuckDB table.', str(e), 'Check the file and table permissions.') from e
        finally:
            con.close()
