"""Read simple tabular XML: a repeated direct child of a document/container.

The parser is deliberately bounded and rejects DTDs/entities so importing an
untrusted file cannot expand entities or exhaust memory unexpectedly.
"""
from __future__ import annotations

from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET

import pyarrow as pa

from data.connectors.base import DataSource, SourceError

MAX_XML_BYTES = 100 * 1024 * 1024  # XML is parsed into memory; avoid accidental huge allocations


def _tag(tag: str) -> str:
    return tag.rsplit('}', 1)[-1]


def _flatten(node: ET.Element, prefix: str, record: dict[str, str | None]) -> None:
    for k, v in node.attrib.items():
        record[f'{prefix}@{_tag(k)}'] = v
    children = list(node)
    if not children:
        val = (node.text or '').strip()
        if prefix:
            record[prefix] = val or None
        return
    seen = set()
    for child in children:
        key = f'{prefix}.{_tag(child.tag)}' if prefix else _tag(child.tag)
        if key in seen:
            raise SourceError('XML contains repeated fields within a record.',
                              f'The field {key} occurs more than once.',
                              'Flatten the nested collection first, or use JSON.')
        seen.add(key)
        _flatten(child, key, record)


def _records(path: str, record_element: str | None) -> list[dict]:
    size = Path(path).stat().st_size
    if size > MAX_XML_BYTES:
        raise SourceError('XML file is too large for the XML importer.',
                          f'The safe limit is {MAX_XML_BYTES // (1024 * 1024)} MB.',
                          'Convert large XML to Parquet or CSV before importing.')
    raw = Path(path).read_bytes()
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise SourceError('XML with DTD or entity declarations is not supported.',
                          'External or expanded entities are unsafe in imported files.',
                          'Export plain XML without a DOCTYPE declaration.')
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as e:
        raise SourceError('The XML file is invalid.', str(e), 'Check the XML syntax.') from e
    if record_element:
        try:
            matched = root.findall(record_element)
        except SyntaxError as e:
            raise SourceError('Invalid XML record selector.', str(e),
                              'Use an ElementTree selector such as .//item.') from e
    else:
        # Prefer a group of repeated sibling tags (root or any nested container).
        matched = []
        for parent in root.iter():
            children = list(parent)
            counts = Counter(c.tag for c in children)
            repeats = [tag for tag, count in counts.items() if count >= 2]
            if repeats:
                candidate = max(repeats, key=lambda tag: counts[tag])
                matched = [c for c in children if c.tag == candidate]
                break
    if not matched and not record_element:
        # A document with a single record: <data><row>...</row></data>, or the root itself being the record.
        top = list(root)
        if len(top) == 1 and len(list(top[0])) > 0:
            matched = [top[0]]
        elif top and all(len(list(c)) == 0 for c in top) and len({c.tag for c in top}) == len(top):
            matched = [root]
    if not matched:
        raise SourceError('No tabular records found in XML.',
                          'The XML should contain repeating record elements.',
                          'For example, use <data><row>...</row><row>...</row></data>.')
    records = []
    for element in matched:
        record: dict[str, str | None] = {}
        for attr, val in element.attrib.items():
            record[f'@{_tag(attr)}'] = val
        seen = set()
        for child in element:
            key = _tag(child.tag)
            if key in seen:
                raise SourceError('Duplicate XML fields.', f'Multiple {key} elements found in one record.',
                                  'Flatten or rename repeated nested fields before import.')
            seen.add(key)
            _flatten(child, key, record)
        if not record:
            record['value'] = (element.text or '').strip() or None
        records.append(record)
    return records


class XMLDataSource(DataSource):
    format_name = 'XML'
    extensions = ('.xml',)

    def __init__(self, path, record_element=None, **kw):
        super().__init__(path, record_element=record_element, **kw)

    def arrow_table(self, limit=None) -> pa.Table:
        rows = _records(self.path, self.options['record_element'])
        # Import as text to avoid irreversible guesses about dates/identifiers.
        names = list(dict.fromkeys(k for row in rows for k in row))
        if not names:
            raise SourceError('XML records contain no columns.')
        rows = rows[:limit] if limit is not None else rows
        return pa.table({name: pa.array([r.get(name) for r in rows], type=pa.string()) for name in names})
