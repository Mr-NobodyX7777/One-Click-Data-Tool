from __future__ import annotations

from data.connectors.base import DataSource
from data.connectors.csv_source import _lit
from data.types import quote_ident


class ParquetDataSource(DataSource):
    format_name = "Parquet"
    extensions = (".parquet", ".pq")

    def scan_sql(self, columns=None) -> str:
        cols = "*" if not columns else ", ".join(quote_ident(c) for c in columns)
        return f"SELECT {cols} FROM read_parquet({_lit(self.path)})"
