"""Version-proof conversion of DuckDB query results.

DuckDB renamed/removed several result methods between releases (``fetch_arrow_table`` ->
``to_arrow_table``; ``.arrow()`` / ``.pl()`` are no longer on connection results in 2.x).
These helpers work on old and new versions so a dependency update never breaks the app.
"""
from __future__ import annotations

import warnings

import polars as pl
import pyarrow as pa

# DuckDB 2.x warns that Arrow output from a cursor makes one extra copy. It is harmless (and the
# only method DuckDB 2.x offers on cursors), so it is filtered instead of shown on every call.
warnings.filterwarnings("ignore", message="Arrow output on a DB-API result")


def to_arrow(result) -> pa.Table:
    for name in ("to_arrow_table", "fetch_arrow_table", "arrow"):
        fn = getattr(result, name, None)
        if fn is not None:
            out = fn()
            if isinstance(out, pa.RecordBatchReader):
                out = out.read_all()
            return out
    raise AttributeError("This DuckDB version offers no Arrow export method.")


def to_polars(result) -> pl.DataFrame:
    out = pl.from_arrow(to_arrow(result))
    return out if isinstance(out, pl.DataFrame) else out.to_frame()
