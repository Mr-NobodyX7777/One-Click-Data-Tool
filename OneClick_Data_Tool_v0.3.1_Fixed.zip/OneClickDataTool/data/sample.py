"""Built-in demo dataset. Generated locally with a fixed seed - no internet needed.

It deliberately contains: missing values, duplicate rows, outliers, numeric /
categorical / date columns, whitespace-only text and invalid values.
"""
from __future__ import annotations

import datetime as dt
import random

import polars as pl


def sample_frame(n: int = 600, seed: int = 7) -> pl.DataFrame:
    rnd = random.Random(seed)
    depts = ["Sales", "Engineering", "Support", "Finance", "HR"]
    countries = ["India", "USA", "Germany", "Brazil", "Japan"]
    rows = []
    for i in range(1, n + 1):
        age = rnd.randint(21, 62)
        salary = round(rnd.lognormvariate(11.0, 0.45), 2)
        rows.append({
            "employee_id": i,
            "name": f"Employee {i:03d}",
            "department": rnd.choice(depts),
            "country": rnd.choice(countries),
            "age": age,
            "salary": salary,
            "score": round(rnd.gauss(70, 10), 1),
            "hire_date": dt.date(2015, 1, 1) + dt.timedelta(days=rnd.randint(0, 3400)),
            "email": f"emp{i}@example.com",
            "region_code": "R1",  # constant column
        })
    # missing values
    for i in rnd.sample(range(n), int(n * 0.08)):
        rows[i]["salary"] = None
    for i in rnd.sample(range(n), int(n * 0.03)):
        rows[i]["age"] = None
    for i in rnd.sample(range(n), int(n * 0.05)):
        rows[i]["country"] = None
    for i in rnd.sample(range(n), int(n * 0.02)):
        rows[i]["department"] = "   "  # whitespace-only text counts as missing
    # outliers
    for i in rnd.sample(range(n), 5):
        rows[i]["salary"] = round(rows[i]["salary"] * 12, 2) if rows[i]["salary"] else 9_999_999.0
    # invalid values
    rows[10]["age"] = -4
    rows[11]["age"] = 250
    rows[12]["email"] = "not-an-email"
    # exact duplicate rows
    for i in rnd.sample(range(n), 12):
        rows.append(dict(rows[i]))
    rnd.shuffle(rows)
    return pl.DataFrame(rows, schema_overrides={"age": pl.Int64, "salary": pl.Float64,
                                                "country": pl.String, "department": pl.String})
