"""Session-level audit log of every change made to a dataset."""
from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime


@dataclass
class HistoryEntry:
    action: str
    column: str | None
    affected: int
    rows_before: int
    rows_after: int
    params: dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))
    status: str = "applied"  # applied | undone | reverted


class HistoryLog:
    def __init__(self):
        self.entries: list[HistoryEntry] = []

    def add(self, entry: HistoryEntry) -> None:
        # entries that were undone can never be redone once a new change is made
        self.entries = [e for e in self.entries if e.status != "undone"]
        self.entries.append(entry)

    def mark_last(self, from_status: str, to_status: str, newest_first: bool = True) -> None:
        seq = reversed(self.entries) if newest_first else iter(self.entries)
        for e in seq:
            if e.status == from_status:
                e.status = to_status
                return

    def revert_all(self) -> None:
        for e in self.entries:
            if e.status == "applied":
                e.status = "reverted"
        self.entries = [e for e in self.entries if e.status != "undone"]

    def applied(self) -> list[HistoryEntry]:
        return [e for e in self.entries if e.status == "applied"]

    def to_dicts(self) -> list[dict]:
        return [asdict(e) for e in self.entries]

    def export_json(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dicts(), f, indent=2, default=str)

    def export_csv(self, path: str) -> None:
        with open(path, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["timestamp", "action", "column", "affected", "rows_before",
                        "rows_after", "status", "parameters"])
            for e in self.entries:
                w.writerow([e.timestamp, e.action, e.column or "", e.affected, e.rows_before,
                            e.rows_after, e.status, json.dumps(e.params, default=str)])
