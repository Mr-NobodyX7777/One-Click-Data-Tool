"""Cleaning operations.

Every operation is *planned* first: `plan_*` returns an OperationPlan that carries
the SQL, the expected impact (rows affected / current / after) and a plain-language
description. Nothing changes until the user confirms and `Dataset.apply(plan)` runs.
The SQL always builds a NEW version - data is never edited in place.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from data.duckdb_manager import Engine
from data.types import (is_float_type, is_integer_type, missing_expr, num_expr,
                        quote_ident, type_kind)


class OperationError(Exception):
    """User-facing validation problem (e.g. a custom value that does not fit the column)."""


@dataclass
class OperationPlan:
    action: str
    description: str
    sql: str
    params: list
    current_rows: int
    rows_after: int
    affected: int
    column: str | None = None
    parameters: dict = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    @property
    def rows_removed(self) -> int:
        return self.current_rows - self.rows_after


def _col_type(engine: Engine, table: str, column: str) -> str:
    for name, t in engine.schema(table):
        if name == column:
            return t
    raise OperationError(f"Column '{column}' does not exist.")


# ---------------------------------------------------------------------------------------------------
def validate_custom_value(engine: Engine, duck_type: str, text: str) -> None:
    """Raise OperationError if `text` cannot be stored in a column of `duck_type`."""
    kind = type_kind(duck_type)
    if kind == "text":
        return
    if text.strip() == "":
        raise OperationError("Enter a value to fill with.")
    if kind == "numeric":
        if is_integer_type(duck_type) and not re.fullmatch(r"[+-]?\d+", text.strip()):
            raise OperationError(f"'{text}' is not a whole number, and this {duck_type} column only holds whole numbers.")
        if engine.scalar(f"SELECT TRY_CAST(? AS {duck_type}) IS NOT NULL", [text.strip()]) is not True:
            raise OperationError(f"'{text}' is not a valid number for this {duck_type} column.")
        return
    if kind == "boolean":
        if text.strip().lower() not in ("true", "false", "yes", "no", "1", "0", "t", "f", "y", "n"):
            raise OperationError(f"'{text}' is not a valid boolean (use true/false).")
        return
    if kind in ("datetime", "time"):
        if engine.scalar(f"SELECT TRY_CAST(? AS {duck_type}) IS NOT NULL", [text.strip()]) is not True:
            raise OperationError(
                f"'{text}' is not a valid {duck_type.lower()} value (example: 2024-01-31).")
        return
    raise OperationError(f"Filling values of type {duck_type} is not supported.")


def _bool_literal(text: str) -> bool:
    return text.strip().lower() in ("true", "yes", "1", "t", "y")


# ---------------------------------------------------------------------------------------------------
def plan_drop_missing(engine: Engine, table: str, columns: list[str] | None) -> OperationPlan:
    """Drop rows that have a missing value in `columns` (None = in any column)."""
    schema = engine.schema(table)
    types = dict(schema)
    cols = columns or [c for c, _ in schema]
    for c in cols:
        if c not in types:
            raise OperationError(f"Column '{c}' does not exist.")
    t = quote_ident(table)
    cond = " OR ".join(missing_expr(c, types[c]) for c in cols)
    cur = engine.row_count(table)
    removed = int(engine.scalar(f"SELECT count(*) FROM {t} WHERE {cond}"))
    scope = f"in '{cols[0]}'" if len(cols) == 1 else "in any column"
    return OperationPlan(
        action="drop_missing_rows",
        description=f"Drop rows with a missing value {scope}",
        sql=f"SELECT * FROM {t} WHERE NOT ({cond}) ORDER BY rowid", params=[],
        current_rows=cur, rows_after=cur - removed, affected=removed,
        column=cols[0] if len(cols) == 1 else None,
        parameters={"columns": cols if columns else "all"})


def plan_fill_missing(engine: Engine, table: str, column: str, method: str,
                      custom_value: str | None = None) -> OperationPlan:
    """Fill missing cells with the column mean, median, or a custom value."""
    types = dict(engine.schema(table))
    if column not in types:
        raise OperationError(f"Column '{column}' does not exist.")
    dtype = types[column]
    kind = type_kind(dtype)
    t, q = quote_ident(table), quote_ident(column)
    miss = missing_expr(column, dtype)
    cur = engine.row_count(table)
    affected = int(engine.scalar(f"SELECT count(*) FROM {t} WHERE {miss}"))
    notes: list[str] = []
    params: list = []

    if method in ("mean", "median"):
        if kind != "numeric":
            raise OperationError(f"{method.title()} can only be used on numeric columns; "
                                 f"'{column}' is {dtype}.")
        fn = "avg" if method == "mean" else "median"
        value = engine.scalar(f"SELECT {fn}({num_expr(column)}) FROM {t}")
        if value is None:
            raise OperationError(f"'{column}' has no valid numbers to compute a {method} from.")
        if is_integer_type(dtype) or dtype.upper().startswith("DECIMAL"):
            notes.append(f"The {method} is {value:,.4f}; column '{column}' will change from {dtype} "
                         "to DOUBLE so the value is not rounded.")
            repl_type = "DOUBLE"
        else:
            repl_type = dtype
        expr = (f"CASE WHEN {miss} THEN CAST(? AS {repl_type}) "
                f"ELSE CAST({q} AS {repl_type}) END")
        params = [float(value)]
        label = f"Fill missing values in '{column}' with the {method} ({value:,.4g})"
        parameters = {"method": method, "value": float(value)}
    elif method == "custom":
        text = custom_value if custom_value is not None else ""
        validate_custom_value(engine, dtype, text)
        if kind == "boolean":
            expr, params = f"CASE WHEN {miss} THEN CAST(? AS BOOLEAN) ELSE {q} END", [_bool_literal(text)]
        elif kind == "text":
            expr, params = f"CASE WHEN {miss} THEN ? ELSE {q} END", [text]
        else:
            expr, params = f"CASE WHEN {miss} THEN CAST(? AS {dtype}) ELSE {q} END", [text.strip()]
        label = f"Fill missing values in '{column}' with '{text}'"
        parameters = {"method": "custom", "value": text}
    else:
        raise OperationError(f"Unknown fill method '{method}'.")

    return OperationPlan(
        action=f"fill_{method}", description=label,
        sql=f"SELECT * REPLACE ({expr} AS {q}) FROM {t} ORDER BY rowid", params=params,
        current_rows=cur, rows_after=cur, affected=affected, column=column,
        parameters=parameters, notes=notes)


def plan_remove_duplicates(engine: Engine, table: str,
                           columns: list[str] | None = None) -> OperationPlan:
    """Keep the first occurrence of each duplicate group (whole-row by default)."""
    t = quote_ident(table)
    all_cols = [c for c, _ in engine.schema(table)]
    part = columns or all_cols
    cur = engine.row_count(table)
    part_sql = ", ".join(quote_ident(c) for c in part)
    distinct = int(engine.scalar(f"SELECT count(*) FROM (SELECT DISTINCT {part_sql} FROM {t})"))
    removed = cur - distinct
    return OperationPlan(
        action="remove_duplicates",
        description="Remove duplicate rows" + (f" (by {', '.join(part)})" if columns else " (entire row)"),
        # Keep the first row of every group. (Not "QUALIFY row_number() OVER (...)": DuckDB 2.0.0 raises an
        # internal error on tables mixing nested/binary/decimal columns, which invalidates the whole database.)
        sql=(f"SELECT * FROM {t} WHERE rowid IN (SELECT min(rowid) FROM {t} GROUP BY {part_sql}) "
             f"ORDER BY rowid"),
        params=[], current_rows=cur, rows_after=cur - removed, affected=removed,
        parameters={"columns": columns or "all", "keep": "first"})
