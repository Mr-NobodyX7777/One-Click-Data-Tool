"""OneClick Data Tool - entry point. Runs fully offline.

A loading screen is shown immediately; the heavy libraries (DuckDB, Polars, Matplotlib, SciPy ...)
are loaded in a background thread while the screen animates, then the main window opens.
"""
import os
import sys
import time

from PySide6.QtCore import QThread, Signal
from PySide6.QtWidgets import QApplication

from app.paths import data_dir, is_first_run, mark_first_run_done
from app.splash import SplashScreen

# (message, modules to import). Importing them ahead of time is what takes long on a first launch.
STEPS = [
    ("Loading the data engine...", ["duckdb", "pyarrow", "polars"]),
    ("Loading charting tools...", ["matplotlib", "matplotlib.font_manager", "matplotlib.figure"]),
    ("Loading statistics tools...", ["numpy", "scipy.stats", "openpyxl"]),
    ("Preparing the interface...", ["PySide6.QtGui", "matplotlib.backends.backend_qtagg"]),
]


class Warmup(QThread):
    status = Signal(str)
    progress = Signal(int, int)

    def run(self):
        import importlib
        n_mods = sum(len(mods) for _, mods in STEPS)
        total = n_mods + 2          # +2: building the main window
        done = 0
        for msg, mods in STEPS:
            for m in mods:
                self.status.emit(f"{msg}  [{m}]")
                self.progress.emit(done, total)
                try:
                    importlib.import_module(m)
                except Exception:  # a missing optional module must not block start-up
                    pass
                done += 1
        self.progress.emit(done, total)


def signal_handoff() -> None:
    """Tell the Windows setup window (if any) that the app's own loading screen is now visible."""
    path = os.environ.get("ONECLICK_HANDOFF")
    if path:
        try:
            open(path, "w").write("ok")
        except OSError:
            pass


def main() -> int:
    first = is_first_run()
    app = QApplication(sys.argv)
    app.setApplicationName("OneClick Data Tool")
    splash = SplashScreen(first_run=first)
    splash.show()
    app.processEvents()
    signal_handoff()
    started = time.time()

    state = {"win": None}
    warm = Warmup()
    warm.status.connect(splash.set_status)
    warm.progress.connect(splash.set_progress)

    def build_window():
        splash.set_status("Opening the main window...")
        splash.set_progress(90, 100)
        from app.errors import setup_logging
        setup_logging()
        from app.main_window import MainWindow
        win = MainWindow()
        state["win"] = win
        win.show()
        splash.set_progress(100, 100)
        mark_first_run_done()
        # keep the screen up for a moment so it never just flashes
        remaining = max(0.0, 0.6 - (time.time() - started))
        from PySide6.QtCore import QTimer
        QTimer.singleShot(int(remaining * 1000), splash.close)
        if len(sys.argv) > 1:
            win.import_path(sys.argv[1])

    warm.finished.connect(build_window)
    warm.start()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
