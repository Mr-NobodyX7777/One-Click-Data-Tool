"""Statistically-backed suggestions for missing values.

These are *guidance*, never automatic decisions: every recommendation carries a
quick, a detailed and a methodology explanation, and the user can always pick a
different action.
"""
from __future__ import annotations

from dataclasses import dataclass

from auditor.statistics import ColumnProfile

DROP_MAX_PCT = 2.0         # drop rows if at most this % of rows have the value missing
KEEP_MIN_PCT = 40.0        # beyond this, filling would mostly invent data
SKEW_STRONG = 1.0          # |skew| >= 1  -> strongly skewed
SKEW_SYMMETRIC = 0.5       # |skew| <  0.5 -> approximately symmetric
OUTLIER_MEANINGFUL_PCT = 5.0

ACTIONS = {
    "drop": "Drop rows containing missing values",
    "mean": "Fill with Mean",
    "median": "Fill with Median",
    "custom": "Fill with Custom Value",
    "keep": "Leave as is",
}


@dataclass
class Recommendation:
    action: str            # drop | mean | median | custom | keep
    quick: str
    detailed: str
    methodology: str
    suggested_value: str | None = None

    @property
    def label(self) -> str:
        return ACTIONS[self.action]


METHODOLOGY = (
    "Rules (applied in this order):\n"
    f"1. Missing <= {DROP_MAX_PCT:g}% of rows: dropping rows loses little data -> Drop rows.\n"
    f"2. Missing >= {KEEP_MIN_PCT:g}%: filling would mostly invent data -> Leave as is "
    "(consider excluding the column).\n"
    f"3. Numeric: Median if |skewness| >= {SKEW_STRONG:g} or IQR outliers >= {OUTLIER_MEANINGFUL_PCT:g}% "
    f"or the distribution is only moderately skewed ({SKEW_SYMMETRIC:g} <= |skew| < {SKEW_STRONG:g}); "
    f"Mean only if |skewness| < {SKEW_SYMMETRIC:g} and outliers are limited.\n"
    "4. Text/categorical: fill with a placeholder such as 'Unknown' so the gap stays visible.\n"
    "5. Date/boolean: values cannot be sensibly invented -> Drop rows (or leave as is when many are missing).\n"
    "Skewness is the adjusted Fisher-Pearson coefficient; outliers use Tukey's 1.5 x IQR fences. "
    "These are heuristics, not guaranteed truth."
)


def recommend_missing(p: ColumnProfile) -> Recommendation | None:
    if p.missing == 0:
        return None
    pct = p.missing_pct

    if pct >= KEEP_MIN_PCT:
        return Recommendation(
            "keep", "Too many values are missing to fill reliably.",
            f"{pct:.1f}% of values are missing; imputing them would mostly invent data.",
            METHODOLOGY)
    if pct <= DROP_MAX_PCT:
        return Recommendation(
            "drop", f"Only {pct:.1f}% of rows are affected, so dropping them loses little.",
            f"{p.missing:,} of {p.rows:,} rows have a missing value in '{p.name}'.", METHODOLOGY)

    if p.is_numeric and p.skew is not None and p.median is not None and p.mean is not None:
        strong = abs(p.skew) >= SKEW_STRONG
        meaningful_outliers = p.outlier_pct >= OUTLIER_MEANINGFUL_PCT
        symmetric = abs(p.skew) < SKEW_SYMMETRIC and not meaningful_outliers
        detail = (f"Mean = {p.mean:,.2f}, median = {p.median:,.2f}, skewness = {p.skew:.2f}, "
                  f"IQR = {p.iqr:,.2f}, outliers = {p.outliers:,} ({p.outlier_pct:.1f}%).")
        if symmetric:
            return Recommendation(
                "mean", "Mean was recommended because the distribution is roughly symmetric "
                        "with few outliers.", detail, METHODOLOGY)
        why = ("strongly skewed" if strong else
               "has meaningful outliers" if meaningful_outliers else "moderately skewed")
        return Recommendation(
            "median", f"Median was recommended because the distribution {why if not strong else 'is strongly skewed'}.",
            detail, METHODOLOGY)

    if p.kind == "text":
        return Recommendation(
            "custom", "Fill with a visible placeholder such as 'Unknown' so the gap is not hidden.",
            f"'{p.name}' is {p.category.lower()}; a mean/median does not apply.",
            METHODOLOGY, suggested_value="Unknown")
    if p.kind in ("datetime", "time", "boolean"):
        return Recommendation(
            "drop", "Dates and booleans cannot be sensibly invented.",
            f"{p.missing:,} rows have no value in '{p.name}'.", METHODOLOGY)
    return Recommendation("keep", "No automatic recommendation for this column type.", "", METHODOLOGY)
