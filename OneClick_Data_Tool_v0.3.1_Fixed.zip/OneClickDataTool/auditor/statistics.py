"""Full-data column profiling, computed in DuckDB (no data is pulled into Python).

Definitions (documented in the UI/report):
* missing   : NULL, or - for text - empty/whitespace-only strings, or - for floats - NaN
* non-null  : rows - missing (cells that hold a real value)
* outliers  : numeric values outside [Q1 - 1.5*IQR, Q3 + 1.5*IQR]  (Tukey's fences)
* skewness  : adjusted Fisher-Pearson sample skewness (DuckDB `skewness`)
"""
from __future__ import annotations

from dataclasses import dataclass, field

from data.duckdb_manager import Engine
from data.types import missing_expr, num_expr, quote_ident, type_kind

CATEGORICAL_MAX_UNIQUE = 50
CATEGORICAL_MAX_RATIO = 0.05
IQR_MULTIPLIER = 1.5
PROFILE_BATCH = 25      # columns profiled per query (keeps the SQL planner fast on wide tables)


@dataclass
class ColumnProfile:
    name: str
    duck_type: str
    kind: str
    category: str = "Unknown"
    rows: int = 0
    non_null: int = 0
    missing: int = 0
    missing_pct: float = 0.0
    unique: int = 0
    cardinality: float = 0.0  # unique / non_null
    min: object = None
    max: object = None
    mean: float | None = None
    median: float | None = None
    std: float | None = None
    variance: float | None = None
    skew: float | None = None
    q1: float | None = None
    q3: float | None = None
    iqr: float | None = None
    lower_fence: float | None = None
    upper_fence: float | None = None
    outliers: int = 0
    outlier_pct: float = 0.0
    zeros: int = 0
    negatives: int = 0
    constant: bool = False
    # text profiling
    min_len: int | None = None
    max_len: int | None = None
    avg_len: float | None = None
    empty_strings: int = 0
    whitespace_only: int = 0
    token_missing: int = 0  # values like "NA"/"N/A" still present as text
    top_values: list = field(default_factory=list)
    # verdict
    issues: list[str] = field(default_factory=list)

    @property
    def is_numeric(self) -> bool:
        return self.kind == "numeric"

    @property
    def invalid(self) -> int:
        """Placeholder text such as 'NA' that is still stored as a real value.
        (Blank / whitespace-only strings are already counted as missing.)"""
        return self.token_missing

    @property
    def healthy(self) -> bool:
        return not self.issues


def _lit(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def profile_columns(engine: Engine, table: str, missing_tokens: list[str]) -> list[ColumnProfile]:
    t = quote_ident(table)
    schema = engine.schema(table)
    tokens = [x.strip().upper() for x in missing_tokens if x.strip()]
    token_list = ", ".join(_lit(x) for x in tokens) or "''"

    # One query per small batch of columns. A single query over hundreds of columns makes DuckDB's
    # planner very slow (and eventually run out of memory), so wide tables are profiled in chunks.
    chunks: list[tuple[list[tuple[str, str]], list[dict[str, int]], tuple]] = []
    for start in range(0, max(len(schema), 1), PROFILE_BATCH):
        part = schema[start:start + PROFILE_BATCH]
        exprs = ["count(*)"]
        slots: list[dict[str, int]] = []
        for name, dtype in part:
            kind = type_kind(dtype)
            q = quote_ident(name)
            miss = missing_expr(name, dtype)
            s: dict[str, int] = {}

            def add(key: str, expr: str) -> None:
                s[key] = len(exprs)
                exprs.append(expr)

            add("missing", f"count(*) FILTER (WHERE {miss})")
            if kind != "other":
                add("unique", f"count(DISTINCT {q}) FILTER (WHERE NOT {miss})")
            else:
                add("unique", f"count(DISTINCT CAST({q} AS VARCHAR)) FILTER (WHERE {q} IS NOT NULL)")
            if kind in ("text", "boolean", "datetime", "time"):
                add("min", f"min({q}) FILTER (WHERE NOT {miss})")
                add("max", f"max({q}) FILTER (WHERE NOT {miss})")
            if kind == "numeric":
                n = num_expr(name)
                add("min", f"min({n})")
                add("max", f"max({n})")
                add("mean", f"avg({n})")
                add("median", f"median({n})")
                add("std", f"stddev_samp({n})")
                add("var", f"var_samp({n})")
                add("skew", f"skewness({n})")
                add("q1", f"quantile_cont({n}, 0.25)")
                add("q3", f"quantile_cont({n}, 0.75)")
                add("zeros", f"count(*) FILTER (WHERE {n} = 0)")
                add("neg", f"count(*) FILTER (WHERE {n} < 0)")
            if kind == "text":
                add("minlen", f"min(length({q}))")
                add("maxlen", f"max(length({q}))")
                add("avglen", f"avg(length({q}))")
                add("empty", f"count(*) FILTER (WHERE {q} = '')")
                add("ws", f"count(*) FILTER (WHERE {q} <> '' AND trim({q}) = '')")
                add("tok", f"count(*) FILTER (WHERE upper(trim({q})) IN ({token_list}))")
            slots.append(s)
        chunks.append((part, slots, engine.fetchone(f"SELECT {', '.join(exprs)} FROM {t}")))
    total = int(chunks[0][2][0])
    profiles: list[ColumnProfile] = []
    flat = [(name, dtype, s, row) for part, slots, row in chunks
            for (name, dtype), s in zip(part, slots)]
    for name, dtype, s, row in flat:
        kind = type_kind(dtype)
        g = lambda k, d=None, s=s, row=row: row[s[k]] if k in s else d  # noqa: E731
        p = ColumnProfile(name=name, duck_type=dtype, kind=kind, rows=total)
        p.missing = int(g("missing", 0))
        p.non_null = total - p.missing
        p.missing_pct = (p.missing / total * 100) if total else 0.0
        p.unique = int(g("unique", 0))
        p.cardinality = (p.unique / p.non_null) if p.non_null else 0.0
        p.min, p.max = g("min"), g("max")
        if kind == "numeric":
            p.mean, p.median, p.std = g("mean"), g("median"), g("std")
            p.variance, p.skew = g("var"), g("skew")
            p.q1, p.q3 = g("q1"), g("q3")
            p.zeros, p.negatives = int(g("zeros", 0)), int(g("neg", 0))
            if p.q1 is not None and p.q3 is not None:
                p.iqr = p.q3 - p.q1
                p.lower_fence = p.q1 - IQR_MULTIPLIER * p.iqr
                p.upper_fence = p.q3 + IQR_MULTIPLIER * p.iqr
        if kind == "text":
            p.min_len, p.max_len, p.avg_len = g("minlen"), g("maxlen"), g("avglen")
            p.empty_strings, p.whitespace_only = int(g("empty", 0)), int(g("ws", 0))
            p.token_missing = int(g("tok", 0))
        p.constant = total > 1 and p.non_null > 0 and p.unique <= 1
        p.category = _category(p)
        profiles.append(p)

    _fill_outliers(engine, t, profiles)
    _fill_top_values(engine, t, profiles)
    for p in profiles:
        p.issues = _issues(p)
    return profiles


def _category(p: ColumnProfile) -> str:
    if p.kind == "numeric":
        return "Numeric"
    if p.kind == "boolean":
        return "Boolean"
    if p.kind in ("datetime", "time"):
        return "Date/time"
    if p.kind == "text":
        if p.unique <= CATEGORICAL_MAX_UNIQUE or p.cardinality <= CATEGORICAL_MAX_RATIO:
            return "Categorical"
        return "Text"
    return "Unknown"


def _fill_outliers(engine: Engine, t: str, profiles: list[ColumnProfile]) -> None:
    targets = [p for p in profiles if p.is_numeric and p.lower_fence is not None and p.iqr]
    if not targets:
        return
    for start in range(0, len(targets), PROFILE_BATCH * 2):
        part = targets[start:start + PROFILE_BATCH * 2]
        exprs = []
        for p in part:
            n = num_expr(p.name)
            exprs.append(f"count(*) FILTER (WHERE {n} < {p.lower_fence!r} OR {n} > {p.upper_fence!r})")
        row = engine.fetchone(f"SELECT {', '.join(exprs)} FROM {t}")
        for p, c in zip(part, row):
            p.outliers = int(c)
            p.outlier_pct = (p.outliers / p.non_null * 100) if p.non_null else 0.0


def _fill_top_values(engine: Engine, t: str, profiles: list[ColumnProfile], n: int = 5) -> None:
    for p in profiles:
        if p.category not in ("Categorical", "Text", "Boolean") or p.non_null == 0:
            continue
        q = quote_ident(p.name)
        rows = engine.fetchall(
            f"SELECT {q}, count(*) c FROM {t} WHERE NOT {missing_expr(p.name, p.duck_type)} "
            f"GROUP BY {q} ORDER BY c DESC, {q} LIMIT {n}")
        p.top_values = [(v, int(c)) for v, c in rows]


# thresholds that decide whether a column is flagged as a "problem column"
MISSING_FLAG_PCT = 1.0
OUTLIER_FLAG_PCT = 1.0


def _issues(p: ColumnProfile) -> list[str]:
    out = []
    if p.rows and p.missing == p.rows:
        out.append("All values are missing")
        return out
    if p.missing_pct >= MISSING_FLAG_PCT:
        out.append(f"{p.missing_pct:.1f}% missing")
    if p.invalid:
        out.append(f"{p.invalid:,} placeholder value(s) such as NA/NULL stored as text")
    if p.is_numeric and p.outlier_pct >= OUTLIER_FLAG_PCT:
        out.append(f"{p.outliers:,} IQR outlier(s) ({p.outlier_pct:.1f}%)")
    if p.constant:
        out.append("Constant column (single value)")
    return out
