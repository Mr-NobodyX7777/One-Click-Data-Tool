from __future__ import annotations

from data.duckdb_manager import Engine
from data.types import quote_ident


def count_duplicates(engine: Engine, table: str, columns: list[str] | None = None) -> int:
    """Number of *extra* rows: total rows minus distinct rows.

    By default the complete row is compared (NULLs compare equal). Pass `columns`
    to compare only a subset.
    """
    t = quote_ident(table)
    cols = "*" if not columns else ", ".join(quote_ident(c) for c in columns)
    total = engine.scalar(f"SELECT count(*) FROM {t}")
    distinct = engine.scalar(f"SELECT count(*) FROM (SELECT DISTINCT {cols} FROM {t})")
    return int(total - distinct)
