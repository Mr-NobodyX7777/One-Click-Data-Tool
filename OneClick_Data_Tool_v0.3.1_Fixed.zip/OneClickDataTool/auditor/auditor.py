"""Phase 1: audit a dataset version (everything is computed on the full data)."""
from __future__ import annotations

from dataclasses import dataclass, field

from auditor.duplicates import count_duplicates
from auditor.recommendations import Recommendation, recommend_missing
from auditor.statistics import ColumnProfile, profile_columns
from data.duckdb_manager import Engine

DEFAULT_MISSING_TOKENS = ["NA", "N/A", "NULL", "NaN", "#N/A"]

# --- Data Health Score: every weight and cap is documented here -----------------------------------
# score = 100 - sum(penalties), clamped to [0, 100].  penalty = min(cap, weight * fraction)
HEALTH_RULES = {
    "Missing values":   dict(weight=150.0, cap=30.0, basis="share of all cells that are missing"),
    "Duplicates":       dict(weight=100.0, cap=20.0, basis="share of rows that are exact duplicates"),
    "Invalid values":   dict(weight=100.0, cap=15.0, basis="share of text cells holding placeholders (NA, NULL...) as text"),
    "Outliers":         dict(weight=100.0, cap=15.0, basis="share of numeric cells outside the 1.5 x IQR fences"),
    "Constant columns": dict(weight=30.0, cap=10.0, basis="share of columns holding a single value"),
}


def health_methodology() -> str:
    lines = ["Data Health Score = 100 - sum of penalties (never below 0).",
             "Each penalty = min(cap, weight x fraction), where the fraction is a share between 0 and 1.", ""]
    for name, r in HEALTH_RULES.items():
        lines.append(f"- {name}: weight {r['weight']:g}, max penalty {r['cap']:g} - {r['basis']}.")
    lines += ["", "Example: 10% of cells missing -> 150 x 0.10 = 15 points off (capped at 30).",
              "Outliers are *flagged*, not assumed wrong: a real extreme value still costs a small amount "
              "so you can review it."]
    return "\n".join(lines)


@dataclass
class HealthScore:
    score: int
    components: list[tuple[str, float, str]]  # (name, penalty, detail)


@dataclass
class AuditResult:
    dataset_name: str
    rows: int
    columns: list[ColumnProfile]
    duplicates: int
    missing_cells: int
    total_cells: int
    health: HealthScore
    recommendations: dict[str, Recommendation] = field(default_factory=dict)
    missing_tokens: list[str] = field(default_factory=list)

    @property
    def missing_pct(self) -> float:
        return self.missing_cells / self.total_cells * 100 if self.total_cells else 0.0

    @property
    def problem_columns(self) -> list[ColumnProfile]:
        return [c for c in self.columns if not c.healthy]

    @property
    def healthy_columns(self) -> list[ColumnProfile]:
        return [c for c in self.columns if c.healthy]

    def profile(self, name: str) -> ColumnProfile | None:
        return next((c for c in self.columns if c.name == name), None)


def compute_health(rows: int, columns: list[ColumnProfile], duplicates: int) -> HealthScore:
    ncols = len(columns)
    cells = rows * ncols
    missing = sum(c.missing for c in columns)
    text_cells = sum(c.non_null for c in columns if c.kind == "text")
    invalid = sum(c.invalid for c in columns)
    numeric_cells = sum(c.non_null for c in columns if c.is_numeric)
    outliers = sum(c.outliers for c in columns if c.is_numeric)
    constants = sum(1 for c in columns if c.constant)

    fractions = {
        "Missing values": (missing / cells if cells else 0, f"{missing:,} of {cells:,} cells"),
        "Duplicates": (duplicates / rows if rows else 0, f"{duplicates:,} of {rows:,} rows"),
        "Invalid values": (invalid / text_cells if text_cells else 0, f"{invalid:,} of {text_cells:,} text cells"),
        "Outliers": (outliers / numeric_cells if numeric_cells else 0, f"{outliers:,} of {numeric_cells:,} numeric cells"),
        "Constant columns": (constants / ncols if ncols else 0, f"{constants} of {ncols} columns"),
    }
    comps, total = [], 0.0
    for name, (frac, detail) in fractions.items():
        r = HEALTH_RULES[name]
        penalty = min(r["cap"], r["weight"] * frac)
        total += penalty
        comps.append((name, round(penalty, 1), detail))
    return HealthScore(score=max(0, min(100, round(100 - total))), components=comps)


def audit_table(engine: Engine, table: str, name: str = "",
                missing_tokens: list[str] | None = None) -> AuditResult:
    tokens = DEFAULT_MISSING_TOKENS if missing_tokens is None else missing_tokens
    columns = profile_columns(engine, table, tokens)
    rows = columns[0].rows if columns else 0
    dups = count_duplicates(engine, table) if rows else 0
    missing = sum(c.missing for c in columns)
    recs = {}
    for c in columns:
        r = recommend_missing(c)
        if r:
            recs[c.name] = r
    return AuditResult(
        dataset_name=name, rows=rows, columns=columns, duplicates=dups,
        missing_cells=missing, total_cells=rows * len(columns),
        health=compute_health(rows, columns, dups), recommendations=recs,
        missing_tokens=list(tokens))
