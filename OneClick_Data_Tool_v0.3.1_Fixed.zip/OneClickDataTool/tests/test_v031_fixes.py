"""Regression tests for the v0.3.1 bug-fix round (each test failed on v0.3)."""
import datetime as dt
import json
import re
import time
import zipfile

import polars as pl
import pyarrow as pa
import pyarrow.parquet as pq
import pytest

from auditor.auditor import audit_table
from cleaner import operations as ops
from data.importer import import_frame, import_path
from export import FORMATS, export_dataset


# 1 ---------------------------------------------------------------------------------------------
def test_blank_cells_do_not_turn_columns_into_text(engine, tmp_path):
    p = tmp_path / "blank.csv"
    p.write_text("n,d,f,s\n1,2020-01-01,true,a\n,,,\n3,2020-01-03,false,c\n")
    ds = import_path(engine, str(p))
    types = dict(ds.columns())
    assert types["n"] == "BIGINT" and types["d"] == "DATE" and types["f"] == "BOOLEAN"
    assert engine.fetchall(f'SELECT count(*) FROM "{ds.current}" WHERE n IS NULL')[0][0] == 1
    # and the numeric cleaning actions are therefore available
    plan = ops.plan_fill_missing(engine, ds.current, "n", "mean")
    assert plan.affected == 1


def test_blank_cells_with_empty_token_list(engine, tmp_path):
    p = tmp_path / "b.csv"
    p.write_text("a,b\n1,\n2,3\n")
    ds = import_path(engine, str(p), missing_tokens=[])
    assert dict(ds.columns())["b"] == "BIGINT"


# 2 ---------------------------------------------------------------------------------------------
@pytest.mark.parametrize("ncols", [400])
def test_wide_table_audit_is_fast_and_correct(engine, ncols):
    df = pl.DataFrame({f"c{i}": [float(i), float(i + 1), None, 3.0] for i in range(ncols)})
    ds = import_frame(engine, df, "wide")
    t = time.time()
    a = audit_table(engine, ds.current, "wide")
    assert time.time() - t < 20
    assert len(a.columns) == ncols
    assert [c.name for c in a.columns] == list(df.columns)       # order preserved across batches
    assert a.columns[7].mean == pytest.approx((7 + 8 + 3) / 3)    # values land on the right column
    assert all(c.missing == 1 for c in a.columns)


# 3 ---------------------------------------------------------------------------------------------
def test_excel_export_survives_control_chars_and_never_writes_formulas(engine, tmp_path):
    from openpyxl import load_workbook
    ds = import_frame(engine, pl.DataFrame({"=h": ["ok", "bad\x01char", "=1+1", "x" * 40000]}), "x")
    dest = str(tmp_path / "o.xlsx")
    export_dataset(engine, ds.current, dest, "Excel (.xlsx)", None)
    ws = load_workbook(dest).active
    cells = [ws.cell(row=r, column=1) for r in range(1, 6)]
    assert [c.data_type for c in cells] == ["s"] * 5            # header and every value are plain text
    assert cells[2].value == "badchar" and cells[3].value == "=1+1"
    assert len(cells[4].value) == 32767


def test_csv_export_neutralises_formulas_but_keeps_normal_text(engine, tmp_path):
    vals = ["=cmd|' /C calc'!A0", "@SUM(1)", "-2+3", "+44 20 7946 0000", "-5", "plain", "-abc", "a=b"]
    ds = import_frame(engine, pl.DataFrame({"s": vals, "n": list(range(len(vals)))}), "x")
    dest = str(tmp_path / "o.csv")
    export_dataset(engine, ds.current, dest, "CSV (.csv)", None)
    back = pl.read_csv(dest, infer_schema_length=0)["s"].to_list()
    assert back[0].startswith("'=") and back[1].startswith("'@") and back[6].startswith("'-")
    assert back[2:6] == ["-2+3", "+44 20 7946 0000", "-5", "plain"] and back[7] == "a=b"


# 4 ---------------------------------------------------------------------------------------------
def test_column_named_rowid_keeps_row_order(engine, tmp_path):
    p = tmp_path / "r.csv"
    p.write_text("rowid,a\n3,x\n1,y\n2,z\n3,x\n")
    ds = import_path(engine, str(p))
    assert "rowid_1" in ds.column_names() and any("rowid" in w for w in ds.info.warnings)
    ds.apply(ops.plan_remove_duplicates(engine, ds.current, None))
    assert [r[0] for r in engine.fetchall(f'SELECT rowid_1 FROM "{ds.current}"')] == [3, 1, 2]
    dest = str(tmp_path / "o.csv")
    export_dataset(engine, ds.current, dest, "CSV (.csv)", None)
    assert pl.read_csv(dest)["rowid_1"].to_list() == [3, 1, 2]


def test_rowid_in_any_case_and_frames(engine):
    ds = import_frame(engine, pl.DataFrame({"RowID": [2, 1], "rowid_1": [0, 0]}), "f")
    assert ds.column_names() == ["RowID_2", "rowid_1"]   # skips the name that is already taken
    assert not any(n.casefold() == "rowid" for n in ds.column_names())


# 5 ---------------------------------------------------------------------------------------------
def test_timezone_aware_timestamps_audit(engine, tmp_path):
    t = pa.table({"ts": pa.array([dt.datetime(2020, 1, 1, tzinfo=dt.timezone.utc), None,
                                  dt.datetime(2021, 1, 1, tzinfo=dt.timezone.utc)])})
    p = str(tmp_path / "tz.parquet")
    pq.write_table(t, p)
    ds = import_path(engine, p)
    a = audit_table(engine, ds.current, "tz")
    assert a.columns[0].missing == 1


def test_pytz_is_a_declared_requirement():
    from pathlib import Path
    req = (Path(__file__).resolve().parent.parent / "requirements.txt").read_text().lower()
    assert "pytz" in req


# 6 ---------------------------------------------------------------------------------------------
def test_na_tokens_in_text_columns_are_reported(engine, tmp_path):
    p = tmp_path / "c.csv"
    p.write_text("country,n\nNA,1\nUS,2\nDE,3\nNA,4\n")
    ds = import_path(engine, str(p))
    assert any("country" in w and "2" in w for w in ds.info.warnings)


# 7 ---------------------------------------------------------------------------------------------
def test_json_export_is_valid_strict_json(engine, tmp_path):
    ds = import_frame(engine, pl.DataFrame({"f": [1.5, float("nan"), float("inf"), float("-inf")]}), "x")
    for lab in ("JSON (.json)", "JSON Lines (.jsonl)"):
        dest = str(tmp_path / ("o" + FORMATS[lab][0]))
        export_dataset(engine, ds.current, dest, lab, None)
        txt = open(dest).read()
        assert not re.search(r"NaN|Infinity", txt)
        json.loads(txt, parse_constant=lambda c: (_ for _ in ()).throw(ValueError(c))) \
            if lab == "JSON (.json)" else [json.loads(l) for l in txt.splitlines() if l]


# 8 ---------------------------------------------------------------------------------------------
@pytest.mark.parametrize("bad", ["3.7", "1e3", "abc"])
def test_integer_column_rejects_non_whole_custom_fill(engine, bad):
    ds = import_frame(engine, pl.DataFrame({"i": [1, None, 3]}), "x")
    with pytest.raises(ops.OperationError):
        ops.plan_fill_missing(engine, ds.current, "i", "custom", bad)
    ops.plan_fill_missing(engine, ds.current, "i", "custom", " 7 ")  # whole numbers are still fine


# 9 ---------------------------------------------------------------------------------------------
def test_json_huge_integers_warn(engine, tmp_path):
    p = tmp_path / "big.json"
    p.write_text(json.dumps([{"id": 2 ** 70, "v": 1}, {"id": 5, "v": 2}]))
    assert any("64 bits" in w for w in import_path(engine, str(p)).info.warnings)
    p2 = tmp_path / "ok.json"
    p2.write_text(json.dumps([{"id": 5, "s": "12345678901234567890123"}]))
    assert not import_path(engine, str(p2)).info.warnings


def test_excel_uncached_formulas_warn(engine, tmp_path):
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.append(["a", "b"])
    ws.append([1, "=A2*2"])
    ws.append([2, "=A3*2"])
    p = str(tmp_path / "f.xlsx")
    wb.save(p)
    assert any("formula" in w for w in import_path(engine, p).info.warnings)


def test_xml_single_record(engine, tmp_path):
    p = tmp_path / "one.xml"
    p.write_text("<data><row><a>1</a><b>x</b></row></data>")
    ds = import_path(engine, str(p))
    assert ds.row_count() == 1 and ds.column_names() == ["a", "b"]


def test_ragged_csv_rows_warn(engine, tmp_path):
    p = tmp_path / "rag.csv"
    p.write_text("a,b,c\n1,2,3\n4,5\n6,7,8,9\n10,11,12\n")
    assert any("different number of fields" in w and "2 row" in w for w in import_path(engine, str(p)).info.warnings)
    q = tmp_path / "fine.csv"
    q.write_text('a,b\n1,"x\ny"\n2,z\n')
    assert not import_path(engine, str(q)).info.warnings


# 10 --------------------------------------------------------------------------------------------
def test_closing_datasets_does_not_raise_in_gui(tmp_path):
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from app.main_window import MainWindow
    w = MainWindow()

    def idle():  # the real window refuses to close a dataset while a job runs, so wait like a user would
        end = time.time() + 30
        while time.time() < end and w.runner.busy:
            app.processEvents()
            time.sleep(0.02)
        assert not w.runner.busy

    a = import_frame(w.state.engine, pl.DataFrame({"x": [1, 2]}), "a")
    b = import_frame(w.state.engine, pl.DataFrame({"x": [3, 4]}), "b")
    w.state.add_dataset(a)
    idle()
    w.state.add_dataset(b)
    idle()
    w.state.close_dataset(b)                  # used to raise ValueError inside a Qt slot
    idle()
    assert w.combo.count() == 1 and w.state.current is a
    assert not w.combo.signalsBlocked()
    w.state.close_dataset(a)
    idle()
    assert w.combo.count() == 0 and not w.combo.signalsBlocked()
    w.close()


# 11 --------------------------------------------------------------------------------------------
def test_project_roundtrip_with_rowid_rename(engine, tmp_path):
    from app.project import load_project, save_project
    from data.duckdb_manager import Engine
    ds = import_frame(engine, pl.DataFrame({"rowid": [2, 1], "v": [1, 2]}), "p")

    class St:  # minimal stand-in for AppState
        datasets = [ds]
        current = ds
        missing_tokens = ["NA"]
    St.engine = engine
    path = str(tmp_path / "x.ocdt")
    save_project(St, path)
    e2 = Engine()
    try:
        loaded, _, _ = load_project(e2, path)
        assert "rowid" not in [c.casefold() for c in loaded[0].column_names()]
    finally:
        e2.close()


# 12 --------------------------------------------------------------------------------------------
def test_files_without_any_data_are_rejected_but_blank_cells_are_kept(engine, tmp_path):
    from data.connectors.base import SourceError
    for name, text in (("a.csv", "\n\n\n"), ("b.csv", "a,b\n"), ("c.csv", "a\n\n\n")):
        (tmp_path / name).write_text(text)
        with pytest.raises(SourceError):
            import_path(engine, str(tmp_path / name))
    (tmp_path / "d.csv").write_text("a\n1\n\n3\n")           # a real blank cell in a one-column file
    assert import_path(engine, str(tmp_path / "d.csv")).row_count() == 3


def test_wide_table_cleaning_and_export(engine, tmp_path):
    n = 1200
    df = pl.DataFrame({f"c{i}": [1.0, None, 1.0, 2.0] for i in range(n)})
    df = pl.concat([df, df.head(1)])
    ds = import_frame(engine, df, "w")
    ds.apply(ops.plan_remove_duplicates(engine, ds.current, None))
    ds.apply(ops.plan_drop_missing(engine, ds.current, None))
    assert ds.row_count() == 2
    for lab in ("CSV (.csv)", "Parquet (.parquet)", "JSON Lines (.jsonl)"):
        export_dest = str(tmp_path / ("w" + FORMATS[lab][0]))
        export_dataset(engine, ds.current, export_dest, lab, None)


def test_remove_duplicates_on_mixed_nested_types_does_not_crash_duckdb(engine, tmp_path):
    """DuckDB 2.0.0 crashed (and invalidated the database) on the previous QUALIFY-based query."""
    t = pa.table({"l": [[1], [2, 3], [1], None], "s": [{"x": 1}, {"x": None}, {"x": 1}, None],
                  "b": [b"a", None, b"a", b"c"], "i": [1, 2, 1, 3]})
    p = str(tmp_path / "m.parquet")
    pq.write_table(t, p)
    for cols, expected in ((["i"], [1, 2, 3]), (["l"], [1, 2, 3]), (["b"], [1, 2, 3]), (None, [1, 2, 3])):
        ds = import_path(engine, p)
        plan = ops.plan_remove_duplicates(engine, ds.current, cols)
        ds.apply(plan)
        assert [r[0] for r in engine.fetchall(f'SELECT i FROM "{ds.current}"')] == expected
        assert plan.affected == 1
