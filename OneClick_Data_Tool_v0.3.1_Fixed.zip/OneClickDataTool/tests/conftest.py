import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest

from data.duckdb_manager import Engine


@pytest.fixture
def engine():
    e = Engine()
    yield e
    e.close()
