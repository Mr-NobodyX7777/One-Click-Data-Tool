"""Regression tests for v0.2: requested bug fixes, connectors and project persistence."""
import zipfile

import duckdb
import polars as pl
import pytest

from app.project import load_project, save_project
from app.state import AppState
from auditor.auditor import audit_table
from cleaner.operations import plan_fill_missing
from data.connectors.csv_source import CSVDataSource
from data.connectors.duckdb_source import list_tables as duckdb_tables
from data.connectors.base import SourceError
from data.importer import import_frame, import_path
from export.html_report import export_html_report


def test_csv_preview_does_not_reset_all_varchar(engine, tmp_path):
    path = tmp_path / 'weird.csv'
    path.write_text('amount,note\n12,x\n13,y\n')
    src = CSVDataSource(str(path))
    src._all_varchar = True
    assert src.preview(engine, 2).height == 2
    assert src._all_varchar
    table = engine.new_table_name('source')
    src.load_into(engine, table)
    assert engine.row_count(table) == 2


def test_undo_overflow_position_and_original_reset(engine):
    ds = import_frame(engine, pl.DataFrame({f'c{i}': [1, None] for i in range(12)}), 'history')
    for i in range(12):
        ds.apply(plan_fill_missing(engine, ds.current, f'c{i}', 'median'))
        assert ds.current == ds.stack[ds.pos]
    assert len(ds.stack) == ds.MAX_UNDO + 1
    assert ds.pos == len(ds.stack) - 1
    undo_count = 0
    while ds.undo():
        undo_count += 1
    assert undo_count == ds.MAX_UNDO
    ds.reset_to_original()
    assert ds.current == ds.original and not ds.is_modified
    assert engine.scalar(f'SELECT count(*) FROM "{ds.current}" WHERE c0 IS NULL') == 1


def test_xml_repeating_records(engine, tmp_path):
    p = tmp_path / 'sale.xml'
    p.write_text('<data><sale status="ok"><id>1</id><customer><city>X</city></customer></sale>'
                 '<sale status="new"><id>2</id><customer><city>Y</city></customer></sale></data>')
    ds = import_path(engine, str(p))
    assert ds.row_count() == 2
    assert {'@status', 'id', 'customer.city'} <= set(ds.column_names())
    ds2 = import_path(engine, str(p), record_element='.//sale')
    assert ds2.row_count() == 2


def test_xml_rejects_dtd(engine, tmp_path):
    p = tmp_path / 'x.xml'
    p.write_text('<!DOCTYPE data [ <!ENTITY test "BAD"> ]><data><r><v>1</v></r><r><v>2</v></r></data>')
    with pytest.raises(SourceError):
        import_path(engine, str(p))


def test_duckdb_readonly_import(engine, tmp_path):
    p = tmp_path / 'sample.duckdb'
    db = duckdb.connect(str(p))
    db.execute('CREATE TABLE sales(id INTEGER, amount DOUBLE)')
    db.execute('INSERT INTO sales VALUES (1,3.0),(2,4.5)')
    db.close()
    assert any(t['name'].endswith('.sales') for t in duckdb_tables(str(p)))
    ds = import_path(engine, str(p), table='main.sales')
    assert ds.row_count() == 2
    assert ds.info.format == 'DuckDB'


def test_portable_project_roundtrip(tmp_path):
    state = AppState()
    other = AppState()
    try:
        ds = import_frame(state.engine, pl.DataFrame({'a': [1, None, 3]}), 'test dataset')
        state.add_dataset(ds)
        ds.apply(plan_fill_missing(state.engine, ds.current, 'a', 'median'))
        state.missing_tokens = ['NOT_SET']
        saved = tmp_path / 'test.ocdt'
        save_project(state, str(saved))
        with zipfile.ZipFile(saved) as z:
            assert 'project.json' in z.namelist()
            assert any(p.endswith('.parquet') for p in z.namelist())
        datasets, active, tokens = load_project(other.engine, str(saved))
        assert active == 0 and tokens == ['NOT_SET']
        loaded = datasets[0]
        assert loaded.name == ds.name and loaded.row_count() == 3
        assert len(loaded.history.entries) == 1
        assert loaded.can_undo and loaded.undo()
        assert other.engine.scalar(f'SELECT count(*) FROM "{loaded.current}" WHERE a IS NULL') == 1
        loaded.reset_to_original()
        assert not loaded.is_modified
    finally:
        state.shutdown()
        other.shutdown()


def test_html_quality_report_escapes_content(engine, tmp_path):
    ds = import_frame(engine, pl.DataFrame({'id': [1, 2], 'a': [None, 3]}), '<unsafe&name>')
    audit = audit_table(engine, ds.current, ds.name)
    dest = tmp_path / 'quality.html'
    export_html_report(audit, str(dest))
    content = dest.read_text()
    assert 'Health-score breakdown' in content and 'Column-level results' in content
    assert '<unsafe&name>' not in content and '&lt;unsafe&amp;name&gt;' in content
