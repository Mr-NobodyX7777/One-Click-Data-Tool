import json
import sqlite3

import polars as pl
import pytest
from openpyxl import Workbook

from data.connectors.base import SourceError
from data.importer import import_path


def w(tmp_path, name, text, enc="utf-8"):
    p = tmp_path / name
    p.write_bytes(text.encode(enc))
    return str(p)


def test_small_csv(engine, tmp_path):
    ds = import_path(engine, w(tmp_path, "a.csv", "a,b\n1,x\n2,y\n"))
    assert ds.row_count() == 2 and [c for c, _ in ds.columns()] == ["a", "b"]


def test_empty_csv(engine, tmp_path):
    with pytest.raises(SourceError):
        import_path(engine, w(tmp_path, "e.csv", ""))


def test_header_only_csv(engine, tmp_path):
    with pytest.raises(SourceError):
        import_path(engine, w(tmp_path, "h.csv", "a,b\n"))


def test_no_header(engine, tmp_path):
    ds = import_path(engine, w(tmp_path, "n.csv", "1,2\n3,4\n"), header=False)
    assert ds.row_count() == 2


@pytest.mark.parametrize("delim", [";", "\t", "|"])
def test_delimiters(engine, tmp_path, delim):
    ds = import_path(engine, w(tmp_path, "d.csv", f"a{delim}b\n1{delim}2\n3{delim}4\n"))
    assert len(ds.columns()) == 2


def test_latin1_and_utf16(engine, tmp_path):
    ds = import_path(engine, w(tmp_path, "l.csv", "name,v\ncafé,1\nnaïve,2\n", "latin-1"))
    assert ds.engine.fetchall(f'select name from "{ds.current}" order by v')[0][0] == "café"
    ds = import_path(engine, w(tmp_path, "u.csv", "﻿name,v\nabc,1\nxyz,2\n", "utf-16"))
    assert ds.row_count() == 2


def test_missing_tokens_become_null(engine, tmp_path):
    ds = import_path(engine, w(tmp_path, "m.csv", "a\n1\nNA\n3\n"))
    assert ds.columns()[0][1] == "BIGINT"
    assert engine.scalar(f'select count(*) from "{ds.current}" where a is null') == 1


def test_large_csv(engine, tmp_path):
    pl.DataFrame({"x": range(300_000), "y": [1.5] * 300_000}).write_csv(tmp_path / "big.csv")
    assert import_path(engine, str(tmp_path / "big.csv")).row_count() == 300_000


def test_excel_sheets_mixed_and_empty(engine, tmp_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "S1"
    ws.append(["Age", "Name", None])
    for r in ([21, "a"], [22, "b"], ["unknown", "c"], [None, None], [25, "d"]):
        ws.append(r)
    ws2 = wb.create_sheet("S2")
    ws2.append(["v"])
    ws2.append([1.5])
    p = str(tmp_path / "w.xlsx")
    wb.save(p)
    ds = import_path(engine, p, sheet="S1")
    assert ds.row_count() == 4 and len(ds.columns()) == 2
    assert dict(ds.columns())["Age"] == "VARCHAR"  # mixed values kept as text, nothing lost
    assert any("mixes" in x for x in ds.info.warnings)
    assert import_path(engine, p, sheet="S2").row_count() == 1


def test_json_array_ndjson_and_flatten(engine, tmp_path):
    recs = [{"id": 1, "customer": {"name": "A", "address": {"city": "X"}}},
            {"id": 2, "customer": {"name": "B", "address": {"city": "Y"}}}]
    p = tmp_path / "a.json"
    p.write_text(json.dumps(recs))
    ds = import_path(engine, str(p))
    assert "customer.address.city" in ds.column_names()
    ds = import_path(engine, str(p), flatten=False)
    assert "customer" in ds.column_names()
    n = tmp_path / "a.ndjson"
    n.write_text("\n".join(json.dumps(r) for r in recs))
    assert import_path(engine, str(n)).row_count() == 2


def test_parquet(engine, tmp_path):
    pl.DataFrame({"a": [1, 2, 3]}).write_parquet(tmp_path / "p.parquet")
    assert import_path(engine, str(tmp_path / "p.parquet")).row_count() == 3


def test_sqlite_readonly(engine, tmp_path):
    p = str(tmp_path / "d.db")
    con = sqlite3.connect(p)
    con.execute("create table t(a integer, b text)")
    con.executemany("insert into t values (?,?)", [(1, "x"), (2, "y")])
    con.commit()
    con.close()
    before = open(p, "rb").read()
    ds = import_path(engine, p, table="t")
    assert ds.row_count() == 2
    assert open(p, "rb").read() == before


def test_unsupported_and_missing(engine, tmp_path):
    with pytest.raises(SourceError):
        import_path(engine, w(tmp_path, "x.xyz", "abc"))
    with pytest.raises(SourceError):
        import_path(engine, str(tmp_path / "nope.csv"))
