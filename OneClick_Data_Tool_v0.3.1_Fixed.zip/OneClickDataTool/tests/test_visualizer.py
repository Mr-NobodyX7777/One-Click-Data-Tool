import datetime as dt

import numpy as np
import polars as pl

from data.importer import import_frame
from export.png_export import export_png
from visualizer.charts import render
from visualizer.validation import ChartSpec, validate_plot_data


def ds(engine, **cols):
    return import_frame(engine, pl.DataFrame(cols), "t").current


def check(engine, t, spec):
    r = validate_plot_data(engine, t, spec)
    if r.ok:
        fig = render(r)
        assert fig.axes and fig.axes[0].has_data()  # a valid chart is never blank
    else:
        assert r.errors  # an invalid chart always explains why
    return r


def test_normal_numeric(engine):
    rng = np.random.default_rng(1)
    x = rng.normal(size=500)
    t = ds(engine, x=x, y=2 * x + rng.normal(size=500), g=["a", "b"] * 250)
    assert check(engine, t, ChartSpec("histogram", "x")).ok
    r = check(engine, t, ChartSpec("scatter", "x", "y"))
    assert r.ok and r.payload["r"] > 0.8
    assert check(engine, t, ChartSpec("box", "g", "x")).ok
    assert check(engine, t, ChartSpec("bar", "g", "x", agg="mean")).ok


def test_all_null_and_one_row_and_insufficient(engine):
    t = ds(engine, a=pl.Series([None] * 5, dtype=pl.Float64), b=[1.0, None, None, None, None], c=[1.0, 2, 3, 4, 5])
    for spec in (ChartSpec("histogram", "a"), ChartSpec("histogram", "b"), ChartSpec("scatter", "a", "c"),
                 ChartSpec("scatter", "b", "c"), ChartSpec("box", None, "a")):
        assert not check(engine, t, spec).ok


def test_constant_values_handled(engine):
    t = ds(engine, k=[5.0] * 10, v=list(range(10)))
    r = check(engine, t, ChartSpec("histogram", "k"))
    assert r.ok and r.warnings
    r = check(engine, t, ChartSpec("scatter", "k", "v"))
    assert r.ok and r.payload["slope"] is None


def test_missing_pairs_dropped(engine):
    t = ds(engine, x=[1.0, 2, 3, None, 5], y=[2.0, None, 6, 8, 10])
    r = check(engine, t, ChartSpec("scatter", "x", "y"))
    assert r.ok and r.payload["n"] == 3 and r.warnings


def test_high_cardinality_blocked_or_topn(engine):
    t = ds(engine, id=[f"u{i}" for i in range(500)], v=list(range(500)),
           c=[f"c{i % 80}" for i in range(500)])
    assert not check(engine, t, ChartSpec("bar", "id")).ok
    r = check(engine, t, ChartSpec("bar", "c", top_n=10))
    assert r.ok and len(r.payload["labels"]) == 10 and r.warnings


def test_dates_and_wrong_types(engine):
    days = [dt.date(2024, 1, 1) + dt.timedelta(days=i) for i in range(60)]
    t = ds(engine, d=days, v=[float(i) for i in range(60)], s=["a", "b"] * 30)
    r = check(engine, t, ChartSpec("line", "d", "v"))
    assert r.ok and r.payload["is_time"]
    assert not check(engine, t, ChartSpec("line", "s", "v")).ok  # text is not a time axis
    assert not check(engine, t, ChartSpec("histogram", "s")).ok
    assert not check(engine, t, ChartSpec("histogram", "nope")).ok
    assert not check(engine, t, ChartSpec("scatter", "v", "v")).ok


def test_large_dataset_is_sampled(engine):
    n = 400_000
    rng = np.random.default_rng(2)
    x = rng.normal(size=n)
    t = ds(engine, x=x, y=x + rng.normal(size=n))
    r = check(engine, t, ChartSpec("scatter", "x", "y", max_points=20_000))
    assert r.ok and len(r.payload["x"]) == 20_000 and r.payload["n"] == n and r.notes
    assert check(engine, t, ChartSpec("histogram", "x")).payload["counts"].sum() == n


def test_png_export_and_refuses_invalid(engine, tmp_path):
    t = ds(engine, x=[1.0, 2, 3, 4, 5])
    fig = render(validate_plot_data(engine, t, ChartSpec("histogram", "x")))
    export_png(fig, str(tmp_path / "c.png"))
    assert (tmp_path / "c.png").stat().st_size > 1000
    bad = validate_plot_data(engine, t, ChartSpec("histogram", "zzz"))
    try:
        render(bad)
        assert False
    except ValueError:
        pass
