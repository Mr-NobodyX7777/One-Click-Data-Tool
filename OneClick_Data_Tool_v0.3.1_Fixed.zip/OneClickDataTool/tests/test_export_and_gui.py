import time

import polars as pl
import pytest

from data.importer import import_frame, import_path
from export import FORMATS, ExportError, export_dataset


def test_export_roundtrip_all_formats(engine, tmp_path):
    ds = import_frame(engine, pl.DataFrame({"a": [1, 2, 3], "b": ["x", "y", None]}), "t")
    for label, (ext, _) in FORMATS.items():
        p = str(tmp_path / f"o{ext}")
        export_dataset(engine, ds.current, p, label, None)
        assert import_path(engine, p).row_count() == 3


def test_never_overwrites_original(engine, tmp_path):
    src = tmp_path / "in.csv"
    src.write_text("a\n1\n2\n")
    ds = import_path(engine, str(src))
    with pytest.raises(ExportError):
        export_dataset(engine, ds.current, str(src), "CSV (.csv)", str(src))
    assert src.read_text() == "a\n1\n2\n"


def test_gui_smoke():
    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([])
    from app.main_window import MainWindow
    from visualizer.validation import ChartSpec
    w = MainWindow()
    w.resize(1000, 700)
    w.load_sample()
    end = time.time() + 20
    while time.time() < end and not (w.state.current and w.state.audit_for(w.state.current)):
        app.processEvents(); time.sleep(0.02)
    assert w.state.audit_for(w.state.current) is not None
    for k in ("import", "audit", "clean", "viz"):
        w.show_page(k); app.processEvents()
    w.p_viz.generate_requested.emit(ChartSpec("histogram", "salary"))
    end = time.time() + 20
    while time.time() < end and w.p_viz.figure is None:
        app.processEvents(); time.sleep(0.02)
    assert w.p_viz.figure is not None
    # closing is (by design) refused while a job runs, which would open a modal box and hang CI
    end = time.time() + 20
    while time.time() < end and w.runner.busy:
        app.processEvents(); time.sleep(0.02)
    assert not w.runner.busy
    w.close()
