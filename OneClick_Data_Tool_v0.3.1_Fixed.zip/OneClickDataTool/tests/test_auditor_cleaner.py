import numpy as np
import polars as pl
import pytest

from auditor.auditor import HEALTH_RULES, audit_table
from cleaner.operations import (OperationError, plan_drop_missing, plan_fill_missing, plan_remove_duplicates)
from data.importer import import_frame
from data.sample import sample_frame


def make(engine, **cols):
    return import_frame(engine, pl.DataFrame(cols), "t")


def test_missing_duplicates_constants(engine):
    ds = make(engine, a=[1, 2, None, 2, 2], b=["x", "y", " ", "y", "y"], c=[7] * 5)
    a = audit_table(engine, ds.current)
    assert a.profile("a").missing == 1 and a.profile("b").missing == 1  # blank text counts as missing
    assert a.duplicates == 2
    assert a.profile("c").constant and not a.profile("a").constant


def test_numeric_statistics_match_numpy(engine):
    vals = [1.0, 2.0, 3.0, 4.0, 5.0, 100.0]
    p = audit_table(engine, make(engine, v=vals).current).profile("v")
    assert p.mean == pytest.approx(np.mean(vals)) and p.median == pytest.approx(np.median(vals))
    assert p.std == pytest.approx(np.std(vals, ddof=1))
    assert p.q1 == pytest.approx(np.percentile(vals, 25)) and p.q3 == pytest.approx(np.percentile(vals, 75))
    assert p.outliers == 1 and p.skew > 1


def test_health_score_bounds_and_breakdown(engine):
    a = audit_table(engine, import_frame(engine, sample_frame(), "s").current)
    assert 0 <= a.health.score <= 100
    assert {n for n, _, _ in a.health.components} == set(HEALTH_RULES)
    assert a.health.score == max(0, round(100 - sum(p for _, p, _ in a.health.components)))
    bad = make(engine, a=[None] * 20)
    assert 0 <= audit_table(engine, bad.current).health.score <= 100


def test_recommendations(engine):
    skewed = [1.0] * 50 + [1000.0] * 3 + [None] * 10
    a = audit_table(engine, make(engine, v=skewed).current)
    assert a.recommendations["v"].action == "median"


def test_fill_mean_median_custom_and_undo(engine):
    ds = make(engine, a=[1, 2, None, 5], s=["x", None, "y", "z"])
    ds.apply(plan_fill_missing(engine, ds.current, "a", "median"))
    assert engine.fetchall(f'select a from "{ds.current}" order by rowid')[2][0] == 2.0
    ds.apply(plan_fill_missing(engine, ds.current, "s", "custom", "Unknown"))
    assert engine.scalar(f'select s from "{ds.current}" where rowid=1') == "Unknown"
    assert [e.action for e in ds.history.applied()] == ["fill_median", "fill_custom"]
    ds.undo()
    assert engine.scalar(f'select count(*) from "{ds.current}" where s is null') == 1 and ds.can_redo
    ds.redo()
    ds.reset_to_original()
    assert not ds.is_modified and ds.row_count() == 4


def test_mean_fill_value(engine):
    ds = make(engine, a=[2.0, 4.0, None])
    p = plan_fill_missing(engine, ds.current, "a", "mean")
    assert p.affected == 1 and p.parameters["value"] == 3.0


def test_custom_value_validation(engine):
    ds = make(engine, a=[1, None], d=["2020-01-01", None])
    with pytest.raises(OperationError):
        plan_fill_missing(engine, ds.current, "a", "custom", "abc")
    with pytest.raises(OperationError):
        plan_fill_missing(engine, ds.current, "s", "mean")
    with pytest.raises(OperationError):
        plan_fill_missing(engine, ds.current, "d", "mean")


def test_drop_rows_and_duplicates(engine):
    ds = make(engine, a=[1, None, 1, 3], b=["x", "y", "x", None])
    p = plan_drop_missing(engine, ds.current, ["a"])
    assert (p.affected, p.rows_after) == (1, 3)
    p = plan_drop_missing(engine, ds.current, None)
    assert p.affected == 2
    p = plan_remove_duplicates(engine, ds.current)
    assert p.affected == 1
    ds.apply(p)
    assert ds.row_count() == 3 and ds.history.entries[0].affected == 1


def test_nothing_changes_before_apply(engine):
    ds = make(engine, a=[1, None])
    plan_drop_missing(engine, ds.current, ["a"])
    assert ds.row_count() == 2 and not ds.history.entries
